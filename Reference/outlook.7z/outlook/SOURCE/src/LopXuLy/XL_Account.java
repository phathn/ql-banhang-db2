/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LopXuLy;

import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.*;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

/**
 *
 * @author letuan
 */
public class XL_Account {

    private int _AccountID;
    private String _AccountName;
    private String _EmailAddress;
    private String _PopName;
    private String _SmtpName;
    private int _PopPort;
    private int _SmtpPort;
    private String _PopType;
    private String _Password;

    /**
     * @return the _AccountID
     */
    public int getAccountID() {
        return _AccountID;
    }

    /**
     * @param AccountID the _AccountID to set
     */
    public void setAccountID(int AccountID) {
        this._AccountID = AccountID;
    }

    /**
     * @return the _AccountName
     */
    public String getAccountName() {
        return _AccountName;
    }

    /**
     * @param AccountName the _AccountName to set
     */
    public void setAccountName(String AccountName) {
        this._AccountName = AccountName;
    }

    /**
     * @return the _EmailAddress
     */
    public String getEmailAddress() {
        return _EmailAddress;
    }

    /**
     * @param EmailAddress the _EmailAddress to set
     */
    public void setEmailAddress(String EmailAddress) {
        this._EmailAddress = EmailAddress;
    }

    /**
     * @return the _PopName
     */
    public String getPopName() {
        return _PopName;
    }

    /**
     * @param PopName the _PopName to set
     */
    public void setPopName(String PopName) {
        this._PopName = PopName;
    }

    /**
     * @return the _SmtpName
     */
    public String getSmtpName() {
        return _SmtpName;
    }

    /**
     * @param SmtpName the _SmtpName to set
     */
    public void setSmtpName(String SmtpName) {
        this._SmtpName = SmtpName;
    }

    /**
     * @return the _PopPort
     */
    public int getPopPort() {
        return _PopPort;
    }

    /**
     * @param PopPort the _PopPort to set
     */
    public void setPopPort(int PopPort) {
        this._PopPort = PopPort;
    }

    /**
     * @return the _SmtpPort
     */
    public int getSmtpPort() {
        return _SmtpPort;
    }

    /**
     * @param SmtpPort the _SmtpPort to set
     */
    public void setSmtpPort(int SmtpPort) {
        this._SmtpPort = SmtpPort;
    }

    /**
     * @return the _PopType
     */
    public String getPopType() {
        return _PopType;
    }

    /**
     * @param PopType the _PopType to set
     */
    public void setPopType(String PopType) {
        this._PopType = PopType;
    }

    public XL_Account() {
    }

    /**
     * Constructor
     * @param Nut
     */
    public XL_Account(Element Nut) {
        this._AccountID = Integer.parseInt(Nut.getAttribute("AccountID"));

        for (Node childnode = Nut.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
            //Text textNode = (Text) childnode.getFirstChild();
            //String content = textNode.getData();
            if (childnode.getNodeName().equals("AccountName")) {
                Text textNode = (Text) childnode.getFirstChild();
                if (textNode != null) {
                    String content = textNode.getData();
                    this._AccountName = content;
                }
            } else if (childnode.getNodeName().equals("EmailAddress")) {
                Text textNode = (Text) childnode.getFirstChild();
                if (textNode != null) {
                    String content = textNode.getData();
                    this._EmailAddress = content;
                }
            } else if (childnode.getNodeName().equals("Server")) {
                NamedNodeMap attributes = childnode.getAttributes();
                Node attributeNode = attributes.item(0);
                for (Node child = childnode.getFirstChild(); child != null; child = child.getNextSibling()) {
                    //Text textNode = (Text) childnode.getFirstChild();
                    //String content = textNode.getData();
                    if (child.getNodeName().equals("pop")) {
                        attributes = child.getAttributes();
                        for (int i = 0; i < attributes.getLength(); ++i) {
                            attributeNode = attributes.item(i);
                            if (attributeNode.getNodeName().equals("ServerName")) {
                                this._PopName = attributeNode.getNodeValue();
                            } else if (attributeNode.getNodeName().equals("Port")) {
                                this._PopPort = Integer.parseInt(attributeNode.getNodeValue());
                            } else if (attributeNode.getNodeName().equals("Type")) {
                                this._PopType = attributeNode.getNodeValue();
                            }
                        }
                    } else if (child.getNodeName().equals("smtp")) {
                        attributes = child.getAttributes();
                        for (int i = 0; i < attributes.getLength(); ++i) {
                            attributeNode = attributes.item(i);
                            if (attributeNode.getNodeName().equals("ServerName")) {
                                this._SmtpName = attributeNode.getNodeValue();
                            } else if (attributeNode.getNodeName().equals("Port")) {
                                this._SmtpPort = Integer.parseInt(attributeNode.getNodeValue());
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * tao tai khoan moi
     * @param strTenTapTin
     * @return
     */
    @SuppressWarnings("empty-statement")
    public boolean Ghi(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));
            Element Goc = TaiLieu.getDocumentElement();
            Element Account = Goc.getOwnerDocument().createElement("Account");
            //tao cac the con cua the Account
            Element AccountName = Account.getOwnerDocument().createElement("AccountName");
            Element EmailAddress = Account.getOwnerDocument().createElement("EmailAddress");
            Element Server = Account.getOwnerDocument().createElement("Server");
            //tao cac the con cua the server
            Element pop = Server.getOwnerDocument().createElement("pop");
            Element smtp = Server.getOwnerDocument().createElement("smtp");

            //khoi tao noi dung cho cac the
            AccountName.setTextContent(this._AccountName);
            EmailAddress.setTextContent(_EmailAddress);

            //dua noi dung vao cac the
            Account.appendChild(AccountName);
            Account.appendChild(EmailAddress);
            Account.appendChild(Server);
            Server.appendChild(pop);
            Server.appendChild(smtp);

            Account.setAttribute("AccountID", String.valueOf(_AccountID));
            pop.setAttribute("ServerName", _PopName);
            pop.setAttribute("Port", String.valueOf(_PopPort));
            pop.setAttribute("Type", _PopType);

            smtp.setAttribute("ServerName", _SmtpName);
            smtp.setAttribute("Port", String.valueOf(_SmtpPort));

            Goc.appendChild(Account);

            /*XMLSerializer serializer = new XMLSerializer();
            serializer.setOutputCharStream(new FileWriter(strTenTapTin));
            serializer.serialize(TaiLieu);*/
            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (TransformerException ex) {
            return false;
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * lay userid by name
     * @param tenTapTin
     * @param Name
     * @return
     * @throws javax.xml.parsers.ParserConfigurationException
     * @throws org.xml.sax.SAXException
     * @throws java.io.IOException
     * @throws javax.xml.xpath.XPathExpressionException
     */
    public int getUserIDByName(String tenTapTin, String Name) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        builder = factory.newDocumentBuilder();
        Document TaiLieu = builder.parse(new File(tenTapTin));

        XPathFactory xpfactory = XPathFactory.newInstance();
        XPath xpath = xpfactory.newXPath();
        XPathExpression expr = xpath.compile("//Account[./AccountName/text()='" + Name + "']");
        Object result = expr.evaluate(TaiLieu, XPathConstants.NODESET);
        NodeList nodes = (NodeList) result;
        for (int i = 0; i < nodes.getLength(); i++) {
            Node Nut = nodes.item(i);
            if (Nut instanceof Element) {
                Element elem = ((Element) Nut);
                return Integer.parseInt(elem.getAttribute("AccountID"));
            }

        }
        return -1;
    }

    /**
     * Lay thong tin user tu ten tai khoan
     * @param tenTapTin
     * @param Name
     * @throws javax.xml.parsers.ParserConfigurationException
     * @throws org.xml.sax.SAXException
     * @throws java.io.IOException
     * @throws javax.xml.xpath.XPathExpressionException
     */
    public void getUserInfoByName(String tenTapTin, String Name) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        builder = factory.newDocumentBuilder();
        Document TaiLieu = builder.parse(new File(tenTapTin));

        XPathFactory xpfactory = XPathFactory.newInstance();
        XPath xpath = xpfactory.newXPath();
        XPathExpression expr = xpath.compile("//Account[./AccountName/text()='" + Name + "']");
        Object result = expr.evaluate(TaiLieu, XPathConstants.NODESET);
        NodeList nodes = (NodeList) result;
        for (int i = 0; i < nodes.getLength(); i++) {
            Node Nut = nodes.item(i);
            if (Nut instanceof Element) {
                Element elem = ((Element) Nut);
                _AccountID = Integer.parseInt(elem.getAttribute("AccountID"));
                for (Node childnode = Nut.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
                    //Text textNode = (Text) childnode.getFirstChild();
                    //String content = textNode.getData();
                    if (childnode.getNodeName().equals("AccountName")) {
                        Text textNode = (Text) childnode.getFirstChild();
                        String content = textNode.getData();
                        this._AccountName = content;
                    } else if (childnode.getNodeName().equals("EmailAddress")) {
                        Text textNode = (Text) childnode.getFirstChild();
                        String content = textNode.getData();
                        this._EmailAddress = content;
                    } else if (childnode.getNodeName().equals("Server")) {
                        NamedNodeMap attributes = childnode.getAttributes();
                        Node attributeNode = attributes.item(0);
                        for (Node child = childnode.getFirstChild(); child != null; child = child.getNextSibling()) {
                            //Text textNode = (Text) childnode.getFirstChild();
                            //String content = textNode.getData();
                            if (child.getNodeName().equals("pop")) {
                                attributes = child.getAttributes();
                                for (int j = 0; j < attributes.getLength(); ++j) {
                                    attributeNode = attributes.item(j);
                                    if (attributeNode.getNodeName().equals("ServerName")) {
                                        this._PopName = attributeNode.getNodeValue();
                                    } else if (attributeNode.getNodeName().equals("Port")) {
                                        this._PopPort = Integer.parseInt(attributeNode.getNodeValue());
                                    } else if (attributeNode.getNodeName().equals("Type")) {
                                        this._PopType = attributeNode.getNodeValue();
                                    }
                                }
                            } else if (child.getNodeName().equals("smtp")) {
                                attributes = child.getAttributes();
                                for (int j = 0; j < attributes.getLength(); ++j) {
                                    attributeNode = attributes.item(j);
                                    if (attributeNode.getNodeName().equals("ServerName")) {
                                        this._SmtpName = attributeNode.getNodeValue();
                                    } else if (attributeNode.getNodeName().equals("Port")) {
                                        this._SmtpPort = Integer.parseInt(attributeNode.getNodeValue());
                                    }
                                }
                            }
                        }
                    }
                }
            }

        }
    }

    /**
     * Cap nhatthong tin tai khoan
     * @param strTenTapTin
     * @return
     */
    public boolean update(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//Account[@AccountID='" + _AccountID + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Node account = (Node) result;

            for (Node childnode = account.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
                if (childnode.getNodeName().equals("AccountName")) {
                    childnode.setTextContent(_AccountName);
                } else if (childnode.getNodeName().equals("EmailAddress")) {
                    childnode.setTextContent(_EmailAddress);
                } else if (childnode.getNodeName().equals("Server")) {
                    NamedNodeMap attributes = childnode.getAttributes();
                    Node attributeNode = attributes.item(0);
                    for (Node child = childnode.getFirstChild(); child != null; child = child.getNextSibling()) {
                        //Text textNode = (Text) childnode.getFirstChild();
                        //String content = textNode.getData();
                        if (child.getNodeName().equals("pop")) {
                            attributes = child.getAttributes();
                            for (int i = 0; i < attributes.getLength(); ++i) {
                                attributeNode = attributes.item(i);
                                if (attributeNode.getNodeName().equals("ServerName")) {
                                    attributeNode.setNodeValue(_PopName);
                                } else if (attributeNode.getNodeName().equals("Port")) {
                                    attributeNode.setNodeValue(String.valueOf(_PopPort));
                                } else if (attributeNode.getNodeName().equals("Type")) {
                                    attributeNode.setNodeValue(_PopType);
                                }
                            }
                        } else if (child.getNodeName().equals("smtp")) {
                            attributes = child.getAttributes();
                            for (int i = 0; i < attributes.getLength(); ++i) {
                                attributeNode = attributes.item(i);
                                if (attributeNode.getNodeName().equals("ServerName")) {
                                    attributeNode.setNodeValue(_SmtpName);
                                } else if (attributeNode.getNodeName().equals("Port")) {
                                    attributeNode.setNodeValue(String.valueOf(_SmtpPort));
                                }
                            }
                        }
                    }
                }
            }
            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));

        } catch (XPathExpressionException ex) {
             return false;
        } catch (TransformerException ex) {
            return false;
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * Xoa bo tai khoan
     * @param strTenTapTin
     * @return
     */
    public boolean delete(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//Account[@AccountID='" + _AccountID + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Node acc = (Node) result;

            TaiLieu.getDocumentElement().removeChild(acc);

            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (XPathExpressionException ex) {
            return false;
        } catch (TransformerException ex) {
            return false;
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }
    /**
     * @return the _Password
     */
    public String getPassword() {
        return _Password;
    }

    /**
     * @param Password the _Password to set
     */
    public void setPassword(String Password) {
        this._Password = Password;
    }
}
