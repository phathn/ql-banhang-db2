/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LopXuLy;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

/**
 *
 * @author letuan
 */
public class XL_MailDaGui {

    private String _address;

    /**
     * @return the _address
     */
    public String getAddress() {
        return _address;
    }

    /**
     * @param address the _address to set
     */
    public void setAddress(String address) {
        this._address = address;
    }

    public XL_MailDaGui() {
    }

    /**
     * constructor
     * @param Nut
     */
    public XL_MailDaGui(Element Nut) {
        this._address = Nut.getAttribute("Address");
    }

    /**
     * luu mail da gui
     * @param strTenTapTin
     * @return
     */
    public boolean Ghi(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));
            Element Goc = TaiLieu.getDocumentElement();
            Element Mail = Goc.getOwnerDocument().createElement("Mail");
            //tao cac the con cua the Account

            Mail.setAttribute("Address", _address);

            Goc.appendChild(Mail);


            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (TransformerException ex) {
            Logger.getLogger(XL_MailDaGui.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
            Logger.getLogger(XL_MailDaGui.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(XL_MailDaGui.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(XL_MailDaGui.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    /**
     * mail da gi chua ton tai trong danh sach mail, luu lai
     * @param tenTapTin
     * @param address
     * @return
     * @throws javax.xml.xpath.XPathExpressionException
     */
    public static boolean chuaTonTai(String tenTapTin, String address) throws XPathExpressionException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(tenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//Mail[@Address='" + address + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Node Nut = (Node) result;

            if (Nut != null) {
                return false;
            }
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }
}
