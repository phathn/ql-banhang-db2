/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package LopXuLy;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

/**
 *
 * @author letuan
 */
public class XL_MonthTask {
    private String _Ngay="";
    private ArrayList<XL_CongViecMonthTask> _danhSachCongViec = new ArrayList<XL_CongViecMonthTask>();

    /**
     * @return the _Ngay
     */
    public String getNgay() {
        return _Ngay;
    }

    /**
     * @param _Ngay the _Ngay to set
     */
    public void setNgay(String Ngay) {
        this._Ngay = Ngay;
    }

    /**
     * @return the _danhSachCongViec
     */
    public ArrayList<XL_CongViecMonthTask> getCongViec() {
        return _danhSachCongViec;
    }

    /**
     * @param congViec the _danhSachCongViec to set
     */
    public void setCongViec(ArrayList<XL_CongViecMonthTask> congViec) {
        this._danhSachCongViec = congViec;
    }

    /**
     * doc cong viec theo lich thang
     * @param strTenTapTin
     * @return
     */
    public boolean Doc(String strTenTapTin) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder;
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//task[@ngay='" + _Ngay + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Element task = (Element) result;
            if (task == null) {
                return false;
            }
            for (Node childnode = task.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
                if (childnode.getNodeName().equals("congviec")) {
                    XL_CongViecMonthTask cv=new XL_CongViecMonthTask((Element)childnode);
                    _danhSachCongViec.add(cv);
                }
            }
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (XPathExpressionException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * lay so thu tu cua cong viec
     * @param tenTapTin
     * @param Ngay
     * @return
     */
    public static int layStt(String tenTapTin, String Ngay) {
        int num = 0;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder;
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(tenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//task[@ngay='" + Ngay + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Element task = (Element) result;

            if(task == null){
                return 0;
            }
            Node nodeCuoi = null;
            NodeList list = task.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                Node Nut = list.item(i);
                if (Nut instanceof Element) {
                    nodeCuoi = Nut;
                }
            }
            if(nodeCuoi == null){
                return 0;
            }else{
                num = Integer.parseInt(((Element)nodeCuoi).getAttribute("stt"));
            }
        } catch (XPathExpressionException ex) {
            Logger.getLogger(XL_MonthTask.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
            Logger.getLogger(XL_DanhSachContact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(XL_DanhSachContact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(XL_DanhSachContact.class.getName()).log(Level.SEVERE, null, ex);
        }
        return num;
    }

    /**
     * delete cong viec theo lich thang
     * @param strTenTapTin
     * @return
     */
    public boolean delete(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));
            Element Goc = TaiLieu.getDocumentElement();

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//task[@ngay='" + _Ngay + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Node task = (Node) result;

            Goc.removeChild(task);

            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (TransformerException ex) {
            return false;
        }  catch (XPathExpressionException ex) {
            return false;
        }  catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }
}
