/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LopXuLy;

import com.sun.org.apache.xml.internal.serialize.DOMSerializer;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.AttributedCharacterIterator.Attribute;
import java.util.ArrayList;
import java.util.jar.Attributes.Name;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.xml.parsers.*;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

/**
 *
 * @author letuan
 */
public class XL_Mail {

    private int _mailID;
    private String _subject;
    private String _body;
    private String _date;
    private ArrayList<String> _pathAttach = new ArrayList<String>();
    private String _from;
    private ArrayList<String> _to = new ArrayList<String>();
    private ArrayList<String> _cc = new ArrayList<String>();
    private int _userID;
    private String _placeStore;
    private String _tag = "";
    private String _star = "";
    private String _junk = "";

    /**
     * @return the _mailID
     */
    public int getMailID() {
        return _mailID;
    }

    /**
     * @param mailID the _mailID to set
     */
    public void setMailID(int mailID) {
        this._mailID = mailID;
    }

    /**
     * @return the _subject
     */
    public String getSubject() {
        return _subject;
    }

    /**
     * @param subject the _subject to set
     */
    public void setSubject(String subject) {
        this._subject = subject;
    }

    /**
     * @return the _body
     */
    public String getBody() {
        return _body;
    }

    /**
     * @param body the _body to set
     */
    public void setBody(String body) {
        this._body = body;
    }

    /**
     * @return the _date
     */
    public String getDate() {
        return _date;
    }

    /**
     * @param date the _date to set
     */
    public void setDate(String date) {
        this._date = date;
    }

    /**
     * @return the _pathAttach
     */
    public ArrayList<String> getPathAttach() {
        return _pathAttach;
    }

    /**
     * @param pathAttach the _pathAttach to set
     */
    public void setPathAttach(ArrayList<String> pathAttach) {
        this._pathAttach = pathAttach;
    }

    /**
     * @return the _userID
     */
    public int getUserID() {
        return _userID;
    }

    /**
     * @param userID the _userID to set
     */
    public void setUserID(int userID) {
        this._userID = userID;
    }

    public XL_Mail() {
    }

    /**
     * constructor
     * @param Nut
     */
    public XL_Mail(Element Nut) {
        this._mailID = Integer.parseInt(Nut.getAttribute("MailID"));
        this._userID = Integer.parseInt(Nut.getAttribute("UserID"));

        for (Node childnode = Nut.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
            //Text textNode = (Text) childnode.getFirstChild();
            //String content = textNode.getData();
            if (childnode.getNodeName().equals("Subject")) {
                Text textNode = (Text) childnode.getFirstChild();
                if (textNode != null) {
                    String content = textNode.getData();
                    this._subject = content;
                }
            } else if (childnode.getNodeName().equals("Body")) {
                this._body = childnode.getTextContent();
            } else if (childnode.getNodeName().equals("Date")) {
                Text textNode = (Text) childnode.getFirstChild();
                if (textNode != null) {
                    String content = textNode.getData();
                    this._date = content;
                }
            } else if (childnode.getNodeName().equals("From")) {
                this._from = childnode.getTextContent();
            } else if (childnode.getNodeName().equals("To")) {
                for (Node child = childnode.getFirstChild(); child != null; child = child.getNextSibling()) {
                    this._to.add(child.getTextContent());
                }
            } else if (childnode.getNodeName().equals("CC")) {
                for (Node child = childnode.getFirstChild(); child != null; child = child.getNextSibling()) {
                    this._cc.add(child.getTextContent());
                }
            } else if (childnode.getNodeName().equals("PlaceStore")) {
                Text textNode = (Text) childnode.getFirstChild();
                if (textNode != null) {
                    String content = textNode.getData();
                    this._placeStore = content;
                }
            } else if (childnode.getNodeName().equals("PathAttach")) {
                for (Node child = childnode.getFirstChild(); child != null; child = child.getNextSibling()) {
                    Text textNode = (Text) child.getFirstChild();
                    if (textNode != null) {
                        String content = textNode.getData();
                        this._pathAttach.add(content);
                    }
                }
            } else if (childnode.getNodeName().equals("tag")) {
                Text textNode = (Text) childnode.getFirstChild();
                if (textNode != null) {
                    String content = textNode.getData();
                    this._tag = content;
                }
            } else if (childnode.getNodeName().equals("star")) {
                Text textNode = (Text) childnode.getFirstChild();
                if (textNode != null) {
                    String content = textNode.getData();
                    this._star = content;
                }
            } else if (childnode.getNodeName().equals("junk")) {
                Text textNode = (Text) childnode.getFirstChild();
                if (textNode != null) {
                    String content = textNode.getData();
                    this._junk = content;
                }
            }
        }

    }

    /**
     * Luu mail moi
     * @param strTenTapTin
     * @return
     */
    public boolean Ghi(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;

        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));
            Element Goc = TaiLieu.getDocumentElement();
            Element Mail = Goc.getOwnerDocument().createElement("Mail");
            //tao cac the con cua the Account
            Element Subject = Mail.getOwnerDocument().createElement("Subject");
            Element Body = Mail.getOwnerDocument().createElement("Body");
            Element Date = Mail.getOwnerDocument().createElement("Date");
            Element From = Mail.getOwnerDocument().createElement("From");
            Element To = Mail.getOwnerDocument().createElement("To");
            Element CC = Mail.getOwnerDocument().createElement("CC");
            Element PathAttach = Mail.getOwnerDocument().createElement("PathAttach");
            Element PlaceStore = Mail.getOwnerDocument().createElement("PlaceStore");
            Element Tag = Mail.getOwnerDocument().createElement("tag");
            Element Star = Mail.getOwnerDocument().createElement("star");
            Element Junk = Mail.getOwnerDocument().createElement("junk");

            for (int i = 0; i < _to.size(); i++) {
                Element AddressTo = To.getOwnerDocument().createElement("AddressTo");
                CDATASection cdata = Mail.getOwnerDocument().createCDATASection(_to.get(i));
                AddressTo.appendChild(cdata);
                To.appendChild(AddressTo);
            }
            for (int i = 0; i < _cc.size(); i++) {
                Element AddressCC = To.getOwnerDocument().createElement("AddressCC");
                CDATASection cdata = Mail.getOwnerDocument().createCDATASection(_cc.get(i));
                AddressCC.appendChild(cdata);
                CC.appendChild(AddressCC);
            }
            //khoi tao noi dung cho cac the
            Subject.setTextContent(this._subject);

            CDATASection cdata = Mail.getOwnerDocument().createCDATASection(_body);
            Body.appendChild(cdata);

            Date.setTextContent(_date);

            cdata = Mail.getOwnerDocument().createCDATASection(_from);
            From.appendChild(cdata);


            for (int i = 0; i < _pathAttach.size(); i++) {
                Element PathName = To.getOwnerDocument().createElement("PathName");
                PathName.setTextContent(_pathAttach.get(i));
                PathAttach.appendChild(PathName);
            }

            PlaceStore.setTextContent(_placeStore);
            Tag.setTextContent("");
            Star.setTextContent("false");
            Junk.setTextContent("false");
            //dua noi dung vao cac the
            Mail.appendChild(Subject);
            Mail.appendChild(Body);
            Mail.appendChild(Date);
            Mail.appendChild(From);
            Mail.appendChild(To);
            Mail.appendChild(CC);
            Mail.appendChild(PathAttach);
            Mail.appendChild(PlaceStore);
            Mail.appendChild(Tag);
            Mail.appendChild(Star);
            Mail.appendChild(Junk);


            Mail.setAttribute("MailID", String.valueOf(_mailID));
            Mail.setAttribute("UserID", String.valueOf(_userID));

            Goc.appendChild(Mail);

            /*XMLSerializer serializer = new XMLSerializer();
            serializer.setOutputCharStream(new FileWriter(strTenTapTin));
            serializer.serialize(TaiLieu);*/
            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (TransformerException ex) {
            Logger.getLogger(XL_Mail.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }

        return true;
    }

    /**
     * doc mail
     * @param tenTapTin
     * @param mailID
     * @return
     */
    public boolean docMail(String tenTapTin, int mailID) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(tenTapTin));
            Element Goc = TaiLieu.getDocumentElement();

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//Mail[@MailID='" + mailID + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Element mail = (Element) result;

            //Element mail = Goc.getOwnerDocument().getElementById(String.valueOf(mailID));
            this._mailID = mailID;
            this._userID = Integer.parseInt(mail.getAttribute("UserID"));

            for (Node childnode = mail.getFirstChild();
                    childnode != null; childnode = childnode.getNextSibling()) {
                //Text textNode = (Text) childnode.getFirstChild();
                //String content = textNode.getData();
                if (childnode.getNodeName().equals("Subject")) {
                    Text textNode = (Text) childnode.getFirstChild();
                    String content = textNode.getData();
                    this._subject = content;
                } else if (childnode.getNodeName().equals("Body")) {
                    this._body = childnode.getTextContent();
                } else if (childnode.getNodeName().equals("Date")) {
                    Text textNode = (Text) childnode.getFirstChild();
                    String content = textNode.getData();
                    this._date = content;
                } else if (childnode.getNodeName().equals("From")) {
                    this._from = childnode.getTextContent();
                } else if (childnode.getNodeName().equals("To")) {
                    for (Node child = childnode.getFirstChild(); child != null; child = child.getNextSibling()) {
                        if (child.getNodeName().equals("AddressTo")) {
                            this._to.add(child.getTextContent());
                        }
                    }
                } else if (childnode.getNodeName().equals("CC")) {
                    for (Node child = childnode.getFirstChild(); child != null; child = child.getNextSibling()) {
                        if (child.getNodeName().equals("AddressCC")) {
                            this._cc.add(child.getTextContent());
                        }
                    }
                } else if (childnode.getNodeName().equals("PathAttach")) {
                    for (Node child = childnode.getFirstChild(); child != null; child = child.getNextSibling()) {
                        Text textNode = (Text) child.getFirstChild();
                        if (textNode != null) {
                            String content = textNode.getData();
                            this._pathAttach.add(content);
                        }
                    }
                } else if (childnode.getNodeName().equals("PlaceStore")) {
                    Text textNode = (Text) childnode.getFirstChild();
                    String content = textNode.getData();
                    this._placeStore = content;
                } else if (childnode.getNodeName().equals("tag")) {
                    Text textNode = (Text) childnode.getFirstChild();
                    if (textNode != null) {
                        String content = textNode.getData();
                        this._tag = content;
                    }
                } else if (childnode.getNodeName().equals("star")) {
                    Text textNode = (Text) childnode.getFirstChild();
                    if (textNode != null) {
                        String content = textNode.getData();
                        this._star = content;
                    }
                } else if (childnode.getNodeName().equals("junk")) {
                    Text textNode = (Text) childnode.getFirstChild();
                    if (textNode != null) {
                        String content = textNode.getData();
                        this._junk = content;
                    }
                }
            }
        } catch (XPathExpressionException ex) {
            Logger.getLogger(XL_Mail.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * cap nhat tag
     * @param strTenTapTin
     * @return
     */
    public boolean updateTag(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//Mail[@MailID='" + _mailID + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Node contact = (Node) result;
            for (Node childnode = contact.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
                if (childnode.getNodeName().equals("tag")) {
                    childnode.setTextContent(_tag);
                }
            }

            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (XPathExpressionException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * cap nhat star
     * @param strTenTapTin
     * @return
     */
    public boolean updateStar(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//Mail[@MailID='" + _mailID + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Node contact = (Node) result;
            for (Node childnode = contact.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
                if (childnode.getNodeName().equals("star")) {
                    childnode.setTextContent(_star);
                }
            }

            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (XPathExpressionException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * cap nhat junk
     * @param strTenTapTin
     * @return
     */
    public boolean updateJunk(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//Mail[@MailID='" + _mailID + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Node contact = (Node) result;
            for (Node childnode = contact.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
                if (childnode.getNodeName().equals("junk")) {
                    childnode.setTextContent(_junk);
                }
            }

            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (XPathExpressionException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * delete mail
     * @param strTenTapTin
     * @return
     */
    public boolean delete(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//Mail[@MailID='" + _mailID + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Node contact = (Node) result;

            TaiLieu.getDocumentElement().removeChild(contact);

            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (XPathExpressionException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * delete mail
     * @param strTenTapTin
     * @return
     */
    public boolean deleteMailByUserID(String strTenTapTin, int userID) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//Mail[@UserID='" + userID + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODESET);
            NodeList mails = (NodeList) result;

            for (int i = 0; i < mails.getLength(); i++) {
                Node Nut = mails.item(i);
                if (Nut instanceof Element) {
                    TaiLieu.getDocumentElement().removeChild(Nut);
                }
            }

            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (XPathExpressionException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * @return the _from
     */
    public String getFrom() {
        return _from;
    }

    /**
     * @param from the _from to set
     */
    public void setFrom(String from) {
        this._from = from;
    }

    /**
     * @return the _to
     */
    public ArrayList<String> getTo() {
        return _to;
    }

    /**
     * @param to the _to to set
     */
    public void setTo(ArrayList<String> to) {
        this._to = to;
    }

    /**
     * @return the _cc
     */
    public ArrayList<String> getCc() {
        return _cc;
    }

    /**
     * @param cc the _cc to set
     */
    public void setCc(ArrayList<String> cc) {
        this._cc = cc;
    }

    /**
     * @return the _placeStore
     */
    public String getPlaceStore() {
        return _placeStore;
    }

    /**
     * @param placeStore the _placeStore to set
     */
    public void setPlaceStore(String placeStore) {
        this._placeStore = placeStore;
    }

    /**
     * @return the _tag
     */
    public String getTag() {
        return _tag;
    }

    /**
     * @param tag the _tag to set
     */
    public void setTag(String tag) {
        this._tag = tag;
    }

    /**
     * @return the _star
     */
    public String getStar() {
        return _star;
    }

    /**
     * @param star the _star to set
     */
    public void setStar(String star) {
        this._star = star;
    }

    /**
     * @return the _junk
     */
    public String getJunk() {
        return _junk;
    }

    /**
     * @param junk the _junk to set
     */
    public void setJunk(String junk) {
        this._junk = junk;
    }
}
