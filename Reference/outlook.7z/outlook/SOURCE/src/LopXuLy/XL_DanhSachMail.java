/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LopXuLy;

import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Vector;
import java.util.jar.Attributes.Name;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.*;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

/**
 *
 * @author letuan
 */
public class XL_DanhSachMail {

    private ArrayList<XL_Mail> _danhSachMail = new ArrayList<XL_Mail>();

    /**
     * lay id cua phan tu cuoi cung
     * @param tenTapTin
     * @return
     */
    public static int layIDMail(String tenTapTin) {
        int num = 0;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder;
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(tenTapTin));
            Element Goc = TaiLieu.getDocumentElement();
            NodeList list = Goc.getChildNodes();

            Node nodeCuoi = null;
            for (int i = 0; i < list.getLength(); i++) {
                Node Nut = list.item(i);
                if (Nut instanceof Element) {
                    nodeCuoi = Nut;
                }
            }
            if (nodeCuoi == null) {
                return 0;
            } else {
                num = Integer.parseInt(((Element) nodeCuoi).getAttribute("MailID"));
            }
        } catch (SAXException ex) {
            Logger.getLogger(XL_DanhSachContact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(XL_DanhSachContact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(XL_DanhSachContact.class.getName()).log(Level.SEVERE, null, ex);
        }
        return num;
    }

    /**
     * lay danh sach cac mail ung voi userid
     * @param tenTapTin
     * @param userID
     * @return
     * @throws javax.xml.xpath.XPathExpressionException
     */
    public boolean DocDanhSachMailByUserID(String tenTapTin, int userID) throws XPathExpressionException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(tenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//Mail[@UserID='" + userID + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODESET);
            NodeList list = (NodeList) result;

            for (int i = 0; i < list.getLength(); i++) {
                Node Nut = list.item(i);
                if (Nut instanceof Element) {
                    Element elem = ((Element) Nut);
                    XL_Mail mail = new XL_Mail(elem);
                    _danhSachMail.add(mail);
                }
            }
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * lay danh sach cac mail
     * @param tenTapTin
     * @param userID
     * @return
     * @throws javax.xml.xpath.XPathExpressionException
     */
    public boolean Doc(String tenTapTin) throws XPathExpressionException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(tenTapTin));
            Element Goc = TaiLieu.getDocumentElement();

            NodeList list = Goc.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                Node Nut = list.item(i);
                if (Nut instanceof Element) {
                    Element elem = ((Element) Nut);
                    XL_Mail mail = new XL_Mail(elem);
                    _danhSachMail.add(mail);
                }
            }
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    private ArrayList<Node> listTemp = new ArrayList<Node>();

    /**
     * danh sach mail tim kiem duoc
     * @param strTenTapTin
     * @param dsParten
     * @return
     */
    public boolean dsSearchMail(String strTenTapTin, ArrayList<Vector> dsParten) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = null;
            NodeList list1 = null;
            if (!dsParten.get(0).get(1).equals("")) {
                if (dsParten.get(0).get(0).equals("contains")) {
                    expr = xpath.compile("//Mail[./Subject[contains(.,'" + dsParten.get(0).get(1) + "')]]");
                } else if (dsParten.get(0).get(0).equals("is")) {
                    expr = xpath.compile(("//Mail[./Subject/text()='" + dsParten.get(0).get(1) + "']"));
                }
                Object result = expr.evaluate(TaiLieu, XPathConstants.NODESET);
                list1 = (NodeList) result;
            }

            NodeList list2 = null;
            if (!dsParten.get(1).get(1).equals("")) {
                if (dsParten.get(1).get(0).equals("contains")) {
                    expr = xpath.compile("//Mail[./From[contains(.,'" + dsParten.get(1).get(1) + "')]]");
                } else if (dsParten.get(1).get(0).equals("is")) {
                    expr = xpath.compile(("//Mail[./From/text()='" + dsParten.get(1).get(1) + "']"));
                }
                Object result = expr.evaluate(TaiLieu, XPathConstants.NODESET);
                list2 = (NodeList) result;
            }

            NodeList list3 = null;
            if (!dsParten.get(2).get(1).equals("")) {
                if (dsParten.get(2).get(0).equals("contains")) {
                    expr = xpath.compile("//Mail[./Body[contains(.,'" + dsParten.get(2).get(1) + "')]]");
                } else if (dsParten.get(2).get(0).equals("is")) {
                    expr = xpath.compile(("//Mail[./Body/text()='" + dsParten.get(2).get(1) + "']"));
                }
                Object result = expr.evaluate(TaiLieu, XPathConstants.NODESET);
                list3 = (NodeList) result;
            }

            layPhanChung3(list1, list2, list3);

            for (int i = 0; i < listChung.size(); i++) {
                Element elem = (Element) listChung.get(i);
                XL_Mail mail = new XL_Mail(elem);
                _danhSachMail.add(mail);
            }

        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        } catch (XPathExpressionException ex) {
            return false;
        }
        return true;
    }

    /**
     * lay phan tu chung cua 3 list
     * @param list1
     * @param list2
     * @param list3
     */
    public void layPhanChung3(NodeList list1, NodeList list2, NodeList list3) {
        layPhanChung2List(list1, list2);
        layPhanChungEnd(listTemp, list3);
    }

     private ArrayList<Node> listChung = new ArrayList<Node>();
    public void layPhanChungEnd(ArrayList<Node> listTemp, NodeList list) {
        if (list == null) {
            listChung = listTemp;
            return;
        } else if (listTemp.size() == 0) {
            for (int i = 0; i < list.getLength(); i++) {
                Node Nut = list.item(i);
                if (Nut instanceof Element) {
                    listChung.add(Nut);
                }
            }
        } else {
            for (int i = 0; i < list.getLength(); i++) {
                Node Nut = list.item(i);
                if (Nut instanceof Element) {
                    if (coXuatHienTrongArray(Nut, listTemp)) {
                        listChung.add(Nut);
                    }
                }

            }
        }
    }

    public boolean coXuatHienTrongArray(Node node, ArrayList<Node> arr) {
        for (int i = 0; i < arr.size(); i++) {
            Node Nut = arr.get(i);
            if (Nut == node) {
                return true;
            }
        }
        return false;
    }

    public void layPhanChung2List(NodeList list1, NodeList list2) {
        if(list1 == null && list2 == null){
            return;
        }
        if (list1 == null && list2 != null) {
            for (int i = 0; i < list2.getLength(); i++) {
                Node Nut = list2.item(i);
                if (Nut instanceof Element) {
                    listTemp.add(Nut);
                }
            }
        } else if (list1 != null && list2 == null) {
            for (int i = 0; i < list1.getLength(); i++) {
                Node Nut = list1.item(i);
                if (Nut instanceof Element) {
                    listTemp.add(Nut);
                }
            }
        } else {
            for (int i = 0; i < list1.getLength(); i++) {
                Node Nut = list1.item(i);
                if (Nut instanceof Element) {
                    if (coXuatHien(Nut, list2)) {
                        listTemp.add(Nut);
                    }
                }
            }
        }
    }

    public boolean coXuatHien(Node node, NodeList list) {
        if (list == null) {
            return true;
        }
        for (int i = 0; i < list.getLength(); i++) {
            Node Nut = list.item(i);
            if (Nut instanceof Element) {
                if (Nut == node) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * @return the _danhSachMail
     */
    public ArrayList<XL_Mail> getDanhSachMail() {
        return _danhSachMail;
    }

    /**
     * @param danhSachMail the _danhSachMail to set
     */
    public void setDanhSachMail(ArrayList<XL_Mail> danhSachMail) {
        this._danhSachMail = danhSachMail;
    }
}
