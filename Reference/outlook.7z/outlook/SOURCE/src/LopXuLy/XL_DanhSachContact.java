/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LopXuLy;

import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

/**
 *
 * @author letuan
 */
public class XL_DanhSachContact {

    private ArrayList<XL_Contact> _DanhSachContact = new ArrayList<XL_Contact>();

    /**
     * @return the _DanhSachContact
     */
    public ArrayList<XL_Contact> getDanhSachContact() {
        return _DanhSachContact;
    }

    /**
     * @param DanhSachContact the _DanhSachContact to set
     */
    public void setDanhSachContact(ArrayList<XL_Contact> DanhSachContact) {
        this._DanhSachContact = DanhSachContact;
    }

    /**
     * lay id cua phan tu cuoi cung
     * @param tenTapTin
     * @return
     */
    public static int layIDContact(String tenTapTin) {
        int num = 0;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder;
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(tenTapTin));
            Element Goc = TaiLieu.getDocumentElement();
            NodeList list = Goc.getChildNodes();

            Node nodeCuoi = null;
            for (int i = 0; i < list.getLength(); i++) {
                Node Nut = list.item(i);
                if (Nut instanceof Element) {
                    nodeCuoi = Nut;
                }
            }
            if (nodeCuoi == null) {
                return 0;
            } else {
                return Integer.parseInt(((Element) nodeCuoi).getAttribute("contactid"));
            }
        } catch (SAXException ex) {
            Logger.getLogger(XL_DanhSachContact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(XL_DanhSachContact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(XL_DanhSachContact.class.getName()).log(Level.SEVERE, null, ex);
        }
        return num;
    }

    /**
     * doc danh sach contact
     * @param strTenTapTin
     * @return
     */
    public boolean Doc(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));
            Element Goc = TaiLieu.getDocumentElement();
            NodeList list = Goc.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                Node Nut = list.item(i);
                if (Nut instanceof Element) {
                    Element elem = ((Element) Nut);
                    XL_Contact contact = new XL_Contact(elem);
                    _DanhSachContact.add(contact);
                }
            }
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * danh sach contact tim kiem
     * @param strTenTapTin
     * @param contactParten
     * @return
     */
    public boolean dsSearchContact(String strTenTapTin, XL_Contact contactParten) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));
            Element Goc = TaiLieu.getDocumentElement();
            NodeList list = Goc.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                Node Nut = list.item(i);
                if (Nut instanceof Element) {
                    Element elem = ((Element) Nut);
                    XL_Contact contact = new XL_Contact(elem);
                    if(compareContact(contact, contactParten))
                    _DanhSachContact.add(contact);
                }
            }
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * So sanh contact voi contact parten
     * @param contact
     * @param contactParten
     * @return
     */
    public boolean compareContact(XL_Contact contact, XL_Contact contactParten) {
        Vector a;
        ArrayList<Vector> dsCont = new ArrayList<Vector>();
        if (!contactParten.getFullName().equals("")) {
            a = new Vector();
            a.add("fullname");
            a.add(contactParten.getFullName());
            dsCont.add(a);
        }
        if (!contactParten.getBusinessPhone().equals("")) {
            a = new Vector();
            a.add("business");
            a.add(contactParten.getBusinessPhone());
            dsCont.add(a);
        }
        if (!contactParten.getCompany().equals("")) {
            a = new Vector();
            a.add("company");
            a.add(contactParten.getCompany());
            dsCont.add(a);
        }
        if (!contactParten.getEmail().equals("")) {
            a = new Vector();
            a.add("email");
            a.add(contactParten.getEmail());
            dsCont.add(a);
        }
        if (!contactParten.getMobilePhone().equals("")) {
            a = new Vector();
            a.add("mobile");
            a.add(contactParten.getMobilePhone());
            dsCont.add(a);
        }
        if (!contactParten.getCategory().equals("")) {
            a = new Vector();
            a.add("category");
            a.add(contactParten.getCategory());
            dsCont.add(a);
        }
        ////////////////////////////////
        for (int i = 0; i < dsCont.size(); i++) {
            if (dsCont.get(i).get(0).equals("fullname")) {
                if (!dsCont.get(i).get(1).equals(contact.getFullName())) {
                    return false;
                }
            } else if (dsCont.get(i).get(0).equals("business")) {
                if (!dsCont.get(i).get(1).equals(contact.getBusinessPhone())) {
                    return false;
                }
            }else if (dsCont.get(i).get(0).equals("company")) {
                if (!dsCont.get(i).get(1).equals(contact.getCompany())) {
                    return false;
                }
            }else if (dsCont.get(i).get(0).equals("email")) {
                if (!dsCont.get(i).get(1).equals(contact.getEmail())) {
                    return false;
                }
            }else if (dsCont.get(i).get(0).equals("mobile")) {
                if (!dsCont.get(i).get(1).equals(contact.getMobilePhone())) {
                    return false;
                }
            }else if (dsCont.get(i).get(0).equals("category")) {
                if (!dsCont.get(i).get(1).equals(contact.getCategory())) {
                    return false;
                }
            }
        }
        return true;
    }
}
