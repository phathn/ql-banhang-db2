/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LopXuLy;

import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

/**
 *
 * @author letuan
 */
public class XL_DanhSachAccount {

    private ArrayList<XL_Account> _DanhSachAccount = new ArrayList<XL_Account>();

    /**
     * @return the _DanhSachAccount
     */
    public ArrayList<XL_Account> getDanhSachAccount() {
        return _DanhSachAccount;
    }

    /**
     * @param DanhSachAccount the _DanhSachAccount to set
     */
    public void setDanhSachAccount(ArrayList<XL_Account> DanhSachAccount) {
        this._DanhSachAccount = DanhSachAccount;
    }

    /**
     * Lay id cua phan tu cuoi cung
     * @param tenTapTin
     * @return
     */
    public static int layIDAccount(String tenTapTin) {
        int num = 0;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder;
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(tenTapTin));
            Element Goc = TaiLieu.getDocumentElement();
            NodeList list = Goc.getChildNodes();

            Node nodeCuoi = null;
            for (int i = 0; i < list.getLength(); i++) {
                Node Nut = list.item(i);
                if (Nut instanceof Element) {
                    nodeCuoi = Nut;
                }
            }
            if(nodeCuoi == null){
                return 0;
            }else{
                num = Integer.parseInt(((Element)nodeCuoi).getAttribute("AccountID"));
            }
        } catch (SAXException ex) {
            Logger.getLogger(XL_DanhSachContact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(XL_DanhSachContact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(XL_DanhSachContact.class.getName()).log(Level.SEVERE, null, ex);
        }
        return num;
    }

    /**
     * doc danh sach account
     * @param strTenTapTin
     * @return
     */
    public boolean Doc(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));
            Element Goc = TaiLieu.getDocumentElement();
            NodeList list = Goc.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                Node Nut = list.item(i);
                if (Nut instanceof Element) {
                    Element elem = ((Element) Nut);
                    XL_Account account = new XL_Account(elem);
                    _DanhSachAccount.add(account);
                }
            }
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

}
