/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LopXuLy;

import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Vector;
import java.util.jar.Attributes.Name;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.*;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.*;
import org.xml.sax.SAXException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

/**
 *
 * @author letuan
 */
public class XL_CalendarTask {

    private String _ngay = "";
    private ArrayList<XL_CongViec> _danhSachCongViec = new ArrayList<XL_CongViec>();

    public XL_CalendarTask() {
    }

    /**
     * Constructors
     * @param Nut
     */
    public XL_CalendarTask(Element Nut) {
        this._ngay = Nut.getAttribute("ngay");

        for (Node childnode = Nut.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
            if (childnode.getNodeName().equals("congviec")) {
                XL_CongViec cv = new XL_CongViec((Element) childnode);
                _danhSachCongViec.add(cv);
            }
        }
    }

    /**
     * Doc cong viec ung voi lich ngay
     * @param strTenTapTin
     * @param Ngay
     * @return
     */
    public boolean Doc(String strTenTapTin, String Ngay) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder;
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));
            Element Goc = TaiLieu.getDocumentElement();

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//task[@ngay='" + Ngay + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Element task = (Element) result;
            if(task == null){
                return false;
            }
            for (Node childnode = task.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
                if (childnode.getNodeName().equals("congviec")) {
                    XL_CongViec cv=new XL_CongViec((Element)childnode);
                    _danhSachCongViec.add(cv);
                }
            }
        } catch (XPathExpressionException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        } catch (ParserConfigurationException ex) {
            return false;
        }
        return true;
    }

    /**
     * @return the _ngay
     */
    public String getNgay() {
        return _ngay;
    }

    /**
     * @param ngay the _ngay to set
     */
    public void setNgay(String ngay) {
        this._ngay = ngay;
    }

    /**
     * @return the _danhSachCongViec
     */
    public ArrayList<XL_CongViec> getDanhSachCongViec() {
        return _danhSachCongViec;
    }

    /**
     * @param danhSachCongViec the _danhSachCongViec to set
     */
    public void setDanhSachCongViec(ArrayList<XL_CongViec> danhSachCongViec) {
        this._danhSachCongViec = danhSachCongViec;
    }
}
