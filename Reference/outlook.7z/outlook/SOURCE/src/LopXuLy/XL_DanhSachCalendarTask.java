/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LopXuLy;

import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

/**
 *
 * @author letuan
 */
public class XL_DanhSachCalendarTask {

    private ArrayList<XL_CalendarTask> _DanhSachTask = new ArrayList<XL_CalendarTask>();

    /**
     * lay id cua task cuoi cung
     * @param tenTapTin
     * @return
     */
    public static int layIDTask(String tenTapTin) {
        int num = 0;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder;
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(tenTapTin));
            Element Goc = TaiLieu.getDocumentElement();
            NodeList list = Goc.getChildNodes();

            Node nodeCuoi = null;
            for (int i = 0; i < list.getLength(); i++) {
                Node Nut = list.item(i);
                if (Nut instanceof Element) {
                    nodeCuoi = Nut;
                }
            }
            if (nodeCuoi == null) {
                return 0;
            } else {
                return Integer.parseInt(((Element) nodeCuoi).getAttribute("contactid"));
            }
        } catch (SAXException ex) {
            Logger.getLogger(XL_DanhSachContact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(XL_DanhSachContact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(XL_DanhSachContact.class.getName()).log(Level.SEVERE, null, ex);
        }
        return num;
    }

    /**
     * doc danh sach task ung voi lichngay
     * @param strTenTapTin
     * @return
     */
    public boolean Doc(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));
            Element Goc = TaiLieu.getDocumentElement();
            NodeList list = Goc.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                Node Nut = list.item(i);
                if (Nut instanceof Element) {
                    Element elem = ((Element) Nut);
                    XL_CalendarTask task = new XL_CalendarTask(elem);
                    _DanhSachTask.add(task);
                }
            }
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }


    /**
     * @return the _DanhSachTask
     */
    public ArrayList<XL_CalendarTask> getDanhSachTask() {
        return _DanhSachTask;
    }

    /**
     * @param DanhSachTask the _DanhSachTask to set
     */
    public void setDanhSachTask(ArrayList<XL_CalendarTask> DanhSachTask) {
        this._DanhSachTask = DanhSachTask;
    }
}
