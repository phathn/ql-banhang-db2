/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LopXuLy;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

/**
 *
 * @author letuan
 */
public class XL_CongViec {

    private int _gio;
    private String _subject = "";
    private String _notes = "";
    private String _category = "";

    /**
     * @return the _gio
     */
    public int getGio() {
        return _gio;
    }

    /**
     * @param gio the _gio to set
     */
    public void setGio(int gio) {
        this._gio = gio;
    }

    /**
     * @return the _subject
     */
    public String getSubject() {
        return _subject;
    }

    /**
     * @param subject the _subject to set
     */
    public void setSubject(String subject) {
        this._subject = subject;
    }

    /**
     * @return the _notes
     */
    public String getNotes() {
        return _notes;
    }

    /**
     * @param notes the _notes to set
     */
    public void setNotes(String notes) {
        this._notes = notes;
    }

    /**
     * @return the _category
     */
    public String getCategory() {
        return _category;
    }

    /**
     * @param category the _category to set
     */
    public void setCategory(String category) {
        this._category = category;
    }

    /**
     * Constructor
     */
    public XL_CongViec() {
    }

    /**
     * Doc 1 cong viec ung voi lich ngay
     * @param strTenTapTin
     * @param Ngay
     * @return
     */
    public boolean Doc(String strTenTapTin, String Ngay) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder;
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));
            Element Goc = TaiLieu.getDocumentElement();

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//task[@ngay='" + Ngay + "']" + "/congviec[@gio='" + _gio + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Element task = (Element) result;
            if (task == null) {
                return false;
            }
            for (Node childnode = task.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
                if (childnode.getNodeName().equals("subject")) {
                    Text textNode = (Text) childnode.getFirstChild();
                    if (textNode != null) {
                        String content = textNode.getData();
                        this._subject = content;
                    }
                } else if (childnode.getNodeName().equals("category")) {
                    Text textNode = (Text) childnode.getFirstChild();
                    if (textNode != null) {
                        String content = textNode.getData();
                        this._category = content;
                    }
                } else if (childnode.getNodeName().equals("notes")) {
                    this._notes = childnode.getTextContent();
                }
            }
        } catch (XPathExpressionException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        } catch (ParserConfigurationException ex) {
            return false;
        }
        return true;
    }

    /**
     * Constructors
     * @param Nut
     */
    public XL_CongViec(Element Nut) {
        this._gio = Integer.parseInt(Nut.getAttribute("gio"));
        for (Node childnode = Nut.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
            if (childnode.getNodeName().equals("subject")) {
                Text textNode = (Text) childnode.getFirstChild();
                if (textNode != null) {
                    String content = textNode.getData();
                    this._subject = content;
                }
            } else if (childnode.getNodeName().equals("category")) {
                Text textNode = (Text) childnode.getFirstChild();
                if (textNode != null) {
                    String content = textNode.getData();
                    this._category = content;
                }
            } else if (childnode.getNodeName().equals("notes")) {
                this._notes = childnode.getTextContent();
            }
        }
    }

    /**
     * Luu cong viec moi theo lich ngay
     * @param strTenTapTin
     * @param Ngay
     * @return
     */
    public boolean Ghi(String strTenTapTin, String Ngay) {
        boolean newtask = false;
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));
            Element Goc = TaiLieu.getDocumentElement();

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//task[@ngay='" + Ngay + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Element task = (Element) result;

            if (task == null) {
                task = Goc.getOwnerDocument().createElement("task");
                task.setAttribute("ngay", Ngay);
                newtask = true;
            }

            Element congviec = task.getOwnerDocument().createElement("congviec");
            Element subject = congviec.getOwnerDocument().createElement("subject");
            Element notes = congviec.getOwnerDocument().createElement("notes");
            Element category = congviec.getOwnerDocument().createElement("category");

            subject.setTextContent(_subject);
            category.setTextContent(_category);
            CDATASection cdata = notes.getOwnerDocument().createCDATASection(_notes);
            notes.appendChild(cdata);
            congviec.setAttribute("gio", String.valueOf(_gio));

            congviec.appendChild(subject);
            congviec.appendChild(notes);
            congviec.appendChild(category);
            task.appendChild(congviec);
            if (newtask) {
                Goc.appendChild(task);
            }
            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (TransformerException ex) {
            return false;
        } catch (XPathExpressionException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        } catch (ParserConfigurationException ex) {
            return false;
        }
        return true;
    }

    /**
     * Cap nhat cong viec ung voi lich ngay
     * @param strTenTapTin
     * @param Ngay
     * @return
     */
    public boolean update(String strTenTapTin, String Ngay) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//task[@ngay='" + Ngay + "']" + "/congviec[@gio='" + _gio + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Element task = (Element) result;

             for (Node childnode = task.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
                if (childnode.getNodeName().equals("subject")) {
                    childnode.setTextContent(_subject);
                } else if (childnode.getNodeName().equals("category")) {
                    childnode.setTextContent(_category);
                } else if (childnode.getNodeName().equals("notes")) {
                    CDATASection cdata = childnode.getOwnerDocument().createCDATASection(_notes);
                    if (childnode.getFirstChild() == null) {
                        childnode.appendChild(cdata);
                    } else {
                        childnode.replaceChild(cdata, childnode.getFirstChild());
                    }
                }
            }

            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (TransformerException ex) {
            return false;
        } catch (XPathExpressionException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        } catch (ParserConfigurationException ex) {
            return false;
        }
        return true;
    }

    /**
     * Xoa bo cong viec ung voi lich ngay
     * @param strTenTapTin
     * @param Ngay
     * @return
     */
    public boolean delete(String strTenTapTin, String Ngay) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//task[@ngay='" + Ngay + "']" + "/congviec[@gio='" + _gio + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Node congviec = (Node) result;

            expr = xpath.compile("//task[@ngay='" + Ngay + "']");
            result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Node task = (Node) result;

            task.removeChild(congviec);

            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (XPathExpressionException ex) {
            return false;
        } catch (TransformerException ex) {
            return false;
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }
}
