/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LopXuLy;

import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Vector;
import java.util.jar.Attributes.Name;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.*;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.*;
import org.xml.sax.SAXException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

/**
 *
 * @author letuan
 */
public class XL_Contact {

    private int _contactID;
    private String _fullName = "";
    private String _jobTitle = "";
    private String _company = "";
    private String _email = "";
    private String _displayas = "";
    private String _webpage = "";
    private String _businessPhone = "";
    private String _homePhone = "";
    private String _mobilePhone = "";
    private String _address = "";
    private String _notes = "";
    private String _category = "";

    /**
     * @return the _contactID
     */
    public int getContactID() {
        return _contactID;
    }

    /**
     * @param contactID the _contactID to set
     */
    public void setContactID(int contactID) {
        this._contactID = contactID;
    }

    /**
     * @return the _fullName
     */
    public String getFullName() {
        return _fullName;
    }

    /**
     * @param fullName the _fullName to set
     */
    public void setFullName(String fullName) {
        this._fullName = fullName;
    }

    /**
     * @return the _jobTitle
     */
    public String getJobTitle() {
        return _jobTitle;
    }

    /**
     * @param jobTitle the _jobTitle to set
     */
    public void setJobTitle(String jobTitle) {
        this._jobTitle = jobTitle;
    }

    /**
     * @return the _company
     */
    public String getCompany() {
        return _company;
    }

    /**
     * @param company the _company to set
     */
    public void setCompany(String company) {
        this._company = company;
    }

    /**
     * @return the _email
     */
    public String getEmail() {
        return _email;
    }

    /**
     * @param email the _email to set
     */
    public void setEmail(String email) {
        this._email = email;
    }

    /**
     * @return the _displayas
     */
    public String getDisplayas() {
        return _displayas;
    }

    /**
     * @param displayas the _displayas to set
     */
    public void setDisplayas(String displayas) {
        this._displayas = displayas;
    }

    /**
     * @return the _webpage
     */
    public String getWebpage() {
        return _webpage;
    }

    /**
     * @param webpage the _webpage to set
     */
    public void setWebpage(String webpage) {
        this._webpage = webpage;
    }

    /**
     * @return the _businessPhone
     */
    public String getBusinessPhone() {
        return _businessPhone;
    }

    /**
     * @param businessPhone the _businessPhone to set
     */
    public void setBusinessPhone(String businessPhone) {
        this._businessPhone = businessPhone;
    }

    /**
     * @return the _homePhone
     */
    public String getHomePhone() {
        return _homePhone;
    }

    /**
     * @param homePhone the _homePhone to set
     */
    public void setHomePhone(String homePhone) {
        this._homePhone = homePhone;
    }

    /**
     * @return the _mobilePhone
     */
    public String getMobilePhone() {
        return _mobilePhone;
    }

    /**
     * @param mobilePhone the _mobilePhone to set
     */
    public void setMobilePhone(String mobilePhone) {
        this._mobilePhone = mobilePhone;
    }

    /**
     * @return the _address
     */
    public String getAddress() {
        return _address;
    }

    /**
     * @param address the _address to set
     */
    public void setAddress(String address) {
        this._address = address;
    }

    /**
     * @return the _notes
     */
    public String getNotes() {
        return _notes;
    }

    /**
     * @param notes the _notes to set
     */
    public void setNotes(String notes) {
        this._notes = notes;
    }

    public XL_Contact() {
    }

    /**
     * Constructors
     * @param Nut
     */
    public XL_Contact(Element Nut) {
        this._contactID = Integer.parseInt(Nut.getAttribute("contactid"));

        for (Node childnode = Nut.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
            if (childnode.getNodeName().equals("personal")) {
                for (Node child = childnode.getFirstChild(); child != null; child = child.getNextSibling()) {
                    Text textNode = (Text) child.getFirstChild();
                    if (textNode != null) {
                        if (child.getNodeName().equals("fullname")) {
                            String content = textNode.getData();
                            this._fullName = content;
                        } else if (child.getNodeName().equals("jobtitle")) {
                            String content = textNode.getData();
                            this._jobTitle = content;
                        } else if (child.getNodeName().equals("company")) {
                            String content = textNode.getData();
                            this._company = content;
                        } else if (child.getNodeName().equals("email")) {
                            String content = textNode.getData();
                            this._email = content;
                        } else if (child.getNodeName().equals("displayas")) {
                            String content = textNode.getData();
                            this._displayas = content;
                        } else if (child.getNodeName().equals("webpage")) {
                            String content = textNode.getData();
                            this._webpage = content;
                        }
                    }
                }
            } else if (childnode.getNodeName().equals("phone")) {
                for (Node child = childnode.getFirstChild(); child != null; child = child.getNextSibling()) {
                    Text textNode = (Text) child.getFirstChild();
                    if (textNode != null) {
                        if (child.getNodeName().equals("business")) {
                            String content = textNode.getData();
                            this._businessPhone = content;
                        } else if (child.getNodeName().equals("home")) {
                            String content = textNode.getData();
                            this._homePhone = content;
                        } else if (child.getNodeName().equals("mobile")) {
                            String content = textNode.getData();
                            this._mobilePhone = content;
                        }
                    }
                }
            } else if (childnode.getNodeName().equals("address")) {
                Text textNode = (Text) childnode.getFirstChild();
                if (textNode != null) {
                    String content = textNode.getData();
                    this._address = content;
                }
            } else if (childnode.getNodeName().equals("notes")) {
                this._notes = childnode.getTextContent();
            } else if (childnode.getNodeName().equals("category")) {
                Text textNode = (Text) childnode.getFirstChild();
                if (textNode != null) {
                    String content = textNode.getData();
                    this._category = content;
                }
            }
        }
    }

    /**
     * Cap nhatthong tin contact
     * @param strTenTapTin
     * @return
     */
    public boolean update(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//contact[@contactid='" + _contactID + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Node contact = (Node) result;

            for (Node childnode = contact.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
                if (childnode.getNodeName().equals("personal")) {
                    for (Node child = childnode.getFirstChild(); child != null; child = child.getNextSibling()) {
                        if (child.getNodeName().equals("fullname")) {
                            child.setTextContent(_fullName);
                        } else if (child.getNodeName().equals("jobtitle")) {
                            child.setTextContent(_jobTitle);
                        } else if (child.getNodeName().equals("company")) {
                            child.setTextContent(_company);
                        } else if (child.getNodeName().equals("email")) {
                            child.setTextContent(_email);
                        } else if (child.getNodeName().equals("displayas")) {
                            child.setTextContent(_displayas);
                        } else if (child.getNodeName().equals("webpage")) {
                            child.setTextContent(_webpage);
                        }
                    }
                } else if (childnode.getNodeName().equals("phone")) {
                    for (Node child = childnode.getFirstChild(); child != null; child = child.getNextSibling()) {
                        if (child.getNodeName().equals("home")) {
                            child.setTextContent(_homePhone);
                        } else if (child.getNodeName().equals("business")) {
                            child.setTextContent(_businessPhone);
                        } else if (child.getNodeName().equals("mobile")) {
                            child.setTextContent(_mobilePhone);
                        }
                    }
                } else if (childnode.getNodeName().equals("address")) {
                    childnode.setTextContent(_address);
                } else if (childnode.getNodeName().equals("notes")) {
                    CDATASection cdata = childnode.getOwnerDocument().createCDATASection(_notes);
                    if (childnode.getFirstChild() == null) {
                        childnode.appendChild(cdata);
                    } else {
                        childnode.replaceChild(cdata, childnode.getFirstChild());
                    }
                } else if (childnode.getNodeName().equals("category")) {
                    childnode.setTextContent(_category);
                }
            }
            /*XMLSerializer serializer = new XMLSerializer();
            serializer.setOutputCharStream(new FileWriter(strTenTapTin));
            serializer.serialize(TaiLieu);*/

            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (XPathExpressionException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * Select contact tu id
     * @param strTenTapTin
     * @param contactid
     * @return
     */
    public boolean selectContactByID(String strTenTapTin, int contactid) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//contact[@contactid='" + contactid + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Node Nut = (Node) result;

            _contactID = contactid;
            for (Node childnode = Nut.getFirstChild(); childnode != null; childnode = childnode.getNextSibling()) {
                if (childnode.getNodeName().equals("personal")) {
                    for (Node child = childnode.getFirstChild(); child != null; child = child.getNextSibling()) {
                        Text textNode = (Text) child.getFirstChild();
                        if (textNode != null) {
                            if (child.getNodeName().equals("fullname")) {
                                String content = textNode.getData();
                                this._fullName = content;
                            } else if (child.getNodeName().equals("jobtitle")) {
                                String content = textNode.getData();
                                this._jobTitle = content;
                            } else if (child.getNodeName().equals("company")) {
                                String content = textNode.getData();
                                this._company = content;
                            } else if (child.getNodeName().equals("email")) {
                                String content = textNode.getData();
                                this._email = content;
                            } else if (child.getNodeName().equals("displayas")) {
                                String content = textNode.getData();
                                this._displayas = content;
                            } else if (child.getNodeName().equals("webpage")) {
                                String content = textNode.getData();
                                this._webpage = content;
                            }
                        }
                    }
                } else if (childnode.getNodeName().equals("phone")) {
                    for (Node child = childnode.getFirstChild(); child != null; child = child.getNextSibling()) {
                        Text textNode = (Text) child.getFirstChild();
                        if (textNode != null) {
                            if (child.getNodeName().equals("business")) {
                                String content = textNode.getData();
                                this._businessPhone = content;
                            } else if (child.getNodeName().equals("home")) {
                                String content = textNode.getData();
                                this._homePhone = content;
                            } else if (child.getNodeName().equals("mobile")) {
                                String content = textNode.getData();
                                this._mobilePhone = content;
                            }
                        }
                    }
                } else if (childnode.getNodeName().equals("address")) {
                    Text textNode = (Text) childnode.getFirstChild();
                    if (textNode != null) {
                        String content = textNode.getData();
                        this._address = content;
                    }
                } else if (childnode.getNodeName().equals("notes")) {
                    this._notes = childnode.getTextContent();
                } else if (childnode.getNodeName().equals("category")) {
                    Text textNode = (Text) childnode.getFirstChild();
                    if (textNode != null) {
                        String content = textNode.getData();
                        this._category = content;
                    }
                }
            }
        } catch (XPathExpressionException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * Xoa bo contact
     * @param strTenTapTin
     * @return
     */
    public boolean delete(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//contact[@contactid='" + _contactID + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Node contact = (Node) result;

            TaiLieu.getDocumentElement().removeChild(contact);

            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (XPathExpressionException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * ghi Contact moi
     * @param strTenTapTin
     * @return
     */
    public boolean Ghi(String strTenTapTin) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));
            Element Goc = TaiLieu.getDocumentElement();
            Element contact = Goc.getOwnerDocument().createElement("contact");
            //tao cac the con cua the Account
            Element personal = contact.getOwnerDocument().createElement("personal");
            Element phone = contact.getOwnerDocument().createElement("phone");
            Element address = contact.getOwnerDocument().createElement("address");
            Element notes = contact.getOwnerDocument().createElement("notes");
            Element category = contact.getOwnerDocument().createElement("category");
            //tao cac the con cua the server
            Element fullname = personal.getOwnerDocument().createElement("fullname");
            Element jobtitle = personal.getOwnerDocument().createElement("jobtitle");
            Element company = personal.getOwnerDocument().createElement("company");
            Element email = personal.getOwnerDocument().createElement("email");
            Element displayas = personal.getOwnerDocument().createElement("displayas");
            Element webpage = personal.getOwnerDocument().createElement("webpage");

            Element business = phone.getOwnerDocument().createElement("business");
            Element home = phone.getOwnerDocument().createElement("home");
            Element mobile = phone.getOwnerDocument().createElement("mobile");

            //khoi tao noi dung cho cac the
            fullname.setTextContent(this._fullName);
            jobtitle.setTextContent(_jobTitle);
            company.setTextContent(this._company);
            email.setTextContent(_email);
            displayas.setTextContent(this._displayas);
            webpage.setTextContent(_webpage);

            business.setTextContent(_businessPhone);
            home.setTextContent(this._homePhone);
            mobile.setTextContent(_mobilePhone);

            address.setTextContent(_address);
            category.setTextContent(_category);

            CDATASection cdata = notes.getOwnerDocument().createCDATASection(_notes);
            notes.appendChild(cdata);

            //dua noi dung vao cac the
            personal.appendChild(fullname);
            personal.appendChild(jobtitle);
            personal.appendChild(company);
            personal.appendChild(email);
            personal.appendChild(displayas);
            personal.appendChild(webpage);

            phone.appendChild(home);
            phone.appendChild(business);
            phone.appendChild(mobile);

            contact.setAttribute("contactid", String.valueOf(_contactID));
            contact.appendChild(personal);
            contact.appendChild(phone);
            contact.appendChild(address);
            contact.appendChild(notes);
            contact.appendChild(category);

            Goc.appendChild(contact);

            /*XMLSerializer serializer = new XMLSerializer();
            serializer.setOutputCharStream(new FileWriter(strTenTapTin));
            serializer.serialize(TaiLieu);*/
            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (TransformerException ex) {
            Logger.getLogger(XL_Contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    /**
     * @return the _category
     */
    public String getCategory() {
        return _category;
    }

    /**
     * @param category the _category to set
     */
    public void setCategory(String category) {
        this._category = category;
    }
}
