/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LopXuLy;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

/**
 *
 * @author letuan
 */
public class XL_CongViecMonthTask {

    private int _stt;
    private String _congviec;

    /**
     * @return the _stt
     */
    public int getStt() {
        return _stt;
    }

    /**
     * @param stt the _stt to set
     */
    public void setStt(int stt) {
        this._stt = stt;
    }

    /**
     * @return the _congviec
     */
    public String getCongviec() {
        return _congviec;
    }

    /**
     * @param congviec the _congviec to set
     */
    public void setCongviec(String congviec) {
        this._congviec = congviec;
    }

    public XL_CongViecMonthTask() {
    }

    /**
     * Constructor
     * @param Nut
     */
    public XL_CongViecMonthTask(Element Nut) {
        _stt = Integer.parseInt(Nut.getAttribute("stt"));
        Text textNode = (Text) Nut.getFirstChild();
        if (textNode != null) {
            String content = textNode.getData();
            _congviec = content;
        }
    }

    /**
     * doc cong viec ung voi lich thang
     * @param strTenTapTin
     * @param Ngay
     * @return
     */
    public boolean Doc(String strTenTapTin, String Ngay) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder;
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));
            Element Goc = TaiLieu.getDocumentElement();

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//task[@ngay='" + Ngay + "']" + "/congviec[@stt='" + _stt + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Element task = (Element) result;
            if (task == null) {
                return false;
            }
            Text textNode = (Text) task.getFirstChild();
            if (textNode != null) {
                String content = textNode.getData();
                this._congviec = content;
            }
        } catch (XPathExpressionException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        } catch (ParserConfigurationException ex) {
            return false;
        }
        return true;
    }

    /**
     * Luu cong viectheo lich tahng
     * @param strTenTapTin
     * @param Ngay
     * @return
     */
    public boolean Ghi(String strTenTapTin, String Ngay) {
        boolean newtask = false;
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));
            Element Goc = TaiLieu.getDocumentElement();

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//task[@ngay='" + Ngay + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Element task = (Element) result;

            if (task == null) {
                task = Goc.getOwnerDocument().createElement("task");
                task.setAttribute("ngay", Ngay);
                newtask = true;
            }

            Element congviec = task.getOwnerDocument().createElement("congviec");

            congviec.setTextContent(_congviec);
            congviec.setAttribute("stt", String.valueOf(_stt));

            task.appendChild(congviec);
            if (newtask) {
                Goc.appendChild(task);
            }
            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (TransformerException ex) {
            return false;
        } catch (XPathExpressionException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        } catch (ParserConfigurationException ex) {
            return false;
        }
        return true;
    }

    /**
     * Cap nhatcong viec ung voi lich thang
     * @param strTenTapTin
     * @param Ngay
     * @return
     */
    public boolean update(String strTenTapTin, String Ngay) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//task[@ngay='" + Ngay + "']" + "/congviec[@stt='" + _stt + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Element task = (Element) result;
            task.setTextContent(_congviec);

            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (TransformerException ex) {
            return false;
        } catch (XPathExpressionException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        } catch (ParserConfigurationException ex) {
            return false;
        }
        return true;
    }

    /**
     * Xoa cong viec ung voi lich thang
     * @param strTenTapTin
     * @param Ngay
     * @return
     */
    public boolean delete(String strTenTapTin, String Ngay) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(strTenTapTin));

            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath xpath = xpfactory.newXPath();
            XPathExpression expr = xpath.compile("//task[@ngay='" + Ngay + "']" + "/congviec[@stt='" + _stt + "']");
            Object result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Node congviec = (Node) result;

            expr = xpath.compile("//task[@ngay='" + Ngay + "']");
            result = expr.evaluate(TaiLieu, XPathConstants.NODE);
            Node task = (Node) result;

            task.removeChild(congviec);

            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(TaiLieu), new StreamResult(new FileOutputStream(strTenTapTin)));
        } catch (XPathExpressionException ex) {
            return false;
        } catch (TransformerException ex) {
            return false;
        } catch (ParserConfigurationException ex) {
            return false;
        } catch (SAXException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        }
        return true;
    }
}
