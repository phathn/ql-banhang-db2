/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package LopXuLy;

import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;
/**
 *
 * @author letuan
 */
public class XL_DanhSachMailDaGui {
    private ArrayList<XL_MailDaGui> _DanhSachMailDaGui=new ArrayList<XL_MailDaGui>();

    /**
     * doc danh sach mail da gui de thuc hien autocomplete
     * @param tenTapTin
     * @return
     */
    public boolean Doc(String tenTapTin){
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            Document TaiLieu = builder.parse(new File(tenTapTin));
            Element Goc = TaiLieu.getDocumentElement();
            NodeList list = Goc.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                Node Nut = list.item(i);
                if (Nut instanceof Element) {
                    Element elem = ((Element) Nut);
                    XL_MailDaGui mail = new XL_MailDaGui(elem);
                    getDanhSachMailDaGui().add(mail);
                }
            }
        } catch (SAXException ex) {
            Logger.getLogger(XL_DanhSachMailDaGui.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(XL_DanhSachMailDaGui.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(XL_DanhSachMailDaGui.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    /**
     * @return the _DanhSachMailDaGui
     */
    public ArrayList<XL_MailDaGui> getDanhSachMailDaGui() {
        return _DanhSachMailDaGui;
    }

    /**
     * @param DanhSachMailDaGui the _DanhSachMailDaGui to set
     */
    public void setDanhSachMailDaGui(ArrayList<XL_MailDaGui> DanhSachMailDaGui) {
        this._DanhSachMailDaGui = DanhSachMailDaGui;
    }


}
