/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyTable;

import java.awt.Color;
import java.awt.Component;
import java.awt.SystemColor;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author letuan
 */
public class MyImageHeaderRenderer extends DefaultTableCellRenderer {

    private String tooltip;

    public MyImageHeaderRenderer(String text) {
        super();
        tooltip = text;
    }

    public Component getTableCellRendererComponent(JTable table,
            Object obj, boolean isSelected, boolean hasFocus, int row, int column) {
        txtIcon i = (txtIcon) obj;
        if (obj == i) {
            setIcon(i.imageIcon);
        }
        setBorder(UIManager.getBorder("TableHeader.cellBorder"));
        setHorizontalAlignment(JLabel.CENTER);
        setToolTipText(tooltip);
        return this;
    }
}

