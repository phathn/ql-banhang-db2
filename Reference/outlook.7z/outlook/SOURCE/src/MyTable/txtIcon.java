/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package MyTable;

import javax.swing.ImageIcon;

/**
 *
 * @author letuan
 */
public class txtIcon {

    ImageIcon imageIcon;

    txtIcon(ImageIcon icon) {
        imageIcon = icon;
    }
}