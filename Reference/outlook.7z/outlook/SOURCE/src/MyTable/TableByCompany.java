/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyTable;

import BienDungChung.GlobalVariables;
import LopXuLy.XL_DanhSachAccount;
import LopXuLy.XL_DanhSachContact;
import LopXuLy.XL_DanhSachMail;
import LopXuLy.XL_Mail;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.io.File;
import java.lang.reflect.Array;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Random;
import java.util.Vector;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

/**
 *
 * @author letuan
 */
public class TableByCompany {

    private static Vector<String> arrCol = new Vector<String>(3);
    //mang chua du lieu cac dong
    private static Vector<Object> arrRow;
    //mang luu giu ten cac cot
    private static String[] columnNames;
    private static int PREFERRED_SIZE = 12;
    private static Color whiteSmoke = new Color(245, 245, 245);

    public static void sortAllRowsByCompany(DefaultTableModel model, int colIndex, boolean ascending) {
        Vector data = model.getDataVector();
        Collections.sort(data, new ColumnSorterByCategory(colIndex, ascending));
        model.fireTableStructureChanged();
    }

    public static void loadFolderIntoTableCompany(JTable table, XL_DanhSachContact dsContact) {
        table.setRowHeight(18);
        arrCol = new Vector<String>();
        columnNames = new String[]{"", "FullName", "Company", "Display As", "Categories", "Mobile phone", "Business phone"};
        for (String strNameCol : columnNames) {
            arrCol.add(strNameCol);
        }

        addElementIntoTableCompany(dsContact);
        //them dong, cot
        MyTableModel model = new MyTableModel(arrRow, arrCol, false);
        table.setModel(model);
        //thuc hien sort column theo tung loai (thu muc, file)
        //thu muc tang tu tren xuong duoi
        //sau do den file tang tu tren xuong duoi
        table.setAutoCreateColumnsFromModel(false);
        sortAllRowsByCompany(model, 2, true);
        ///////////////
        editTableCompany(table);
    }

    /**
     * Đưa các files/folders con của file ứng với đường dẫn path1
     * vào 1 table theo kiểu full screen
     * @param path1: đường dẫn chứa files/folders cần load
     */
    public static void addElementIntoTableCompany(XL_DanhSachContact dsContact) {
        //arraylsit chua tat cac cac file tuong ung voi thu muc
        //co duong dan strTempPathLeft
        arrRow = new Vector<Object>();
        /////////////////
        for (int i = 0; i < dsContact.getDanhSachContact().size(); i++) {
            JLabel lb = new JLabel();
            String pathImages;
            pathImages = System.getProperty("user.dir") + File.separator +
                    "images_tree/vcard.png";

            ImageIcon imageIcon = new ImageIcon(pathImages);
            if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
                imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                        PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
            }

            lb.setIcon(imageIcon);
            lb.setName(String.valueOf(dsContact.getDanhSachContact().get(i).getContactID()));
            /////
            //them cac phan tu vao mang
            Vector<Object> a = new Vector<Object>();
            a.add(lb);//add icon

            a.add(dsContact.getDanhSachContact().get(i).getFullName());//add from

            JTextField textField = new JTextField();
            textField.setBackground(whiteSmoke);
            textField.setFont(GlobalVariables.g_font);
            textField.setText(dsContact.getDanhSachContact().get(i).getCompany());
            a.add(textField);//add

            a.add(dsContact.getDanhSachContact().get(i).getDisplayas());//add from
            a.add(dsContact.getDanhSachContact().get(i).getCategory());//add category
            a.add(dsContact.getDanhSachContact().get(i).getMobilePhone());//add
            a.add(dsContact.getDanhSachContact().get(i).getBusinessPhone());//add from

            arrRow.add(a);
        }
    }

    public static void editTableCompany(JTable table1) {
        TableColumn column = null;
        //dieu chinh kich thuoc, do rong cac cot
        for (int i = 0; i < 7; i++) {
            column = table1.getColumnModel().getColumn(i);
            switch (i) {
                case 0://icon
                    column.setResizable(false);
                    column.setPreferredWidth(16);
                    break;
                case 1://name
                    column.setPreferredWidth(142);
                    break;
                case 2://company
                    column.setPreferredWidth(120);
                    break;
                case 3://displayas
                    column.setPreferredWidth(100);
                    break;
                case 4://mobile
                    column.setPreferredWidth(100);
                    break;
                case 5://business
                    column.setPreferredWidth(100);
                    break;
                case 6://home
                    column.setPreferredWidth(100);
                    break;
            }

        }
        //tuy chinh font, ung voi cac item trong table (in dam)
        Font font = GlobalVariables.g_font;
        table1.setFont(font);
        table1.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        table1.setSelectionBackground(Color.WHITE);
        table1.setSelectionForeground(Color.RED);

        TableColumn labelColumn = table1.getColumn("");
        labelColumn.setCellRenderer(new MyImageCellRenderer());

        labelColumn = table1.getColumn("Company");
        labelColumn.setCellRenderer(new MyImageCellRenderer());
        ////////////////////////////////
        ArrayList a1 = new ArrayList();
        Color[] rowColor = new Color[]{new Color(217, 248, 229), new Color(248, 217, 234),
            new Color(243, 217, 248), new Color(244, 248, 217), new Color(217, 239, 248),
            new Color(248, 217, 217), new Color(223, 217, 248)};

        if (table1.getRowCount() == 0) {
            return;
        } else if (table1.getRowCount() == 1) {
            ((JTextField) table1.getValueAt(0, 2)).setBackground(whiteSmoke);
        } else {//hai dong tro len
            for (int i = 0; i < table1.getRowCount(); i++) {
                String parten =
                        ((JTextField) table1.getValueAt(i, 2)).getText().trim();
                for (int j = i; j < table1.getRowCount(); j++) {
                    if (!((JTextField) table1.getValueAt(j, 2)).getText().trim().equals(parten)) {
                        a1.add(j);
                        i = j - 1;
                        break;
                    }
                }
            }
            int t = 0;
            Random rand = new Random();
            int nRand = rand.nextInt(7);
            Color randColor;
            for (int i = 0; i < a1.size(); i++) {
                if (i == 0) {
                    randColor = rowColor[nRand];
                } else {
                    rand = new Random();
                    int nRandNext = rand.nextInt(7);
                    while (nRandNext == nRand) {
                        nRandNext = rand.nextInt(7);
                        if (nRandNext != nRand) {
                            break;
                        }
                    }
                    nRand = nRandNext;
                    randColor = rowColor[nRand];
                }
                for (int j = t; j < Integer.parseInt(a1.get(i).toString()); j++) {

                    ((JTextField) table1.getValueAt(j, 2)).setBackground(randColor);
                }
                t = Integer.parseInt(a1.get(i).toString());
            }
            rand = new Random();
            int nRandEnd = rand.nextInt(7);
            while (nRandEnd == nRand) {
                nRandEnd = rand.nextInt(7);
                if (nRandEnd != nRand) {
                    break;
                }
            }
            randColor = rowColor[nRandEnd];
            for (int i = t; i < table1.getRowCount(); i++) {
                ((JTextField) table1.getValueAt(i, 2)).setBackground(randColor);
            }
        }
    }
}
