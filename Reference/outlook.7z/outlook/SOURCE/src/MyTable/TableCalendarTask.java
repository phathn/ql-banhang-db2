/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyTable;

/**
 *
 * @author letuan
 */
import BienDungChung.GlobalVariables;
import LopXuLy.XL_CalendarTask;
import LopXuLy.XL_CongViec;
import LopXuLy.XL_DanhSachAccount;
import LopXuLy.XL_DanhSachContact;
import LopXuLy.XL_DanhSachMail;
import LopXuLy.XL_Mail;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.io.File;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Vector;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

/**
 *
 * @author letuan
 */
public class TableCalendarTask {
    //mang chua cac cot

    private static int PREFERRED_SIZE = 12;
    private static Color whiteSmoke = new Color(245, 245, 245);
    private static String _ngay;
    /**
     * ham thuc hien điều chỉnh kích thước của các cột trong table theo kiểu full
     * @param table1: bảng cần định dạng
     */
    public static void editTable(JTable table1) {
        TableColumn column = null;
        column = table1.getColumnModel().getColumn(0);
        
        //tuy chinh font, ung voi cac item trong table (in dam)
        Font font = GlobalVariables.g_font;
        table1.setFont(font);
        table1.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        table1.setSelectionBackground(Color.WHITE);
        table1.setSelectionForeground(Color.RED);

        column.setCellRenderer(new MyImageCalendarRenderer());

    //TableCellRenderer renderer = new MyImageRowCalendarRenderer();
    //table1.setDefaultRenderer(Object.class, renderer);
    }

    public static void loadFolderIntoTable(JTable table, XL_CalendarTask task, String Ngay) {
        _ngay = Ngay;

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Microsoft Sans Serif", 1, 12));
        header.setBackground(new Color(243, 217, 152));
        
        table.getColumnModel().getColumn(0).setHeaderValue(_ngay);
        for(int i=0; i<table.getRowCount(); i++){
            table.setValueAt(null, i, 0);
        }
        addElementIntoTable(table, task);
        ///////////////
        editTable(table);
    }

    /**
     * Đưa các files/folders con của file ứng với đường dẫn path1
     * vào 1 table theo kiểu full screen
     * @param path1: đường dẫn chứa files/folders cần load
     */
    public static void addElementIntoTable(JTable table, XL_CalendarTask task) {
        //arraylsit chua tat cac cac file tuong ung voi thu muc
        //co duong dan strTempPathLeft
        /////////////////

        for (XL_CongViec cv : task.getDanhSachCongViec()) {
            JLabel lb = new JLabel();
            lb.setFont(GlobalVariables.g_font);
            String pathImages;
            pathImages = System.getProperty("user.dir") + File.separator +
                    "images_tree/bell.png";

            ImageIcon imageIcon = new ImageIcon(pathImages);
            if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
                imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                        PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
            }

            lb.setIcon(imageIcon);
            lb.setName(String.valueOf(cv.getCategory()));
            lb.setText(String.valueOf(cv.getSubject()));
            /////
            Vector<Object> a = new Vector<Object>();
            a.add(lb);//add icon

            table.setValueAt(lb, tinhDong(cv.getGio()), 0);
        }
    }

    public static int tinhDong(int gio) {
        switch (gio) {
            case 24:
                return 0;
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 3;
            case 4:
                return 4;
            case 5:
                return 5;
            case 6:
                return 6;
            case 7:
                return 7;
            case 8:
                return 8;
            case 9:
                return 9;
            case 10:
                return 10;
            case 11:
                return 11;
            case 12:
                return 12;
            case 13:
                return 13;
            case 14:
                return 14;
            case 15:
                return 15;
            case 16:
                return 16;
            case 17:
                return 17;
            case 18:
                return 18;
            case 19:
                return 19;
            case 20:
                return 20;
            case 21:
                return 21;
            case 22:
                return 22;
            case 23:
                return 23;
        }
        return -1;
    }
}
