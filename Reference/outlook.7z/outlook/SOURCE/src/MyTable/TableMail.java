/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyTable;

import BienDungChung.GlobalVariables;
import LopXuLy.XL_DanhSachAccount;
import LopXuLy.XL_DanhSachContact;
import LopXuLy.XL_DanhSachMail;
import LopXuLy.XL_Mail;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.io.File;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Vector;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

/**
 *
 * @author letuan
 */
public class TableMail {
    //mang chua cac cot

    private static Vector<String> arrCol = new Vector<String>(3);
    //mang chua du lieu cac dong
    private static Vector<Object> arrRow;
    //mang luu giu ten cac cot
    private static String[] columnNames;
    private static int PREFERRED_SIZE = 12;
    private static Color whiteSmoke = new Color(245, 245, 245);

    /**
     * ham thuc hien điều chỉnh kích thước của các cột trong table theo kiểu full
     * @param table1: bảng cần định dạng
     */
    public static void editTableMail(JTable table1) {
        TableColumn column = null;
        //dieu chinh kich thuoc, do rong cac cot
        for (int i = 0; i < 5; i++) {
            column = table1.getColumnModel().getColumn(i);
            switch (i) {
                case 0://icon
                    column.setResizable(false);
                    column.setPreferredWidth(16);

                    String pathImages = System.getProperty("user.dir") + File.separator +
                            "images_tree/star_header.png";
                    ImageIcon imageIcon = new ImageIcon(pathImages);
                    if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
                        imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                                PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
                    }
                    column.setHeaderRenderer(new MyImageHeaderRenderer("Add Star for mail"));
                    column.setHeaderValue(new txtIcon(imageIcon));
                     break;
                case 1://icon
                    column.setResizable(false);
                    column.setPreferredWidth(16);

                    pathImages = System.getProperty("user.dir") + File.separator +
                            "images_tree/attach.png";
                    imageIcon = new ImageIcon(pathImages);
                    if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
                        imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                                PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
                    }
                    column.setHeaderRenderer(new MyImageHeaderRenderer("Attachment"));
                    column.setHeaderValue(new txtIcon(imageIcon));
                    break;
                case 2://name
                    column.setPreferredWidth(340);
                    break;
                case 3://icon
                    column.setResizable(false);
                    column.setPreferredWidth(16);

                    pathImages = System.getProperty("user.dir") + File.separator +
                            "images_tree/junk_header.png";
                    imageIcon = new ImageIcon(pathImages);
                    if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
                        imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                                PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
                    }
                    column.setHeaderRenderer(new MyImageHeaderRenderer("Add junk for mail"));
                    column.setHeaderValue(new txtIcon(imageIcon));
                    break;
                case 4://ext
                    column.setPreferredWidth(166);
                    break;
            }

        }
        //tuy chinh font, ung voi cac item trong table (in dam)
        Font font = GlobalVariables.g_font;
        table1.setFont(font);
        table1.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        table1.setSelectionBackground(Color.WHITE);
        table1.setSelectionForeground(Color.RED);

        TableColumn labelColumn = table1.getColumnModel().getColumn(0);
        labelColumn.setCellRenderer(new MyImageCellRenderer());

        labelColumn = table1.getColumnModel().getColumn(1);
        labelColumn.setCellRenderer(new MyImageCellRenderer());

        labelColumn = table1.getColumnModel().getColumn(3);
        labelColumn.setCellRenderer(new MyImageCellRenderer());

        TableCellRenderer renderer = new MyImageRowRenderer();
        table1.setDefaultRenderer(Object.class, renderer);
    }

    public static void sortAllRowsByFull(DefaultTableModel model, int colIndex, boolean ascending) {
        Vector data = model.getDataVector();
        Collections.sort(data, new ColumnSorterMail(colIndex, ascending));
        model.fireTableStructureChanged();
    }

    public static void loadFolderIntoTableMail(JTable table, XL_DanhSachMail dsMail) {
        table.setRowHeight(18);
        arrCol = new Vector<String>();
        columnNames = new String[]{"", "", "From", "", "Date"};
        for (String strNameCol : columnNames) {
            arrCol.add(strNameCol);
        }

        addElementIntoTableMail(dsMail);
        //them dong, cot
        MyTableModel model = new MyTableModel(arrRow, arrCol, false);
        table.setModel(model);
        //thuc hien sort column theo tung loai (thu muc, file)
        //thu muc tang tu tren xuong duoi
        //sau do den file tang tu tren xuong duoi
        table.setAutoCreateColumnsFromModel(false);
        sortAllRowsByFull(model, 4, false);
        ///////////////
        editTableMail(table);
    }

    /**
     * Đưa các files/folders con của file ứng với đường dẫn path1
     * vào 1 table theo kiểu full screen
     * @param path1: đường dẫn chứa files/folders cần load
     */
    public static void addElementIntoTableMail(XL_DanhSachMail dsMail) {
        //arraylsit chua tat cac cac file tuong ung voi thu muc
        //co duong dan strTempPathLeft
        arrRow = new Vector<Object>();
        /////////////////
        for (int i = 0; i < dsMail.getDanhSachMail().size(); i++) {
            JLabel lb = new JLabel();
            String pathImages;
            if (dsMail.getDanhSachMail().get(i).getPathAttach().size() == 0) {
                pathImages = System.getProperty("user.dir") + File.separator +
                        "images_tree/email_text.png";
            } else {
                pathImages = System.getProperty("user.dir") + File.separator +
                        "images_tree/attach.png";
            }

            ImageIcon imageIcon = new ImageIcon(pathImages);
            if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
                imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                        PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
            }

            lb.setIcon(imageIcon);
            lb.setName(String.valueOf(dsMail.getDanhSachMail().get(i).getMailID()));
            lb.setText(String.valueOf(dsMail.getDanhSachMail().get(i).getTag()));
            /////
            //them cac phan tu vao mang
            JLabel lb2 = new JLabel();
            if (dsMail.getDanhSachMail().get(i).getStar().equals("false")) {
                pathImages = System.getProperty("user.dir") + File.separator +
                        "images_tree/bullet_blue.png";
            } else {
                pathImages = System.getProperty("user.dir") + File.separator +
                        "images_tree/star.png";
            }
            imageIcon = new ImageIcon(pathImages);
            if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
                imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                        PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
            }
            lb2.setIcon(imageIcon);

            JLabel lb3 = new JLabel();
            if (dsMail.getDanhSachMail().get(i).getJunk().equals("true")) {
                pathImages = System.getProperty("user.dir") + File.separator +
                        "images_tree/junk.png";

                imageIcon = new ImageIcon(pathImages);
                if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
                    imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                            PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
                }
                lb3.setIcon(imageIcon);
            }
            Vector<Object> a = new Vector<Object>();
            a.add(lb2);//add icon
            a.add(lb);//add icon
            a.add(dsMail.getDanhSachMail().get(i).getFrom());//add from
            a.add(lb3);//add icon
            a.add(dsMail.getDanhSachMail().get(i).getDate());//add
            arrRow.add(a);
        }
    }
}
