/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyTable;

/**
 *
 * @author le tuan
 */
import java.awt.Color;
import java.awt.Component;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author le tuan
 */
public class MyImageRowCalendarRenderer extends DefaultTableCellRenderer {

    public static final DefaultTableCellRenderer DEFAULT_RENDERER = new DefaultTableCellRenderer();

    /** Override this method in DefaultTableCellRenderer */
    /**
     * Returns the default table cell renderer<p>
     * During a printing operation, this method will be called with isSelected
     * and hasFocus values of false to prevent selection and focus from appearing
     * in the printed output. To do other customization based on whether or not the
     * table is being printed, check the return value from JComponent.isPaintingForPrint().<p>
     * @param table: the JTable
     * @param value:  the value to assign to the cell at [row, column]
     * @param isSelected: true if cell is selected
     * @param isFocused: true if cell has focus
     * @param row: the row of the cell to render
     * @param column: the column of the cell to render
     * @return: The default table cell renderer
     */
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
            boolean isFocused, int row, int column) {
        Component renderer = DEFAULT_RENDERER.getTableCellRendererComponent(
                table, value, isSelected, isFocused, row, column);
        ((JLabel) renderer).setOpaque(true);
        if(row >=0 && row<12){
            renderer.setBackground(new Color(255,255,213));
        }else if(row >=12 && row<24){
            renderer.setBackground(new Color(255,244,188));
        }

        return renderer;
    }
}
