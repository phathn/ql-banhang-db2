/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package BienDungChung;

import LopXuLy.XL_Account;
import LopXuLy.XL_DanhSachAccount;
import LopXuLy.XL_DanhSachMail;
import java.awt.Font;
import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;

/**
 *
 * @author letuan
 */
public class GlobalVariables {
    public static String g_strTenTapTinAccount = System.getProperty("user.dir") + File.separator +
                "Data/Account.xml";
    public static String g_strTenTapTinMail = System.getProperty("user.dir") + File.separator +
                "Data/Mail.xml";
    public static String g_strTenTapTinMailDaGui = System.getProperty("user.dir") + File.separator +
                "Data/DanhSachMailDaGui.xml";
    public static String g_strTenTapTinContact = System.getProperty("user.dir") + File.separator +
                "Data/Contact.xml";
    public static String g_strTenTapTinCalendarTask = System.getProperty("user.dir") + File.separator +
                "Data/CalendarTask.xml";
 public static String g_strTenTapTinMonthTask = System.getProperty("user.dir") + File.separator +
                "Data/MonthTask.xml";
    public static String g_strErrorMessage ;
    public static XL_DanhSachAccount TapHopAccount;
    public static XL_DanhSachMail TapHopMailByID;//bien chua cac mail cua 1 nguoi dung
    public static XL_DanhSachMail TapHopMail;//bien chua cac mail cua 1 nguoi dung

    public static XL_Account ActiveAccount;
    public static String pathLocalFolder = "D:\\Outlook2009_letuan\\Local Folders\\";
    public static String pathOutlook = "D:\\Outlook2009_letuan\\";
    public static String connectSucess = "Chưa kết nối";
    public static int numMessage = -1;
    public static ArrayList<String> pathAtt;
    public static boolean loaded=false;
    public static Hashtable<String, Integer> numMailOfUser = new Hashtable<String, Integer>();
    public static Font g_font = new Font("Microsoft Sans Serif", 0, 11);

}
