/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPrint;

/**
 *
 * @author le tuan
 */
import java.awt.*;
import java.awt.event.*;
import java.awt.font.*;
import java.awt.geom.*;
import java.awt.print.*;
import java.util.*;
import javax.print.*;
import javax.print.attribute.*;
import javax.swing.*;

/**  This program demonstrates how to print 2D graphics  */
/**  This frame shows a panel with 2D graphics and buttons  to print the graphics and to set up the page format.  */
/**  This panel generates a 2D graphics image for screen display  and printing.  */
public class PrintPanel extends JPanel implements Printable {

    private String textPrint;
    private JTextArea m_editor;
    private Vector m_lines;

    public PrintPanel(JTextArea editor, String str) {
        this.m_editor = editor;
        this.textPrint = str;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
    }

    public int print(Graphics pg, PageFormat pageFormat,
            int pageIndex) throws PrinterException {
        pg.translate((int) pageFormat.getImageableX(),
                (int) pageFormat.getImageableY());
        int wPage = (int) pageFormat.getImageableWidth();
        int hPage = (int) pageFormat.getImageableHeight();
        pg.setClip(0, 0, wPage, hPage);
        pg.setColor(this.m_editor.getBackground());
        pg.fillRect(0, 0, wPage, hPage);
        pg.setColor(m_editor.getForeground());
        Font font = m_editor.getFont();
        pg.setFont(font);
        FontMetrics fm = pg.getFontMetrics();
        int hLine = fm.getHeight();
        if (m_lines == null) {
            m_lines = getLines(fm, wPage);
        }
        int numLines = m_lines.size();
        int linesPerPage = Math.max(hPage / hLine, 1);
        int numPages =
                (int) Math.ceil((double) numLines / (double) linesPerPage);
        if (pageIndex >= numPages) {
            m_lines = null;
            return NO_SUCH_PAGE;
        }
        int x = 0;
        int y = fm.getAscent();
        int lineIndex = linesPerPage * pageIndex;
        while (lineIndex < m_lines.size() && y < hPage) {
            String str = (String) m_lines.get(lineIndex);
            pg.drawString(str, x, y);
            y += hLine;
            lineIndex++;
        }
        return PAGE_EXISTS;
    }
    public static final int TAB_SIZE = 4;

    protected Vector getLines(FontMetrics fm, int wPage) {
        Vector v = new Vector();
        String text = textPrint;
        String prevToken = "";
        StringTokenizer st = new StringTokenizer(text, "\n\r", true);
        while (st.hasMoreTokens()) {
            String line = st.nextToken();
            if (line.equals("\r")) {
                continue;
            }
// StringTokenizer will ignore empty lines,
// so it's a bit tricky to get them...
            if (line.equals("\n") && prevToken.equals("\n")) {
                v.add("");
            }
            prevToken = line;
            if (line.equals("\n")) {
                continue;
            }
            StringTokenizer st2 = new StringTokenizer(line, " \t", true);
            String line2 = "";
            while (st2.hasMoreTokens()) {
                String token = st2.nextToken();
                if (token.equals("\t")) {
                    int numSpaces = TAB_SIZE - line2.length() % TAB_SIZE;
                    token = "";
                    for (int k = 0; k < numSpaces; k++) {
                        token += " ";
                    }
                }
                int lineLength = fm.stringWidth(line2 + token);
                if (lineLength > wPage && line2.length() > 0) {
                    v.add(line2);
                    line2 = token.trim();
                    continue;
                }
                line2 += token;
            }
            v.add(line2);
        }
        return v;
    }
}
