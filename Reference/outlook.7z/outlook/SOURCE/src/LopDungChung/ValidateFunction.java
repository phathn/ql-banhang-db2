/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LopDungChung;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author letuan
 */
public class ValidateFunction {

    /**
     * Kiem tra mail hop le
     * @param strEmail
     * @return
     */
    public static boolean KiemTraEmail(String strEmail) {
        Pattern pattern =
                Pattern.compile("\\w+((-\\w+)|(\\.\\w+))*\\@[A-Za-z0-9]+((\\.|-|_)" +
                "[A-Za-z0-9]+)*\\.([A-Za-z]{2,4})$");
        Matcher matcher =
                pattern.matcher(strEmail);
        while (matcher.find()) {
            return true;
        }
        return false;
    }

    /**
     * Kiem tra server hop le
     * @param strEmail
     * @return
     */
    public static boolean KiemTraServer(String strEmail) {
        Pattern pattern =
                Pattern.compile("\\w+((-\\w+)|(\\.\\w+))*\\.[A-Za-z0-9]+((\\.|-|_)" +
                "[A-Za-z0-9]+)*\\.([A-Za-z]{2,4})$");
        Matcher matcher =
                pattern.matcher(strEmail);
        while (matcher.find()) {
            return true;
        }
        return false;
    }
}
