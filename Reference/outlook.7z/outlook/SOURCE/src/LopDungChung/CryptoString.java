/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LopDungChung;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

/**
 *
 * @author letuan
 */
public class CryptoString {

    private static final int count = 20;
    private static final byte[] salt = {
        (byte) 0xc7, (byte) 0x73, (byte) 0x21, (byte) 0x8c,
        (byte) 0x7e, (byte) 0xc8, (byte) 0xee, (byte) 0x99
    };
    private static final String PASSKEY = "26011765362158357242";

    /**
     * Ma hoa pass word
     * @param input
     * @return
     * @throws java.lang.Exception
     */
    public static String encrypt(String input) throws Exception {
        String output;

        byte[] plain = input.getBytes();

        PBEParameterSpec pbeParamSpec = new PBEParameterSpec(salt, count);

        PBEKeySpec pbeKeySpec = new PBEKeySpec(PASSKEY.toCharArray());
        SecretKeyFactory skFact = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
        SecretKey key = skFact.generateSecret(pbeKeySpec);

        Cipher c = Cipher.getInstance("PBEWithMD5AndDES");
        c.init(Cipher.ENCRYPT_MODE, key, pbeParamSpec);
        byte[] encryted = c.doFinal(plain);

        output = new String(encryted);
        return output;
    }

    /**
     * Giai ma pass
     * @param input
     * @return
     * @throws java.lang.Exception
     */
    public static String decrypt(String input) throws Exception {
        String output;

        byte[] plain = input.getBytes();

        PBEParameterSpec pbeParamSpec = new PBEParameterSpec(salt, count);

        PBEKeySpec pbeKeySpec = new PBEKeySpec(PASSKEY.toCharArray());
        SecretKeyFactory skFact = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
        SecretKey key = skFact.generateSecret(pbeKeySpec);

        Cipher c = Cipher.getInstance("PBEWithMD5AndDES");
        c.init(Cipher.DECRYPT_MODE, key, pbeParamSpec);
        byte[] encryted = c.doFinal(plain);

        output = new String(encryted);
        return output;
    }
}
