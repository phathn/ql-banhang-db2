/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LopDungChung;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

/**
 *
 * @author letuan
 */
public class ThaoTacThuMuc {

    /**
     * Tao folder moi
     * @param path
     * @param nameFolder
     * @return
     */
    public static boolean createFolder(String path, String nameFolder) {
        String str = nameFolder;
        if (str == null) {
            return false;
        }

        File f = new File(path + str);
        if (!f.exists()) {
            f.mkdir();
            return true;
        }
        return false;
    }

    /**
     * Luu file
     * @param filename
     * @param input
     * @throws java.io.IOException
     */
    public static void saveFile(String filename, InputStream input) throws IOException {
        File file = new File(filename);
        file.createNewFile();
        InputStream in = input;
        FileOutputStream fos = new FileOutputStream(file);
        byte[] buf = new byte[1024];
        int c = 0;
        while ((c = in.read(buf)) != -1) {
            fos.write(buf, 0, c);
        }
        in.close();
        fos.close();
    }

    /**
     * delete folder
     * @param folder
     */
    public static void deleteFolder(File folder) {
        for (File file : folder.listFiles()) {
            if (file.isFile()) {
                file.delete();
            }

            if (file.isDirectory()) {
                deleteFolder(file);
                file.delete();
            }

        }
    }

    /**
     * luu password
     * @param AccountID
     * @param PassWord
     * @throws java.io.IOException
     * @throws java.lang.Exception
     */
    public static void ghiPassWord(int AccountID, String PassWord) throws IOException, Exception {
        String passEncrypted = LopDungChung.CryptoString.encrypt(PassWord);
        String filepath = "D:\\Outlook2009_Password\\" + String.valueOf(AccountID) + ".txt";
        FileWriter fileWriter = new FileWriter(filepath);
        BufferedWriter bufWriter = new BufferedWriter(fileWriter);

        for (int i = 0; i < passEncrypted.length(); i++) {
            char c = (char) passEncrypted.charAt(i);
            if (String.valueOf(c).equals("\n")) {
                bufWriter.newLine();
            } else {
                bufWriter.write(c);
            }
        }

        bufWriter.close();
    }

    /**
     * doc pass da luu
     * @param AccountID
     * @return
     * @throws java.io.IOException
     * @throws java.lang.Exception
     */
    public static String docPassWord(int AccountID) throws IOException, Exception {
        String filepath = "D:\\Outlook2009_Password\\" + String.valueOf(AccountID) + ".txt";
        File file = new File(filepath);
        if (!file.exists()) {
            return "";
        }
        FileReader fileReader = new FileReader(filepath);
        BufferedReader bufReader = new BufferedReader(fileReader);
        String text = "";
        String str = null;

        do {
            str = bufReader.readLine();
            if (str == null) {
                break;
            }
            text += str;
        } while (str != null);
        bufReader.close();
        String passDecrypted = LopDungChung.CryptoString.decrypt(text);
        return passDecrypted;
    }
}
