/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package AutoComplete;

/**
 *
 * @author TAN Vo Hung
 */
import java.util.List;
import javax.swing.text.JTextComponent;

/**
 * An implementation of the AbstractAutoCompleteAdaptor that is suitable for a
 * JTextComponent.
 *
 * @author Thomas Bierhance
 */
public class TextComponentAdaptor extends AbstractAutoCompleteAdaptor {

    /** a <tt>List</tt> containing the strings to be used for automatic
     * completion */
    List items;
    /** the text component that is used for automatic completion*/
    JTextComponent textComponent;
    /** the item that is currently selected */
    Object selectedItem;

    /**
     * Creates a new <tt>TextComponentAdaptor</tt> for the given list and text
     * component.
     *
     * @param items a <tt>List</tt> that contains the items that are used for
     * automatic completion
     * @param textComponent the text component that will be used automatic
     * completion
     */
    public TextComponentAdaptor(JTextComponent textComponent, List items) {
        this.items = items;
        this.textComponent = textComponent;
    }

    public Object getSelectedItem() {
        return selectedItem;
    }

    public int getItemCount() {
        return items.size();
    }

    public Object getItem(int index) {
        return items.get(index);
    }

    public void setSelectedItem(Object item) {
        selectedItem = item;
    }

    public JTextComponent getTextComponent() {
        return textComponent;
    }
}
