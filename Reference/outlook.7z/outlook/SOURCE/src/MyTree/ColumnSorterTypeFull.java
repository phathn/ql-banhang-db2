/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyTree;

import java.util.Comparator;
import java.util.Vector;

/**
 *
 * @author le tuan
 */
public class ColumnSorterTypeFull implements Comparator {

    int childIndex;
    boolean ascending;

    /**
     * Hởi tạo 1 đối tượng Comparator
     * @param colIndex: sort theo cột
     * @param ascending: true(tăng từ trên xuống dưới), false(tăng từ dưới lên trên)
     */
    ColumnSorterTypeFull(int childIndex, boolean ascending) {
        this.childIndex = childIndex;
        this.ascending = ascending;
    }

    /**
     * sort các dòng dữ liệu của 1 DefaultTableModel, thực hiện so sánh 2 giá trị của 2
     * dòng theo cột dùng để sort
     * @param a: dòng thứ nhất
     * @param b: dòng thứ hai
     * @return
     */
    public int compare(Object a, Object b) {
        Object o1 = a;
        Object o2 = b;

        // Treat empty strains like nulls
        if (o1 instanceof IconNode && ((IconNode) o1).getIconName() == null) {
            o1 = null;
        }
        if (o2 instanceof IconNode && ((IconNode) o2).getIconName() == null) {
            o2 = null;
        }

        // Sort nulls so they appear last, regardless
        // of sort order
        if (o1 == null && o2 == null) {
            return 0;
        } else if (o1 == null) {
            return 1;
        } else if (o2 == null) {
            return -1;
        } else if (o1 instanceof Comparable) {
            if (ascending) {
                return ((IconNode) o1).getIconName().toUpperCase().compareTo(((IconNode) o2).getIconName().toUpperCase());
            } else {
                return ((IconNode) o2).getIconName().toUpperCase().compareTo(((IconNode) o1).getIconName().toUpperCase());
            }
        } else {
            if (ascending) {
                return ((IconNode) o1).getIconName().toUpperCase().compareTo(((IconNode) o2).getIconName().toUpperCase());
            } else {
                return ((IconNode) o2).getIconName().toUpperCase().compareTo(((IconNode) o1).getIconName().toUpperCase());
            }
        }
    }
}
