/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyTree;

import BienDungChung.GlobalVariables;
import java.awt.Image;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Enumeration;
import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import sun.awt.shell.ShellFolder;

/**
 *
 * @author letuan
 */
public class TreeContact {

    private static int PREFERRED_SIZE = 18;

    /**
     * load cac node vao tree contact
     * @param tree
     */
    public static void loadElemIntoTreeContact(JTree tree) {
        //node goc
        MyTree.IconNode nodesDrivers = new MyTree.IconNode("Current View");
        String pathImages = System.getProperty("user.dir") + File.separator +
                "images_tree/outlook.gif";
        ImageIcon imageIcon = new ImageIcon(pathImages);
        if (imageIcon.getIconWidth() > 14 || imageIcon.getIconHeight() > 14) {
            imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                    14, 14, Image.SCALE_SMOOTH));
        }
        nodesDrivers.setIcon(imageIcon);
        nodesDrivers.setIconName("Current View");
        //////////]/////////////////////////////////
        pathImages = System.getProperty("user.dir") + File.separator +
                "images_tree/bullet_red.png";
        imageIcon = new ImageIcon(pathImages);

        //thu nho kich thuoc cua icon
        if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
            imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                    PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
        }
        MyTree.IconNode nodeAddressCards = new MyTree.IconNode("Address Cards");
        nodeAddressCards.setIcon(imageIcon);
        nodeAddressCards.setIconName("pnlContact_AddressCard");

        MyTree.IconNode nodeDetailAddressCards = new MyTree.IconNode("Detail Address Cards");
        nodeDetailAddressCards.setIcon(imageIcon);
        nodeDetailAddressCards.setIconName("pnlContact_DetailAddressCard");

        MyTree.IconNode nodeBusinessCards = new MyTree.IconNode("Business Cards");
        nodeBusinessCards.setIcon(imageIcon);
        nodeBusinessCards.setIconName("pnlContact_BusinessCard");

        MyTree.IconNode nodePhoneList = new MyTree.IconNode("Phone List");
        nodePhoneList.setIcon(imageIcon);
        nodePhoneList.setIconName("pnlContact_PhoneList");

        MyTree.IconNode nodeByCatgory = new MyTree.IconNode("By Category");
        nodeByCatgory.setIcon(imageIcon);
        nodeByCatgory.setIconName("pnlContact_ByCategory");

        MyTree.IconNode nodeByCompany = new MyTree.IconNode("By Company");
        nodeByCompany.setIcon(imageIcon);
        nodeByCompany.setIconName("pnlContact_ByCompany");

        MyTree.IconNode nodeOutlookDataField = new MyTree.IconNode("Outlook Data Field");
        nodeOutlookDataField.setIcon(imageIcon);
        nodeOutlookDataField.setIconName("pnlContact_OutlookDataField");

        nodesDrivers.add(nodeAddressCards);
        nodesDrivers.add(nodeDetailAddressCards);
        nodesDrivers.add(nodeBusinessCards);
        nodesDrivers.add(nodePhoneList);
        nodesDrivers.add(nodeByCatgory);
        nodesDrivers.add(nodeByCompany);
        nodesDrivers.add(nodeOutlookDataField);
        ////////////////////////////////////////
        DefaultTreeModel treeModel = new DefaultTreeModel(nodesDrivers, false);
        tree.setModel(treeModel);
        tree.setCellRenderer(new IconNodeRenderer());
        tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        MyExpandAll.expandAll(tree, true);
    }
}
