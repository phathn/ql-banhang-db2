/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyTree;

/**
 *
 * @author letuan
 */
import java.awt.datatransfer.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.tree.TreePath;

public class TreeTransferHandler extends TransferHandler {

    private boolean _addDrop = false;  //Number of items added.

    /**
     * We only support importing strings.
     */
    @Override
    public boolean canImport(TransferHandler.TransferSupport info) {
        // Check for String flavor
        if (!info.isDataFlavorSupported(DataFlavor.stringFlavor)) {
            return false;
        }
        return true;
    }

    /**
     * We support both copy and move actions.
     */
    @Override
    public int getSourceActions(JComponent c) {
        return TransferHandler.COPY_OR_MOVE;
    }

    /**
     * Hàm thực hiện set giá trị của biến cờ hiệu _addDrop<p>
     * _addDrop: biến này được dùng để báo hiệu 1 động tác drag & drop đã kết
     * thúc
     */
    public void setDrop(boolean b) {
        this._addDrop = b;
    }

    /**
     * Hàm thực hiện lấy giá trị của biến cờ hiệu _addDrop
     * @return Trả về giá trị của biến này
     */
    public boolean getDrop() {
        return this._addDrop;
    }

    /**
     * Bundle up the selected items in a single list for export.
     * Each line is separated by a newline.
     */
    @Override
    protected Transferable createTransferable(JComponent c) {
        JTree tree = (JTree) c;
        int indexRow = tree.getSelectionRows()[0];
        String value = "";
        if (indexRow != -1) {
            TreePath path = tree.getPathForRow(indexRow);
            MyTree.IconNode node = (MyTree.IconNode) path.getLastPathComponent();
            value = node.getIconName().
                    substring(1, node.getIconName().length()).trim();
        }

        return new StringSelection(value);

    }

    /**
     * Perform the actual import.  This demo only supports drag and drop.
     */
    @Override
    public boolean importData(TransferHandler.TransferSupport info) {
        if (!info.isDrop()) {
            this._addDrop = false;
            return false;
        }
        this._addDrop = true;
        return true;
    }
}