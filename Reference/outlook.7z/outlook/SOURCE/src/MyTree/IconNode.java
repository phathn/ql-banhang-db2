/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyTree;

import java.util.Collections;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;

/**
 *
 * @author le tuan
 */
public class IconNode extends DefaultMutableTreeNode implements Comparable {

    protected ImageIcon icon;
    protected String iconName;
    private String iconAccountName;

    public IconNode() {
        this(null);
    }

    public IconNode(Object userObject) {
        this(userObject, true, null);
    }

    public IconNode(Object userObject, boolean allowsChildren, ImageIcon icon) {
        super(userObject, allowsChildren);
        this.icon = icon;
    }

    public void setIcon(ImageIcon icon) {
        this.icon = icon;
    }

    public ImageIcon getIcon() {
        return icon;
    }

    public String getIconName() {
        if (iconName != null) {
            return iconName;
        } else {
            String str = userObject.toString();
            int index = str.lastIndexOf(".");
            if (index != -1) {
                return str.substring(++index);
            } else {
                return null;
            }
        }
    }

    /**
     *
     * @param name
     */
    public void setIconName(String name) {
        iconName = name;
    }

    public IconNode(String name) {
        super(name);
    }

    @Override
    public void insert(final MutableTreeNode newChild, final int childIndex) {
        super.insert(newChild, childIndex);
        Collections.sort(this.children, new ColumnSorterTypeFull(childIndex, true));
    }

    public int compareTo(final Object o) {
        return this.toString().compareToIgnoreCase(o.toString());
    }

    /**
     * @return the iconAccountName
     */
    public String getIconAccountName() {
        return iconAccountName;
    }

    /**
     * @param iconAccountName the iconAccountName to set
     */
    public void setIconAccountName(String iconAccountName) {
        this.iconAccountName = iconAccountName;
    }
}