/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyTree;

import BienDungChung.GlobalVariables;
import java.awt.Image;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Enumeration;
import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import sun.awt.shell.ShellFolder;

/**
 *
 * @author letuan
 */
public class TreeMail {

    private static int PREFERRED_SIZE = 18;

    

    /**
     * load cac node vao tree mail
     * @param tree
     * @throws java.io.FileNotFoundException
     */
    public static void loadElemsIntoTreeMail(JTree tree) throws FileNotFoundException {
        MyTree.IconNode nodesDrivers = new MyTree.IconNode("Outlook2009_LeTuan");
        String pathImages = System.getProperty("user.dir") + File.separator +
                "images_tree/outlook.gif";
        ImageIcon imageIcon = new ImageIcon(pathImages);
        if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
            imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                    PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
        }
        nodesDrivers.setIcon(imageIcon);
        ///////////////////////////////////////////
        File outLookFile = new File(BienDungChung.GlobalVariables.pathOutlook);
        File[] fileDriver;
        if ((fileDriver = outLookFile.listFiles()) != null) {
            for (File file : fileDriver) {
                if (file.isDirectory()) {
                    MyTree.IconNode node = new MyTree.IconNode(file.getName());
                    //goi de qui xet thu muc con
                    //addElementIntoDriverInTree(node, file);
                    pathImages = null;
                    //xet thu muc local folder
                    if (file.getName().equals("Local Folders")) {
                        pathImages = System.getProperty("user.dir") + File.separator +
                                "images_tree/localfolder.gif";
                        imageIcon = new ImageIcon(pathImages);

                        //thu nho kich thuoc cua icon
                        if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
                            imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                                    PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
                        }
                        node.setIcon(imageIcon);
                        node.setIconName(" " + file.getPath());
                    } else {
                        pathImages = System.getProperty("user.dir") + File.separator +
                                "images_tree/user.gif";
                        imageIcon = new ImageIcon(pathImages);

                        //thu nho kich thuoc cua icon
                        if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
                            imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                                    PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
                        }
                        node.setIcon(imageIcon);
                        node.setIconName("!" + file.getPath());
                        node.setIconAccountName(file.getName());
                    }

                    nodesDrivers.add(node);
                    int numMail = 0;
                    if (GlobalVariables.numMailOfUser.containsKey(file.getName())) {
                        numMail = GlobalVariables.numMailOfUser.get(file.getName());
                    }
                    addElementIntoFolderInTree(node, file, numMail, file.getName());
                }
            }
        }
        ////////////////////////////////////////
        DefaultTreeModel treeModel = new DefaultTreeModel(nodesDrivers, false);
        tree.setModel(treeModel);
        tree.setCellRenderer(new IconNodeRenderer());
        tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        MyExpandAll.expandAll(tree, true);
    }

    /**
     * Khoi tao cay mail
     */
    public static void addElementIntoFolderInTree(MyTree.IconNode nodeDriver, File driver, int numMail, String nameCha) throws FileNotFoundException {
        MyTree.IconNode node;
        ShellFolder sf;
        ImageIcon imageIcon;
        File[] fileDriver;
        if ((fileDriver = driver.listFiles()) != null) {
            for (File file : fileDriver) {
                if (file.isDirectory()) {
                    if (file.getName().equals("Inbox") && numMail > 0) {
                        node = new MyTree.IconNode(file.getName() + " (" + numMail + ")");
                    } else {
                        node = new MyTree.IconNode(file.getName());
                    }
                    //goi de qui xet thu muc con
                    //addElementIntoDriverInTree(node, file);
                    String pathImages = null;
                    /////////////////////////////
                    if (file.getName().equals("Inbox")) {
                        pathImages = System.getProperty("user.dir") + File.separator +
                                "images_tree/inbox.gif";
                        imageIcon = new ImageIcon(pathImages);

                        //thu nho kich thuoc cua icon
                        if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
                            imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                                    PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
                        }
                        node.setIcon(imageIcon);
                        node.setIconName(" " + file.getPath());
                        node.setIconAccountName(nameCha);
                    } else if (file.getName().equals("Sent")) {
                        pathImages = System.getProperty("user.dir") + File.separator +
                                "images_tree/Sent.gif";
                        imageIcon = new ImageIcon(pathImages);

                        //thu nho kich thuoc cua icon
                        if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
                            imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                                    PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
                        }
                        node.setIcon(imageIcon);
                        node.setIconName("|" + file.getPath());
                        node.setIconAccountName(nameCha);
                    } else if (file.getName().equals("Trash")) {
                        pathImages = System.getProperty("user.dir") + File.separator +
                                "images_tree/trash.gif";
                        imageIcon = new ImageIcon(pathImages);

                        //thu nho kich thuoc cua icon
                        if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
                            imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                                    PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
                        }
                        node.setIcon(imageIcon);
                        node.setIconName("~" + file.getPath());
                        node.setIconAccountName(nameCha);
                    } else {
                        pathImages = System.getProperty("user.dir") + File.separator +
                                "images_tree/folder.png";
                        imageIcon = new ImageIcon(pathImages);

                        //thu nho kich thuoc cua icon
                        if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
                            imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                                    PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
                        }
                        node.setIcon(imageIcon);
                        node.setIconName("#" + file.getPath());
                        node.setIconAccountName(nameCha);
                    }
                    nodeDriver.add(node);
                    addElementIntoFolderInTree(node, file, numMail, nameCha);
                }
            }
        }
    }

    
}
