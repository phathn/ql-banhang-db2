/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyTree;

import LopXuLy.XL_Account;
import LopXuLy.XL_DanhSachAccount;
import java.awt.Image;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;

/**
 *
 * @author letuan
 */
public class TreeAccountSetting {

    private static int PREFERRED_SIZE = 12;

    /**
     * load cac node vao tree contact
     * @param tree
     */
    public static void loadElemIntoTree(JTree tree, XL_DanhSachAccount dsAccount) {
        //node goc
        MyTree.IconNode nodesDrivers = new MyTree.IconNode("Account Setting");
        String pathImages = System.getProperty("user.dir") + File.separator +
                "images_tree/outlook.gif";
        ImageIcon imageIcon = new ImageIcon(pathImages);
        if (imageIcon.getIconWidth() > 12 || imageIcon.getIconHeight() > 12) {
            imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                    12, 12, Image.SCALE_SMOOTH));
        }
        nodesDrivers.setIcon(imageIcon);
        nodesDrivers.setIconName("Account Setting");
        //////////]/////////////////////////////////
        for (XL_Account account : dsAccount.getDanhSachAccount()) {
            pathImages = System.getProperty("user.dir") + File.separator +
                    "images_tree/user.gif";
            imageIcon = new ImageIcon(pathImages);

            //thu nho kich thuoc cua icon
            if (imageIcon.getIconWidth() > PREFERRED_SIZE || imageIcon.getIconHeight() > PREFERRED_SIZE) {
                imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                        PREFERRED_SIZE, PREFERRED_SIZE, Image.SCALE_SMOOTH));
            }
            MyTree.IconNode nodeAccountSetting = new MyTree.IconNode(account.getAccountName());
            nodeAccountSetting.setIcon(imageIcon);
            nodeAccountSetting.setIconName("D:\\Outlook2009_letuan\\" + String.valueOf(account.getAccountName()));
            nodeAccountSetting.setIconAccountName(String.valueOf(account.getAccountName()));

            nodesDrivers.add(nodeAccountSetting);
        }

        ////////////////////////////////////////
        DefaultTreeModel treeModel = new DefaultTreeModel(nodesDrivers, false);
        tree.setModel(treeModel);
        tree.setCellRenderer(new IconNodeRenderer());
        tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        MyExpandAll.expandAll(tree, true);
    }
}
