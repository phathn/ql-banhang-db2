/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package MyTree;

import java.awt.Component;
import java.util.Hashtable;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;

/**
 *
 * @author le tuan
 */
public class IconNodeRenderer extends DefaultTreeCellRenderer {

    /**
     * Configures the renderer based on the passed in components. The value is set
     * from messaging the tree with convertValueToText, which ultimately invokes
     * toString on value. The foreground color is set based on the selection and
     * the icon is set based on the leaf and expanded parameters.<p>
     * @param tree
     * @param value
     * @param sel
     * @param expanded
     * @param leaf
     * @param row
     * @param hasFocus
     * @return The Component that the renderer uses to draw the value
     */
    @Override
    public Component getTreeCellRendererComponent(JTree tree, Object value,
            boolean sel, boolean expanded, boolean leaf, int row,
            boolean hasFocus) {

        super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf,
                row, hasFocus);

        ImageIcon icon = ((IconNode) value).getIcon();

        if (icon == null) {
            Hashtable icons = (Hashtable) tree.getClientProperty("JTree.icons");
            String name = ((IconNode) value).getIconName();
            if ((icons != null) && (name != null)) {
                icon = (ImageIcon) icons.get(name);
                if (icon != null) {
                    setIcon(icon);
                }
            }
        } else {
            setIcon(icon);
        }

        return this;
    }
}