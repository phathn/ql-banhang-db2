/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package outlook2009;

import BienDungChung.GlobalVariables;
import LopXuLy.XL_Account;
import LopXuLy.XL_DanhSachAccount;
import java.io.FileNotFoundException;
import java.security.NoSuchAlgorithmException;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author letuan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    /**
     * Thuc hien doc danh sach tat ca Account hien co
     */
    public static void LoadDanhSachAccount() {
        BienDungChung.GlobalVariables.TapHopAccount = new XL_DanhSachAccount();
        BienDungChung.GlobalVariables.TapHopAccount.Doc(BienDungChung.GlobalVariables.g_strTenTapTinAccount);
    }

    /**
     * Ham khoi dong chuong trinh thuc hien viec kiem tra co mail moi hay khong
     */
    public static void docMailKhiKhoiDong() throws NoSuchAlgorithmException, Exception {
        //duyet Account[i]
        if (GlobalVariables.TapHopAccount.getDanhSachAccount().size() == 0) {
            MainFrame frm = new MainFrame();
            frm.show();
            return;
        }
        //for (int i = 0; i < GlobalVariables.TapHopAccount.getDanhSachAccount().size(); i++) {
        XL_Account account =
                GlobalVariables.TapHopAccount.getDanhSachAccount().get(0);
        String pass = LopDungChung.ThaoTacThuMuc.docPassWord(account.getAccountID());
        account.setPassword(pass);

        //xet accout thu i
        BienDungChung.GlobalVariables.ActiveAccount = account;

        //khoi tao thong so phuc vu cho viec ket noi
        Connect.MailConstant.khoiTaoThanhPhanKetNoi(pass);
        Connect.ProgressConnectDialog processDlg;
        processDlg = new Connect.ProgressConnectDialog(null, "Please wailt");
        processDlg.testMail();
        MainFrame frm = new MainFrame();
        frm.show();
    //}
    }

    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException, FileNotFoundException, NoSuchAlgorithmException, Exception {
        // TODO code application logic here
        LoadDanhSachAccount();
        docMailKhiKhoiDong();
    }
}
