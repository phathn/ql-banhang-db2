/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * MainFrame.java
 *
 * Created on May 15, 2009, 3:10:26 PM
 */
package outlook2009;

import BienDungChung.GlobalVariables;
import Connect.ProgressConnectDialog;
import LopDungChung.CryptoString;
import LopDungChung.OpenMailAttachment;
import LopXuLy.XL_Account;
import LopXuLy.XL_CalendarTask;
import LopXuLy.XL_CongViec;
import LopXuLy.XL_Contact;
import LopXuLy.XL_DanhSachAccount;
import LopXuLy.XL_DanhSachContact;
import LopXuLy.XL_DanhSachMail;
import LopXuLy.XL_Mail;
import LopXuLy.XL_MonthTask;
import MonthCalendar.CalendarFunctions;
import MonthCalendar.CellTable;
import MyDatePicker.JCalendar;
import MyTable.MyImageCalendarRenderer;
import MyTable.MyTableModel;
import MyTree.IconNode;
import MyTree.IconNodeRenderer;
import MyTree.TreeTransferHandler;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseWheelEvent;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.ResourceBundle;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Generated;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import org.xml.sax.SAXException;
import sun.awt.shell.ShellFolder;
import javax.swing.Timer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeCellRenderer;
import sun.font.Decoration.Label;

/**
 *
 * @author letuan
 */
public class MainFrame extends javax.swing.JFrame {

    private static Color imgCurrentNavImage;
    private static Color khaki = new Color(240, 230, 139);
    private static Color lemonChiffton = new Color(255, 250, 204);
    private static Color whiteSmoke = new Color(245, 245, 245);
    private String strActiveScreen = "";

    /** Creates new form MainFrame */
    public MainFrame() throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException, FileNotFoundException, NoSuchAlgorithmException, Exception {
        initComponents();
        KhoiTaoThanhPhan();

        //LoadDanhSachAccount();
        //docMailKhiKhoiDong();

        //laySoLuongMailHienCo();
        //////////////////////////
        TaoThuMucLocalFolder();
        MyTree.TreeMail.loadElemsIntoTreeMail(treeMail);
        MyTree.TreeContact.loadElemIntoTreeContact(treeContact);
        ///////////////////////////
        final MouseListener mouseListener = new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent mouseEvent) {
                JPanel panel = (JPanel) mouseEvent.getSource();
                imgCurrentNavImage = panel.getBackground();

                //anh xa tu RGB qua HSB
                //ket qua tra ve se duoc luu trong panelColor
                Color panelColor = panel.getBackground();
                float[] colorPanel = null;
                colorPanel = Color.RGBtoHSB(panelColor.getRed(), panelColor.getGreen(), panelColor.getBlue(), colorPanel);

                //anh xa tu RGB qua HSB
                //ket qua tra ve se duoc luu trong colorBase
                float[] colorBase = null;
                colorBase = Color.RGBtoHSB(240, 230, 139, colorBase);

                if (!compareColor(colorPanel, colorBase)) {
                    panel.setBackground(whiteSmoke);
                }
            }

            public void mouseExited(MouseEvent mouseEvent) {
                JPanel panel = (JPanel) mouseEvent.getSource();

                panel.setBackground(imgCurrentNavImage);
                panel.setCursor(Cursor.getDefaultCursor());
            }

            public void mouseReleased(MouseEvent mouseEvent) {
                JPanel panel = (JPanel) mouseEvent.getSource();

                imgCurrentNavImage = khaki;
                panel.setBackground(khaki);
                Navigate(panel.getName());
            }
        };

        MouseListener mouseListener_Screen = new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent mouseEvent) {
                JLabel label = (JLabel) mouseEvent.getSource();
                imgCurrentNavImage = label.getForeground();
                label.setForeground(Color.blue);
                Font italic = new Font(label.getFont().getName(), Font.ITALIC, label.getFont().getSize());
                label.setFont(italic);
            }

            @Override
            public void mouseExited(MouseEvent mouseEvent) {
                JLabel label = (JLabel) mouseEvent.getSource();

                label.setForeground(imgCurrentNavImage);
                label.setCursor(Cursor.getDefaultCursor());
                Font plain = new Font(label.getFont().getName(), Font.PLAIN, label.getFont().getSize());
                label.setFont(plain);
            }

            public void mouseReleased(MouseEvent mouseEvent) {
                JLabel label = (JLabel) mouseEvent.getSource();
                try {
                    NavigateQuanLy(label.getName());
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        };

        pnlQuanLyMail.addMouseListener(mouseListener);
        pnlQuanLyCalendar.addMouseListener(mouseListener);
        pnlQuanLyContact.addMouseListener(mouseListener);

        lblLocalFolderScreen_ViewSettingAccount.addMouseListener(mouseListener_Screen);
        lblLocalFolderSceen_CreateAccount.addMouseListener(mouseListener_Screen);
        lblLocalFolderScreen_SearchMessage.addMouseListener(mouseListener_Screen);
        lblLocalFolderScreen_SearchContacts.addMouseListener(mouseListener_Screen);

        lblMailAccountScreen_ReadMessage.addMouseListener(mouseListener_Screen);
        lblMailAccountScreen_CreateAccount.addMouseListener(mouseListener_Screen);
        lblMailAccountScreen_SearchContacts.addMouseListener(mouseListener_Screen);
        lblMailAccountScreen_SearchMessage.addMouseListener(mouseListener_Screen);
        lblMailAccountScreen_ViewSettingAccount.addMouseListener(mouseListener_Screen);
        lblMailAccountScreen_WriteMessage.addMouseListener(mouseListener_Screen);

    //UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    //SwingUtilities.updateComponentTreeUI(this);
    //////////////////////////////////////////

    }

    public JTree getTreeMail() {
        return this.treeMail;
    }


    /*public void laySoLuongMailHienCo() throws ParserConfigurationException, ParserConfigurationException, SAXException, IOException {
    XL_DanhSachMail dsmail = new XL_DanhSachMail();
    GlobalVariables.SoLuongMailHienCo =
    dsmail.DocSoLuongMailHienCo(BienDungChung.GlobalVariables.g_strTenTapTinMail);

    }*/
    /**
     *Tao thu muc local folder, mac dinh
     */
    public void TaoThuMucLocalFolder() {
        //dau tien tao thu muc local folder (mac dinh)
        LopDungChung.ThaoTacThuMuc.createFolder("D:\\", "Outlook2009_Password");
        LopDungChung.ThaoTacThuMuc.createFolder("D:\\", "Outlook2009_letuan");
        LopDungChung.ThaoTacThuMuc.createFolder("D:\\Outlook2009_letuan\\", "Local Folders");
        LopDungChung.ThaoTacThuMuc.createFolder("D:\\Outlook2009_letuan\\Local Folders\\", "Trash");
    }

    /**
     *Tao thu muc ung voi Account duoc tao, chua file
     */
    public void TaoThuMucAccount(String AccountName) {
        //thu muc accout chua file
        LopDungChung.ThaoTacThuMuc.createFolder("D:\\Outlook2009_letuan\\",
                AccountName);
        LopDungChung.ThaoTacThuMuc.createFolder("D:\\Outlook2009_letuan\\" +
                AccountName + "\\", "Inbox");
        LopDungChung.ThaoTacThuMuc.createFolder("D:\\Outlook2009_letuan\\" +
                AccountName + "\\", "Sent");
        LopDungChung.ThaoTacThuMuc.createFolder("D:\\Outlook2009_letuan\\" +
                AccountName + "\\", "Trash");
    }

    /**
     *ham quan ly tung thao tac doi voi tung chuc nang
     * @param shortCut
     */
    public void NavigateQuanLy(String shortCut) throws FileNotFoundException {
        if (shortCut.equals("lblLocalFolderSceen_CreateAccount") ||
                shortCut.equals("lblMailAccountScreen_CreateAccount")) {
            Create_Account.Account_Wizard dlg = new Create_Account.Account_Wizard(null, true);
            dlg.show();

            if (dlg.isDaThemAccount()) {
                TaoThuMucAccount(BienDungChung.GlobalVariables.ActiveAccount.getAccountName());
                MyTree.TreeMail.loadElemsIntoTreeMail(treeMail);

                Create_Account.XacNhanAccout xacnhandlg = new Create_Account.XacNhanAccout(null, true,
                        pnlLocalfolderScreen, pnlMailAccountScreen, pnlTypeViewlScreen, tblMail, treeMail);
                xacnhandlg.show();
            }
        } else if (shortCut.equals("lblLocalFolderScreen_ViewSettingAccount") ||
                shortCut.equals("lblMailAccountScreen_ViewSettingAccount")) {
            Create_Account.AccountSetting dlg = new Create_Account.AccountSetting(null, true, GlobalVariables.TapHopAccount);
            dlg.show();
            if (dlg.isUpdateSuccess()) {
                MyTree.TreeMail.loadElemsIntoTreeMail(treeMail);
            }
        } else if (shortCut.equals("lblLocalFolderScreen_SearchMessage") ||
                shortCut.equals("lblMailAccountScreen_SearchMessage")) {
            MySearch.SearchMail dlg = new MySearch.SearchMail(null, true);
            dlg.show();
        } else if (shortCut.equals("lblLocalFolderScreen_SearchContacts") ||
                shortCut.equals("lblMailAccountScreen_SearchContacts")) {
            MySearch.SearchContact dlg = new MySearch.SearchContact(null, true);
            dlg.show();
        } else if (shortCut.equals("lblMailAccountScreen_ReadMessage")) {
            try {
                xemMail(nodeAccount);
                pnlLocalfolderScreen.setVisible(false);
                pnlMailAccountScreen.setVisible(false);
                pnlTypeViewlScreen.setVisible(true);
            } catch (ParserConfigurationException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SAXException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (XPathExpressionException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (shortCut.equals("lblMailAccountScreen_WriteMessage")) {
            Connect.SendMail dlg = new Connect.SendMail(null, true);
            dlg.show();
        }
    }

    private void VisiblePanel(JPanel objPanel) {
        objPanel.setVisible(true);
    }

    private void InvisiblePanel(JPanel objPanel, JPanel objNavControl) {
        objPanel.setVisible(false);
        if (objNavControl.getName().equals("pnlQuanLyMail") ||
                objNavControl.getName().equals("pnlQuanLyCalendar") ||
                objNavControl.getName().equals("pnlQuanLyContact") ||
                objNavControl.getName().equals("pnlQuanLyTask")) {
            objNavControl.setBackground(lemonChiffton);
        } else {
            objNavControl.setBackground(Color.white);
        }
    }

    public void hienToolbarMail() {
        toolbar_btnGetMail.setVisible(true);
        toolbar_btnWrite.setVisible(true);
        toolbar_btnAddressBook.setVisible(true);
        toolbar_btnJunk.setVisible(true);
        toolbar_btnPrint.setVisible(true);
        toolbar_btnReply.setVisible(true);
        toolbar_btnTag.setVisible(true);
        toolbar_btnDelete.setVisible(true);
        jSeparator1.setVisible(true);

        toolbar_btnDeleteContact.setVisible(false);
        toolbar_btnNewMessageToContact.setVisible(false);
        toolbar_btnNewContact.setVisible(false);
        toolbar_btnFindContact.setVisible(false);
        jSeparator3.setVisible(false);
        toolbar_btnEditContact.setVisible(false);

        toolbar_btnNewTask.setVisible(false);
        toolbar_btnEditTask.setVisible(false);
        toolbar_btnDeleteTask.setVisible(false);
    }

    public void hienToolbarContact() {
        toolbar_btnGetMail.setVisible(false);
        toolbar_btnWrite.setVisible(false);
        toolbar_btnAddressBook.setVisible(false);
        toolbar_btnJunk.setVisible(false);
        toolbar_btnPrint.setVisible(false);
        toolbar_btnReply.setVisible(false);
        toolbar_btnTag.setVisible(false);
        toolbar_btnDelete.setVisible(false);
        jSeparator1.setVisible(false);

        toolbar_btnNewTask.setVisible(false);
        toolbar_btnEditTask.setVisible(false);
        toolbar_btnDeleteTask.setVisible(false);

        toolbar_btnDeleteContact.setVisible(true);
        toolbar_btnNewMessageToContact.setVisible(true);
        toolbar_btnNewContact.setVisible(true);
        toolbar_btnFindContact.setVisible(true);
        jSeparator3.setVisible(true);
        toolbar_btnEditContact.setVisible(true);
    }

    public void hienToolbarCalendar() {
        toolbar_btnGetMail.setVisible(false);
        toolbar_btnWrite.setVisible(false);
        toolbar_btnAddressBook.setVisible(false);
        toolbar_btnJunk.setVisible(false);
        toolbar_btnPrint.setVisible(false);
        toolbar_btnReply.setVisible(false);
        toolbar_btnTag.setVisible(false);
        toolbar_btnDelete.setVisible(false);
        jSeparator1.setVisible(false);

        toolbar_btnDeleteContact.setVisible(false);
        toolbar_btnNewMessageToContact.setVisible(false);
        toolbar_btnNewContact.setVisible(false);
        toolbar_btnFindContact.setVisible(false);
        jSeparator3.setVisible(false);
        toolbar_btnEditContact.setVisible(false);

        toolbar_btnNewTask.setVisible(true);
        toolbar_btnEditTask.setVisible(true);
        toolbar_btnDeleteTask.setVisible(true);
    }
    JCalendar calendar = null;

    private void Navigate(String Shortcut) {
        Component components1[] = pnlQuanLyBase.getComponents();
        for (int i = 0; i < components1.length; i++) {
            if (components1[i].getName() != null) {
                if (components1[i].getName().equals("pnlQuanLyContact")) {
                    if (Shortcut.equals("pnlQuanLyContact")) {
                        VisiblePanel(pnlChucNangContact);
                        hienToolbarContact();
                    } else {
                        InvisiblePanel(pnlChucNangContact, pnlQuanLyContact);
                    }
                } else if (components1[i].getName().equals("pnlQuanLyMail")) {
                    if (Shortcut.equals("pnlQuanLyMail")) {
                        VisiblePanel(pnlChucNangMail);
                        hienToolbarMail();
                    } else {
                        InvisiblePanel(pnlChucNangMail, pnlQuanLyMail);
                    }
                } else if (components1[i].getName().equals("pnlQuanLyCalendar")) {
                    if (Shortcut.equals("pnlQuanLyCalendar")) {
                        if (calendar == null) {
                            calendar = new JCalendar(tblCalendar_GhiChu, tblCalendar_Month);
                            pnlChucNangCalendar.add(calendar);
                            Date dateChooser = calendar.getDate();
                            String strDate =
                                    DateFormat.getInstance().format(dateChooser);
                            String[] thanhPhanNgay = strDate.split(" ");
                            String date = thanhPhanNgay[0];
                            if (this.jTabbedPane1.getSelectedIndex() == 0) {
                                loadDanhSachCongViec(date);
                            } else if (this.jTabbedPane1.getSelectedIndex() == 1) {
                                MonthCalendar.TableMonthTask.disableDayNotBelongMonth(this.tblCalendar_Month, calendar.getCalendar());
                            }
                        }
                        hienToolbarCalendar();
                        VisiblePanel(pnlChucNangCalendar);
                        NavigatePanelContactView("pnlCalendarScreen");
                    } else {
                        InvisiblePanel(pnlChucNangCalendar, pnlQuanLyCalendar);
                    }
                }
            }
        }
    }

    public void loadDanhSachCongViec(String Ngay) {
        XL_CalendarTask task = new XL_CalendarTask();
        if (task.Doc(GlobalVariables.g_strTenTapTinCalendarTask, Ngay)) {
            MyTable.TableCalendarTask.loadFolderIntoTable(tblCalendar_GhiChu, task, Ngay);
        }
    }

    private static boolean compareColor(float[] a, float[] b) {
        if (a[0] == b[0] && a[1] == b[1] && a[2] == b[2]) {
            return true;
        }
        return false;
    }
    private TreeTransferHandler transfer;

    public void KhoiTaoThanhPhan() {
        this.lblQuanLyMail.setText("    Mail");
        this.lblQuanLyCalendar.setText("    Calendar");
        this.lblQuanLyContact.setText("    Contact");
        pnlAttAndTag.setVisible(false);
        hienToolbarMail();

        transfer = new TreeTransferHandler();
        this.treeMail.setDragEnabled(true);
        this.treeMail.setTransferHandler(transfer);

        JTableHeader header = tblCalendar_ThoiGian.getTableHeader();
        header.setFont(new Font("Microsoft Sans Serif", 1, 12));
        header.setBackground(new Color(243, 217, 152));

        header = tblCalendar_GhiChu.getTableHeader();
        header.setFont(new Font("Microsoft Sans Serif", 1, 12));
        header.setBackground(new Color(243, 217, 152));

        header = tblCalendar_Month.getTableHeader();
        header.setFont(new Font("Microsoft Sans Serif", 0, 12));
        header.setBackground(new Color(195, 215, 255));
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        popMail = new javax.swing.JPopupMenu();
        memMail_NewFolder = new javax.swing.JMenuItem();
        memMail_DeleteFolder = new javax.swing.JMenuItem();
        popClickIntoEmaiAddressl = new javax.swing.JPopupMenu();
        memItemAddToContacts = new javax.swing.JMenuItem();
        memItemComposeMailTo = new javax.swing.JMenuItem();
        popTag = new javax.swing.JPopupMenu();
        memTag_RemoveAlltag = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JSeparator();
        memTag_Important = new javax.swing.JMenuItem();
        memTag_Work = new javax.swing.JMenuItem();
        memTag_Personal = new javax.swing.JMenuItem();
        memTag_Todo = new javax.swing.JMenuItem();
        memTag_Later = new javax.swing.JMenuItem();
        popProcessMail = new javax.swing.JPopupMenu();
        popMoveTo = new javax.swing.JMenu();
        popCopyTo = new javax.swing.JMenu();
        jSeparator5 = new javax.swing.JSeparator();
        popMark = new javax.swing.JMenu();
        popMemItemAddStar = new javax.swing.JMenuItem();
        popMemItemAddJunk = new javax.swing.JMenuItem();
        jPanel5 = new javax.swing.JPanel();
        toolbar_Mail = new javax.swing.JToolBar();
        toolbar_btnGetMail = new javax.swing.JButton();
        toolbar_btnWrite = new javax.swing.JButton();
        toolbar_btnAddressBook = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JToolBar.Separator();
        toolbar_btnReply = new javax.swing.JButton();
        toolbar_btnTag = new javax.swing.JButton();
        toolbar_btnDelete = new javax.swing.JButton();
        toolbar_btnJunk = new javax.swing.JButton();
        toolbar_btnPrint = new javax.swing.JButton();
        toolbar_btnNewContact = new javax.swing.JButton();
        toolbar_btnEditContact = new javax.swing.JButton();
        toolbar_btnDeleteContact = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JToolBar.Separator();
        toolbar_btnNewMessageToContact = new javax.swing.JButton();
        toolbar_btnFindContact = new javax.swing.JButton();
        toolbar_btnNewTask = new javax.swing.JButton();
        toolbar_btnEditTask = new javax.swing.JButton();
        toolbar_btnDeleteTask = new javax.swing.JButton();
        jSplitPane1 = new javax.swing.JSplitPane();
        jLayeredPane2 = new javax.swing.JLayeredPane();
        pnlMailAccountScreen = new javax.swing.JPanel();
        lblMailAccountScreen_CreateAccount = new javax.swing.JLabel();
        lblMailAccountScreen_ViewSettingAccount = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        lblMaiAccountScreen_ReadMessage = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        lblMailAccountScreen_SearchContacts = new javax.swing.JLabel();
        lblMailAccountScreen_SearchMessage = new javax.swing.JLabel();
        lblMailAccountScreen_WriteMessage = new javax.swing.JLabel();
        lblMailAccountScreen_ReadMessage = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        pnlLocalfolderScreen = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        lblLocalFolderScreen_ViewSettingAccount = new javax.swing.JLabel();
        lblLocalFolderSceen_CreateAccount = new javax.swing.JLabel();
        lblLocalFolderScreen_SearchContacts = new javax.swing.JLabel();
        lblLocalFolderScreen_SearchMessage = new javax.swing.JLabel();
        pnlTypeViewlScreen = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        lblCurrentTypeView = new javax.swing.JLabel();
        jSplitPane2 = new javax.swing.JSplitPane();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tblMail = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        lblTypeView_Subject = new javax.swing.JLabel();
        lblTypeView_From = new javax.swing.JLabel();
        pnlTypeView_To = new javax.swing.JPanel();
        pnlTypeView_CC = new javax.swing.JPanel();
        pnlContent = new javax.swing.JPanel();
        pnlAttAndTag = new javax.swing.JPanel();
        pnlTypeView_Tag = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        lblTag = new javax.swing.JLabel();
        pnlTypeView_Attachments = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtTypeView_Content = new javax.swing.JTextArea();
        pnlContact_AddressCard = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        lblCurrentTypeView1 = new javax.swing.JLabel();
        pnlContact_AddressCard_Tong = new javax.swing.JPanel();
        pnlContact_DetailAddressCard = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        lblCurrentTypeView2 = new javax.swing.JLabel();
        pnlContact_DetailAddress_Tong = new javax.swing.JPanel();
        pnlContact_BusinessCard = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        lblCurrentTypeView3 = new javax.swing.JLabel();
        pnlContact_Bus_Tong = new javax.swing.JPanel();
        pnlContact_PhoneList = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        lblCurrentTypeView4 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblContact_PhoneList = new javax.swing.JTable();
        pnlContact_ByCategory = new javax.swing.JPanel();
        jPanel28 = new javax.swing.JPanel();
        lblCurrentTypeView5 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        tblContactByCateGory = new javax.swing.JTable();
        pnlContact_ByCompany = new javax.swing.JPanel();
        jPanel30 = new javax.swing.JPanel();
        lblCurrentTypeView6 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        tblByCompany = new javax.swing.JTable();
        pnlContact_OutlookDataField = new javax.swing.JPanel();
        jPanel32 = new javax.swing.JPanel();
        lblCurrentTypeView7 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        tblOutlookDataField = new javax.swing.JTable();
        pnlCalendarScreen = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        lblCurrentTypeView8 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        pnlCalendar_TableDay = new javax.swing.JPanel();
        jSplitPane3 = new javax.swing.JSplitPane();
        scroll_GhiChu = new javax.swing.JScrollPane();
        tblCalendar_GhiChu = new javax.swing.JTable();
        scroll_ThoiGian = new javax.swing.JScrollPane();
        tblCalendar_ThoiGian = new javax.swing.JTable();
        pnlCalendar_TableMonth = new javax.swing.JPanel();
        scroll_GhiChu1 = new javax.swing.JScrollPane();
        tblCalendar_Month = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        pnlQuanLyBase = new javax.swing.JPanel();
        pnlQuanLyMail = new javax.swing.JPanel();
        lblQuanLyMail = new javax.swing.JLabel();
        pnlQuanLyContact = new javax.swing.JPanel();
        lblQuanLyContact = new javax.swing.JLabel();
        pnlQuanLyCalendar = new javax.swing.JPanel();
        lblQuanLyCalendar = new javax.swing.JLabel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        pnlChucNangMail = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        treeMail = new javax.swing.JTree();
        pnlChucNangCalendar = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        pnlChucNangContact = new javax.swing.JPanel();
        jPanel34 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        treeContact = new javax.swing.JTree();
        jLabel10 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        memItemSearchMessages = new javax.swing.JMenuItem();
        memItemSearchContacts = new javax.swing.JMenuItem();
        memLanguage = new javax.swing.JMenu();
        memItemEnglish = new javax.swing.JMenuItem();
        memItemVieNam = new javax.swing.JMenuItem();
        memHelp = new javax.swing.JMenu();
        memItemJavaDoc = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JSeparator();
        memItemTacGia = new javax.swing.JMenuItem();

        memMail_NewFolder.setText("New Folder");
        memMail_NewFolder.setName("memMail_NewFolder"); // NOI18N
        memMail_NewFolder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memMail_NewFolderActionPerformed(evt);
            }
        });
        popMail.add(memMail_NewFolder);

        memMail_DeleteFolder.setText("Delete Folder");
        memMail_DeleteFolder.setName("memMail_DeleteFolder"); // NOI18N
        memMail_DeleteFolder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memMail_DeleteFolderActionPerformed(evt);
            }
        });
        popMail.add(memMail_DeleteFolder);

        memItemAddToContacts.setText("Add a new Contact");
        memItemAddToContacts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memItemAddToContactsActionPerformed(evt);
            }
        });
        popClickIntoEmaiAddressl.add(memItemAddToContacts);

        memItemComposeMailTo.setText("Compose mail to");
        memItemComposeMailTo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memItemComposeMailToActionPerformed(evt);
            }
        });
        popClickIntoEmaiAddressl.add(memItemComposeMailTo);

        memTag_RemoveAlltag.setText("Remove All Tags");
        memTag_RemoveAlltag.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memTag_RemoveAlltagActionPerformed(evt);
            }
        });
        popTag.add(memTag_RemoveAlltag);
        popTag.add(jSeparator4);

        memTag_Important.setForeground(java.awt.Color.red);
        memTag_Important.setText("Important");
        memTag_Important.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memTag_ImportantActionPerformed(evt);
            }
        });
        popTag.add(memTag_Important);

        memTag_Work.setForeground(java.awt.Color.orange);
        memTag_Work.setText("Work");
        memTag_Work.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memTag_WorkActionPerformed(evt);
            }
        });
        popTag.add(memTag_Work);

        memTag_Personal.setForeground(new java.awt.Color(0, 153, 51));
        memTag_Personal.setText("Personal");
        memTag_Personal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memTag_PersonalActionPerformed(evt);
            }
        });
        popTag.add(memTag_Personal);

        memTag_Todo.setForeground(java.awt.Color.blue);
        memTag_Todo.setText("To do");
        memTag_Todo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memTag_TodoActionPerformed(evt);
            }
        });
        popTag.add(memTag_Todo);

        memTag_Later.setForeground(new java.awt.Color(153, 0, 153));
        memTag_Later.setText("Later");
        memTag_Later.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memTag_LaterActionPerformed(evt);
            }
        });
        popTag.add(memTag_Later);

        popMoveTo.setText("Move To");
        popProcessMail.add(popMoveTo);

        popCopyTo.setText("Copy To");
        popProcessMail.add(popCopyTo);
        popProcessMail.add(jSeparator5);

        popMark.setText("Mark");

        popMemItemAddStar.setText("Add Star");
        popMemItemAddStar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                popMemItemAddStarActionPerformed(evt);
            }
        });
        popMark.add(popMemItemAddStar);

        popMemItemAddJunk.setText("Add Junk");
        popMemItemAddJunk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                popMemItemAddJunkActionPerformed(evt);
            }
        });
        popMark.add(popMemItemAddJunk);

        popProcessMail.add(popMark);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("My Outlook 2009");
        setResizable(false);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });

        jPanel5.setLayout(new java.awt.BorderLayout());

        toolbar_Mail.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        toolbar_btnGetMail.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Get mail.gif"))); // NOI18N
        toolbar_btnGetMail.setText("Get mail");
        toolbar_btnGetMail.setToolTipText("Get new message");
        toolbar_btnGetMail.setBorderPainted(false);
        toolbar_btnGetMail.setFocusable(false);
        toolbar_btnGetMail.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnGetMail.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnGetMail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnGetMailActionPerformed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnGetMail);

        toolbar_btnWrite.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/write.png"))); // NOI18N
        toolbar_btnWrite.setText("Write");
        toolbar_btnWrite.setToolTipText("Create a new message");
        toolbar_btnWrite.setBorderPainted(false);
        toolbar_btnWrite.setFocusable(false);
        toolbar_btnWrite.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnWrite.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnWrite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnWriteActionPerformed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnWrite);

        toolbar_btnAddressBook.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/address book.png"))); // NOI18N
        toolbar_btnAddressBook.setText("Address Book");
        toolbar_btnAddressBook.setToolTipText("Go to the adress book");
        toolbar_btnAddressBook.setBorderPainted(false);
        toolbar_btnAddressBook.setFocusable(false);
        toolbar_btnAddressBook.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnAddressBook.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnAddressBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnAddressBookActionPerformed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnAddressBook);
        toolbar_Mail.add(jSeparator1);

        toolbar_btnReply.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/reply.gif"))); // NOI18N
        toolbar_btnReply.setText("Reply");
        toolbar_btnReply.setToolTipText("Reply to the message");
        toolbar_btnReply.setBorderPainted(false);
        toolbar_btnReply.setFocusable(false);
        toolbar_btnReply.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnReply.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnReply.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnReplyActionPerformed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnReply);

        toolbar_btnTag.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/tag.png"))); // NOI18N
        toolbar_btnTag.setText("Tag");
        toolbar_btnTag.setToolTipText("Tag messages");
        toolbar_btnTag.setBorderPainted(false);
        toolbar_btnTag.setFocusable(false);
        toolbar_btnTag.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnTag.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnTag.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                toolbar_btnTagMousePressed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnTag);

        toolbar_btnDelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Delete.png"))); // NOI18N
        toolbar_btnDelete.setText("Delete");
        toolbar_btnDelete.setToolTipText("Delete seleced messages or folders");
        toolbar_btnDelete.setBorderPainted(false);
        toolbar_btnDelete.setFocusable(false);
        toolbar_btnDelete.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnDelete.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnDeleteActionPerformed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnDelete);

        toolbar_btnJunk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/junk.png"))); // NOI18N
        toolbar_btnJunk.setText("Junk");
        toolbar_btnJunk.setToolTipText("Mark seleted messages as junk");
        toolbar_btnJunk.setBorderPainted(false);
        toolbar_btnJunk.setFocusable(false);
        toolbar_btnJunk.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnJunk.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnJunk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnJunkActionPerformed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnJunk);

        toolbar_btnPrint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/printer.png"))); // NOI18N
        toolbar_btnPrint.setText("Print");
        toolbar_btnPrint.setToolTipText("Print the messages");
        toolbar_btnPrint.setBorderPainted(false);
        toolbar_btnPrint.setFocusable(false);
        toolbar_btnPrint.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnPrint.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnPrintActionPerformed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnPrint);

        toolbar_btnNewContact.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/new_contact.png"))); // NOI18N
        toolbar_btnNewContact.setText("New Contact");
        toolbar_btnNewContact.setToolTipText("Create a new Contact");
        toolbar_btnNewContact.setBorderPainted(false);
        toolbar_btnNewContact.setFocusable(false);
        toolbar_btnNewContact.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnNewContact.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnNewContact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnNewContactActionPerformed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnNewContact);

        toolbar_btnEditContact.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/edit.gif"))); // NOI18N
        toolbar_btnEditContact.setText("Edit");
        toolbar_btnEditContact.setToolTipText("Edit a Contact");
        toolbar_btnEditContact.setBorderPainted(false);
        toolbar_btnEditContact.setFocusable(false);
        toolbar_btnEditContact.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnEditContact.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnEditContact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnEditContactActionPerformed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnEditContact);

        toolbar_btnDeleteContact.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Delete.png"))); // NOI18N
        toolbar_btnDeleteContact.setText("Delete");
        toolbar_btnDeleteContact.setToolTipText("Delete a Contact");
        toolbar_btnDeleteContact.setBorderPainted(false);
        toolbar_btnDeleteContact.setFocusable(false);
        toolbar_btnDeleteContact.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnDeleteContact.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnDeleteContact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnDeleteContactActionPerformed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnDeleteContact);
        toolbar_Mail.add(jSeparator3);

        toolbar_btnNewMessageToContact.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/new message to contact.gif"))); // NOI18N
        toolbar_btnNewMessageToContact.setText("New Message");
        toolbar_btnNewMessageToContact.setToolTipText("New message to contact");
        toolbar_btnNewMessageToContact.setBorderPainted(false);
        toolbar_btnNewMessageToContact.setFocusable(false);
        toolbar_btnNewMessageToContact.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnNewMessageToContact.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnNewMessageToContact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnNewMessageToContactActionPerformed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnNewMessageToContact);

        toolbar_btnFindContact.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/find contact.gif"))); // NOI18N
        toolbar_btnFindContact.setText("Find Contact");
        toolbar_btnFindContact.setToolTipText("Find info of Contact");
        toolbar_btnFindContact.setBorderPainted(false);
        toolbar_btnFindContact.setFocusable(false);
        toolbar_btnFindContact.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnFindContact.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnFindContact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnFindContactActionPerformed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnFindContact);

        toolbar_btnNewTask.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/addTask.png"))); // NOI18N
        toolbar_btnNewTask.setText("Add task");
        toolbar_btnNewTask.setToolTipText("Create a new Task");
        toolbar_btnNewTask.setBorderPainted(false);
        toolbar_btnNewTask.setFocusable(false);
        toolbar_btnNewTask.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnNewTask.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnNewTask.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnNewTaskActionPerformed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnNewTask);

        toolbar_btnEditTask.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/edit.gif"))); // NOI18N
        toolbar_btnEditTask.setText("Edit");
        toolbar_btnEditTask.setToolTipText("Edit a Task");
        toolbar_btnEditTask.setBorderPainted(false);
        toolbar_btnEditTask.setFocusable(false);
        toolbar_btnEditTask.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnEditTask.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnEditTask.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnEditTaskActionPerformed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnEditTask);

        toolbar_btnDeleteTask.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Delete.png"))); // NOI18N
        toolbar_btnDeleteTask.setText("Delete");
        toolbar_btnDeleteTask.setToolTipText("Delete a Task");
        toolbar_btnDeleteTask.setBorderPainted(false);
        toolbar_btnDeleteTask.setFocusable(false);
        toolbar_btnDeleteTask.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnDeleteTask.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnDeleteTask.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnDeleteTaskActionPerformed(evt);
            }
        });
        toolbar_Mail.add(toolbar_btnDeleteTask);

        jPanel5.add(toolbar_Mail, java.awt.BorderLayout.NORTH);

        jSplitPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jSplitPane1.setDividerLocation(182);
        jSplitPane1.setDividerSize(3);

        jLayeredPane2.setBackground(java.awt.Color.white);
        jLayeredPane2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        pnlMailAccountScreen.setBackground(new java.awt.Color(240, 255, 255));
        pnlMailAccountScreen.setName("pnlMailAccountScreen"); // NOI18N

        lblMailAccountScreen_CreateAccount.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblMailAccountScreen_CreateAccount.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/create new acc.png"))); // NOI18N
        lblMailAccountScreen_CreateAccount.setText("  Create a new account");
        lblMailAccountScreen_CreateAccount.setName("lblMailAccountScreen_CreateAccount"); // NOI18N

        lblMailAccountScreen_ViewSettingAccount.setFont(new java.awt.Font("Tahoma", 0, 14));
        lblMailAccountScreen_ViewSettingAccount.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/setting acc.png"))); // NOI18N
        lblMailAccountScreen_ViewSettingAccount.setText("  View setting for this account");
        lblMailAccountScreen_ViewSettingAccount.setName("lblMailAccountScreen_ViewSettingAccount"); // NOI18N

        jPanel17.setBackground(java.awt.SystemColor.inactiveCaptionText);
        jPanel17.setForeground(new java.awt.Color(255, 255, 255));

        jLabel29.setFont(new java.awt.Font("Times New Roman", 1, 16));
        jLabel29.setForeground(new java.awt.Color(204, 0, 51));
        jLabel29.setText("Advanced features");

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addComponent(jLabel29)
                .addContainerGap(320, Short.MAX_VALUE))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel29)
        );

        lblMaiAccountScreen_ReadMessage.setFont(new java.awt.Font("Times New Roman", 1, 26));
        lblMaiAccountScreen_ReadMessage.setForeground(new java.awt.Color(0, 153, 51));
        lblMaiAccountScreen_ReadMessage.setText("My Outlook 2009 - Local folder");

        jPanel18.setBackground(java.awt.SystemColor.inactiveCaptionText);
        jPanel18.setForeground(new java.awt.Color(255, 255, 255));

        jLabel30.setFont(new java.awt.Font("Times New Roman", 1, 16));
        jLabel30.setForeground(new java.awt.Color(204, 0, 51));
        jLabel30.setText("Accounts");

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addComponent(jLabel30)
                .addContainerGap(384, Short.MAX_VALUE))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel30)
        );

        lblMailAccountScreen_SearchContacts.setFont(new java.awt.Font("Tahoma", 0, 14));
        lblMailAccountScreen_SearchContacts.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/find contact.gif"))); // NOI18N
        lblMailAccountScreen_SearchContacts.setText("  Search Contacts");
        lblMailAccountScreen_SearchContacts.setName("lblMailAccountScreen_SearchContacts"); // NOI18N

        lblMailAccountScreen_SearchMessage.setFont(new java.awt.Font("Tahoma", 0, 14));
        lblMailAccountScreen_SearchMessage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search message.png"))); // NOI18N
        lblMailAccountScreen_SearchMessage.setText("  Search messages");
        lblMailAccountScreen_SearchMessage.setName("lblMailAccountScreen_SearchMessage"); // NOI18N

        lblMailAccountScreen_WriteMessage.setFont(new java.awt.Font("Tahoma", 0, 14));
        lblMailAccountScreen_WriteMessage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/write a new message.gif"))); // NOI18N
        lblMailAccountScreen_WriteMessage.setText("  Write a new message");
        lblMailAccountScreen_WriteMessage.setName("lblMailAccountScreen_WriteMessage"); // NOI18N

        lblMailAccountScreen_ReadMessage.setFont(new java.awt.Font("Tahoma", 0, 14));
        lblMailAccountScreen_ReadMessage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/read message.png"))); // NOI18N
        lblMailAccountScreen_ReadMessage.setText("  Read messages");
        lblMailAccountScreen_ReadMessage.setName("lblMailAccountScreen_ReadMessage"); // NOI18N

        jPanel19.setBackground(java.awt.SystemColor.inactiveCaptionText);
        jPanel19.setForeground(new java.awt.Color(255, 255, 255));

        jLabel31.setFont(new java.awt.Font("Times New Roman", 1, 16));
        jLabel31.setForeground(new java.awt.Color(204, 0, 51));
        jLabel31.setText("Email");

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addComponent(jLabel31)
                .addContainerGap(407, Short.MAX_VALUE))
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel31)
        );

        javax.swing.GroupLayout pnlMailAccountScreenLayout = new javax.swing.GroupLayout(pnlMailAccountScreen);
        pnlMailAccountScreen.setLayout(pnlMailAccountScreenLayout);
        pnlMailAccountScreenLayout.setHorizontalGroup(
            pnlMailAccountScreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMailAccountScreenLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(pnlMailAccountScreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlMailAccountScreenLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(pnlMailAccountScreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblMailAccountScreen_CreateAccount, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblMailAccountScreen_ViewSettingAccount, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlMailAccountScreenLayout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(pnlMailAccountScreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblMailAccountScreen_SearchContacts, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblMailAccountScreen_SearchMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlMailAccountScreenLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(pnlMailAccountScreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblMailAccountScreen_WriteMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblMailAccountScreen_ReadMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(lblMaiAccountScreen_ReadMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 598, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlMailAccountScreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jPanel19, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel17, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel18, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(92, 92, 92))
        );
        pnlMailAccountScreenLayout.setVerticalGroup(
            pnlMailAccountScreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMailAccountScreenLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblMaiAccountScreen_ReadMessage)
                .addGap(18, 18, 18)
                .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblMailAccountScreen_ReadMessage)
                .addGap(29, 29, 29)
                .addComponent(lblMailAccountScreen_WriteMessage)
                .addGap(26, 26, 26)
                .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblMailAccountScreen_ViewSettingAccount)
                .addGap(29, 29, 29)
                .addComponent(lblMailAccountScreen_CreateAccount)
                .addGap(30, 30, 30)
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblMailAccountScreen_SearchMessage)
                .addGap(29, 29, 29)
                .addComponent(lblMailAccountScreen_SearchContacts)
                .addContainerGap(78, Short.MAX_VALUE))
        );

        pnlMailAccountScreen.setBounds(0, 0, 724, 505);
        jLayeredPane2.add(pnlMailAccountScreen, javax.swing.JLayeredPane.DEFAULT_LAYER);

        pnlLocalfolderScreen.setBackground(new java.awt.Color(240, 255, 255));
        pnlLocalfolderScreen.setName("pnlLocalfolderScreen"); // NOI18N

        jLabel25.setFont(new java.awt.Font("Times New Roman", 1, 26));
        jLabel25.setForeground(new java.awt.Color(0, 153, 51));
        jLabel25.setText("My Outlook 2009 - Local folder");

        jPanel14.setBackground(java.awt.SystemColor.inactiveCaptionText);
        jPanel14.setForeground(new java.awt.Color(255, 255, 255));

        jLabel26.setFont(new java.awt.Font("Times New Roman", 1, 16));
        jLabel26.setForeground(new java.awt.Color(204, 0, 51));
        jLabel26.setText("Accounts");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addComponent(jLabel26)
                .addContainerGap(384, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel26)
        );

        jPanel15.setBackground(java.awt.SystemColor.inactiveCaptionText);
        jPanel15.setForeground(new java.awt.Color(255, 255, 255));

        jLabel28.setFont(new java.awt.Font("Times New Roman", 1, 16));
        jLabel28.setForeground(new java.awt.Color(204, 0, 51));
        jLabel28.setText("Advanced features");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addComponent(jLabel28)
                .addContainerGap(320, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel28)
        );

        lblLocalFolderScreen_ViewSettingAccount.setFont(new java.awt.Font("Tahoma", 0, 14));
        lblLocalFolderScreen_ViewSettingAccount.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/setting acc.png"))); // NOI18N
        lblLocalFolderScreen_ViewSettingAccount.setText("  View setting for this account");
        lblLocalFolderScreen_ViewSettingAccount.setName("lblLocalFolderScreen_ViewSettingAccount"); // NOI18N

        lblLocalFolderSceen_CreateAccount.setFont(new java.awt.Font("Tahoma", 0, 14));
        lblLocalFolderSceen_CreateAccount.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/create new acc.png"))); // NOI18N
        lblLocalFolderSceen_CreateAccount.setText("  Create a new account");
        lblLocalFolderSceen_CreateAccount.setName("lblLocalFolderSceen_CreateAccount"); // NOI18N

        lblLocalFolderScreen_SearchContacts.setFont(new java.awt.Font("Tahoma", 0, 14));
        lblLocalFolderScreen_SearchContacts.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/find contact.gif"))); // NOI18N
        lblLocalFolderScreen_SearchContacts.setText("  Search Contacts");
        lblLocalFolderScreen_SearchContacts.setName("lblLocalFolderScreen_SearchContacts"); // NOI18N

        lblLocalFolderScreen_SearchMessage.setFont(new java.awt.Font("Tahoma", 0, 14));
        lblLocalFolderScreen_SearchMessage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search message.png"))); // NOI18N
        lblLocalFolderScreen_SearchMessage.setText("  Search messages");
        lblLocalFolderScreen_SearchMessage.setName("lblLocalFolderScreen_SearchMessage"); // NOI18N

        javax.swing.GroupLayout pnlLocalfolderScreenLayout = new javax.swing.GroupLayout(pnlLocalfolderScreen);
        pnlLocalfolderScreen.setLayout(pnlLocalfolderScreenLayout);
        pnlLocalfolderScreenLayout.setHorizontalGroup(
            pnlLocalfolderScreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLocalfolderScreenLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(pnlLocalfolderScreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlLocalfolderScreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jPanel15, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel14, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel25, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnlLocalfolderScreenLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(pnlLocalfolderScreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblLocalFolderSceen_CreateAccount, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblLocalFolderScreen_ViewSettingAccount, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlLocalfolderScreenLayout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(pnlLocalfolderScreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblLocalFolderScreen_SearchContacts, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblLocalFolderScreen_SearchMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(245, Short.MAX_VALUE))
        );
        pnlLocalfolderScreenLayout.setVerticalGroup(
            pnlLocalfolderScreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLocalfolderScreenLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel25)
                .addGap(18, 18, 18)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLocalFolderScreen_ViewSettingAccount)
                .addGap(29, 29, 29)
                .addComponent(lblLocalFolderSceen_CreateAccount)
                .addGap(30, 30, 30)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLocalFolderScreen_SearchMessage)
                .addGap(29, 29, 29)
                .addComponent(lblLocalFolderScreen_SearchContacts)
                .addContainerGap(204, Short.MAX_VALUE))
        );

        pnlLocalfolderScreen.setBounds(0, 0, 724, 505);
        jLayeredPane2.add(pnlLocalfolderScreen, javax.swing.JLayeredPane.PALETTE_LAYER);

        pnlTypeViewlScreen.setBackground(new java.awt.Color(240, 255, 255));
        pnlTypeViewlScreen.setName("pnlTypeViewlScreen"); // NOI18N
        pnlTypeViewlScreen.setLayout(new java.awt.BorderLayout());

        jPanel16.setBackground(java.awt.SystemColor.textHighlight);
        jPanel16.setForeground(new java.awt.Color(255, 255, 255));
        jPanel16.setPreferredSize(new java.awt.Dimension(679, 23));

        lblCurrentTypeView.setFont(new java.awt.Font("SansSerif", 1, 16));
        lblCurrentTypeView.setForeground(java.awt.Color.white);
        lblCurrentTypeView.setText("Inbox");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCurrentTypeView, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(585, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCurrentTypeView, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
        );

        pnlTypeViewlScreen.add(jPanel16, java.awt.BorderLayout.NORTH);

        jSplitPane2.setDividerLocation(300);
        jSplitPane2.setDividerSize(3);

        tblMail.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblMail.setFillsViewportHeight(true);
        tblMail.setRowHeight(18);
        tblMail.setShowHorizontalLines(false);
        tblMail.setShowVerticalLines(false);
        tblMail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblMailMousePressed(evt);
            }
        });
        jScrollPane5.setViewportView(tblMail);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 299, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 480, Short.MAX_VALUE)
        );

        jSplitPane2.setTopComponent(jPanel2);

        jPanel3.setLayout(new java.awt.BorderLayout());

        jPanel4.setBackground(new java.awt.Color(227, 239, 255));
        jPanel4.setPreferredSize(new java.awt.Dimension(351, 74));

        jLabel11.setText("Subject:");

        jLabel12.setText("From:");

        jLabel13.setText("To:");

        jLabel14.setText("CC:");

        lblTypeView_From.setForeground(java.awt.Color.blue);

        pnlTypeView_To.setBackground(new java.awt.Color(227, 239, 255));
        pnlTypeView_To.setLayout(new javax.swing.BoxLayout(pnlTypeView_To, javax.swing.BoxLayout.LINE_AXIS));

        pnlTypeView_CC.setBackground(new java.awt.Color(227, 239, 255));
        pnlTypeView_CC.setLayout(new javax.swing.BoxLayout(pnlTypeView_CC, javax.swing.BoxLayout.LINE_AXIS));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel12)
                    .addComponent(jLabel11)
                    .addComponent(jLabel13)
                    .addComponent(jLabel14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblTypeView_Subject)
                    .addComponent(lblTypeView_From)
                    .addComponent(pnlTypeView_CC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlTypeView_To, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(357, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(lblTypeView_Subject))
                .addGap(1, 1, 1)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(lblTypeView_From))
                .addGap(1, 1, 1)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(pnlTypeView_To, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addComponent(pnlTypeView_CC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel4, java.awt.BorderLayout.NORTH);

        pnlContent.setLayout(new java.awt.BorderLayout());

        pnlAttAndTag.setBackground(new java.awt.Color(227, 239, 255));
        pnlAttAndTag.setPreferredSize(new java.awt.Dimension(378, 36));
        pnlAttAndTag.setLayout(new java.awt.BorderLayout());

        pnlTypeView_Tag.setBackground(new java.awt.Color(227, 239, 255));
        pnlTypeView_Tag.setPreferredSize(new java.awt.Dimension(0, 18));

        jLabel9.setText("Tags:");

        lblTag.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11));
        lblTag.setText("Tags:");

        javax.swing.GroupLayout pnlTypeView_TagLayout = new javax.swing.GroupLayout(pnlTypeView_Tag);
        pnlTypeView_Tag.setLayout(pnlTypeView_TagLayout);
        pnlTypeView_TagLayout.setHorizontalGroup(
            pnlTypeView_TagLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTypeView_TagLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTag)
                .addContainerGap(326, Short.MAX_VALUE))
        );
        pnlTypeView_TagLayout.setVerticalGroup(
            pnlTypeView_TagLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTypeView_TagLayout.createSequentialGroup()
                .addGroup(pnlTypeView_TagLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(lblTag))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlAttAndTag.add(pnlTypeView_Tag, java.awt.BorderLayout.CENTER);

        pnlTypeView_Attachments.setBackground(new java.awt.Color(227, 239, 255));
        pnlTypeView_Attachments.setPreferredSize(new java.awt.Dimension(0, 18));
        pnlTypeView_Attachments.setLayout(new javax.swing.BoxLayout(pnlTypeView_Attachments, javax.swing.BoxLayout.LINE_AXIS));
        pnlAttAndTag.add(pnlTypeView_Attachments, java.awt.BorderLayout.NORTH);

        pnlContent.add(pnlAttAndTag, java.awt.BorderLayout.NORTH);

        jScrollPane6.setPreferredSize(new java.awt.Dimension(166, 340));

        txtTypeView_Content.setColumns(20);
        txtTypeView_Content.setEditable(false);
        txtTypeView_Content.setLineWrap(true);
        txtTypeView_Content.setRows(15);
        txtTypeView_Content.setWrapStyleWord(true);
        jScrollPane6.setViewportView(txtTypeView_Content);

        pnlContent.add(jScrollPane6, java.awt.BorderLayout.CENTER);

        jPanel3.add(pnlContent, java.awt.BorderLayout.CENTER);

        jSplitPane2.setRightComponent(jPanel3);

        pnlTypeViewlScreen.add(jSplitPane2, java.awt.BorderLayout.CENTER);

        pnlTypeViewlScreen.setBounds(0, 0, 724, 505);
        jLayeredPane2.add(pnlTypeViewlScreen, javax.swing.JLayeredPane.DEFAULT_LAYER);

        pnlContact_AddressCard.setBackground(new java.awt.Color(240, 255, 255));
        pnlContact_AddressCard.setName("pnlContact_AddressCard"); // NOI18N
        pnlContact_AddressCard.setLayout(new java.awt.BorderLayout());

        jPanel20.setBackground(java.awt.SystemColor.textHighlight);
        jPanel20.setForeground(new java.awt.Color(255, 255, 255));
        jPanel20.setPreferredSize(new java.awt.Dimension(679, 23));

        lblCurrentTypeView1.setFont(new java.awt.Font("SansSerif", 1, 16));
        lblCurrentTypeView1.setForeground(java.awt.Color.white);
        lblCurrentTypeView1.setText("Address Cards");

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCurrentTypeView1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(585, Short.MAX_VALUE))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCurrentTypeView1, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
        );

        pnlContact_AddressCard.add(jPanel20, java.awt.BorderLayout.NORTH);

        pnlContact_AddressCard_Tong.setBackground(java.awt.Color.white);
        pnlContact_AddressCard_Tong.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        pnlContact_AddressCard_Tong.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 10));
        pnlContact_AddressCard.add(pnlContact_AddressCard_Tong, java.awt.BorderLayout.CENTER);

        pnlContact_AddressCard.setBounds(0, 0, 724, 505);
        jLayeredPane2.add(pnlContact_AddressCard, javax.swing.JLayeredPane.DEFAULT_LAYER);

        pnlContact_DetailAddressCard.setBackground(new java.awt.Color(240, 255, 255));
        pnlContact_DetailAddressCard.setName("pnlContact_DetailAddressCard"); // NOI18N
        pnlContact_DetailAddressCard.setLayout(new java.awt.BorderLayout());

        jPanel22.setBackground(java.awt.SystemColor.textHighlight);
        jPanel22.setForeground(new java.awt.Color(255, 255, 255));
        jPanel22.setPreferredSize(new java.awt.Dimension(679, 23));

        lblCurrentTypeView2.setFont(new java.awt.Font("SansSerif", 1, 16));
        lblCurrentTypeView2.setForeground(java.awt.Color.white);
        lblCurrentTypeView2.setText("Detail Address Cards");

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCurrentTypeView2, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(511, Short.MAX_VALUE))
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCurrentTypeView2, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
        );

        pnlContact_DetailAddressCard.add(jPanel22, java.awt.BorderLayout.NORTH);

        pnlContact_DetailAddress_Tong.setBackground(java.awt.Color.white);
        pnlContact_DetailAddress_Tong.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        pnlContact_DetailAddress_Tong.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 10));
        pnlContact_DetailAddressCard.add(pnlContact_DetailAddress_Tong, java.awt.BorderLayout.CENTER);

        pnlContact_DetailAddressCard.setBounds(0, 0, 724, 505);
        jLayeredPane2.add(pnlContact_DetailAddressCard, javax.swing.JLayeredPane.DEFAULT_LAYER);

        pnlContact_BusinessCard.setBackground(new java.awt.Color(240, 255, 255));
        pnlContact_BusinessCard.setName("pnlContact_BusinessCard"); // NOI18N
        pnlContact_BusinessCard.setLayout(new java.awt.BorderLayout());

        jPanel24.setBackground(java.awt.SystemColor.textHighlight);
        jPanel24.setForeground(new java.awt.Color(255, 255, 255));
        jPanel24.setPreferredSize(new java.awt.Dimension(679, 23));

        lblCurrentTypeView3.setFont(new java.awt.Font("SansSerif", 1, 16));
        lblCurrentTypeView3.setForeground(java.awt.Color.white);
        lblCurrentTypeView3.setText("Business Cards");

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCurrentTypeView3, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(585, Short.MAX_VALUE))
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCurrentTypeView3, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
        );

        pnlContact_BusinessCard.add(jPanel24, java.awt.BorderLayout.NORTH);

        pnlContact_Bus_Tong.setBackground(java.awt.Color.white);
        pnlContact_Bus_Tong.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        pnlContact_Bus_Tong.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 10));
        pnlContact_BusinessCard.add(pnlContact_Bus_Tong, java.awt.BorderLayout.CENTER);

        pnlContact_BusinessCard.setBounds(0, 0, 724, 505);
        jLayeredPane2.add(pnlContact_BusinessCard, javax.swing.JLayeredPane.DEFAULT_LAYER);

        pnlContact_PhoneList.setBackground(new java.awt.Color(240, 255, 255));
        pnlContact_PhoneList.setName("pnlContact_PhoneList"); // NOI18N
        pnlContact_PhoneList.setLayout(new java.awt.BorderLayout());

        jPanel26.setBackground(java.awt.SystemColor.textHighlight);
        jPanel26.setForeground(new java.awt.Color(255, 255, 255));
        jPanel26.setPreferredSize(new java.awt.Dimension(679, 23));

        lblCurrentTypeView4.setFont(new java.awt.Font("SansSerif", 1, 16));
        lblCurrentTypeView4.setForeground(java.awt.Color.white);
        lblCurrentTypeView4.setText("Phone List");

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCurrentTypeView4, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(585, Short.MAX_VALUE))
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCurrentTypeView4, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
        );

        pnlContact_PhoneList.add(jPanel26, java.awt.BorderLayout.NORTH);

        jScrollPane7.setAutoscrolls(true);
        jScrollPane7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11));

        tblContact_PhoneList.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11));
        tblContact_PhoneList.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblContact_PhoneList.setFillsViewportHeight(true);
        tblContact_PhoneList.setGridColor(new java.awt.Color(204, 204, 204));
        tblContact_PhoneList.setRowHeight(18);
        tblContact_PhoneList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblContact_PhoneListMousePressed(evt);
            }
        });
        jScrollPane7.setViewportView(tblContact_PhoneList);

        pnlContact_PhoneList.add(jScrollPane7, java.awt.BorderLayout.CENTER);

        pnlContact_PhoneList.setBounds(0, 0, 724, 505);
        jLayeredPane2.add(pnlContact_PhoneList, javax.swing.JLayeredPane.DEFAULT_LAYER);

        pnlContact_ByCategory.setBackground(new java.awt.Color(240, 255, 255));
        pnlContact_ByCategory.setName("pnlContact_ByCategory"); // NOI18N
        pnlContact_ByCategory.setLayout(new java.awt.BorderLayout());

        jPanel28.setBackground(java.awt.SystemColor.textHighlight);
        jPanel28.setForeground(new java.awt.Color(255, 255, 255));
        jPanel28.setPreferredSize(new java.awt.Dimension(679, 23));

        lblCurrentTypeView5.setFont(new java.awt.Font("SansSerif", 1, 16));
        lblCurrentTypeView5.setForeground(java.awt.Color.white);
        lblCurrentTypeView5.setText("By Category");

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCurrentTypeView5, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(585, Short.MAX_VALUE))
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCurrentTypeView5, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
        );

        pnlContact_ByCategory.add(jPanel28, java.awt.BorderLayout.NORTH);

        tblContactByCateGory.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblContactByCateGory.setFillsViewportHeight(true);
        tblContactByCateGory.setGridColor(new java.awt.Color(204, 204, 204));
        tblContactByCateGory.setRowHeight(18);
        tblContactByCateGory.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblContactByCateGoryMousePressed(evt);
            }
        });
        jScrollPane8.setViewportView(tblContactByCateGory);

        pnlContact_ByCategory.add(jScrollPane8, java.awt.BorderLayout.CENTER);

        pnlContact_ByCategory.setBounds(0, 0, 724, 505);
        jLayeredPane2.add(pnlContact_ByCategory, javax.swing.JLayeredPane.DEFAULT_LAYER);

        pnlContact_ByCompany.setBackground(new java.awt.Color(240, 255, 255));
        pnlContact_ByCompany.setName("pnlContact_ByCompany"); // NOI18N
        pnlContact_ByCompany.setLayout(new java.awt.BorderLayout());

        jPanel30.setBackground(java.awt.SystemColor.textHighlight);
        jPanel30.setForeground(new java.awt.Color(255, 255, 255));
        jPanel30.setPreferredSize(new java.awt.Dimension(679, 23));

        lblCurrentTypeView6.setFont(new java.awt.Font("SansSerif", 1, 16));
        lblCurrentTypeView6.setForeground(java.awt.Color.white);
        lblCurrentTypeView6.setText("By Company");

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCurrentTypeView6, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(585, Short.MAX_VALUE))
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCurrentTypeView6, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
        );

        pnlContact_ByCompany.add(jPanel30, java.awt.BorderLayout.NORTH);

        tblByCompany.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblByCompany.setFillsViewportHeight(true);
        tblByCompany.setGridColor(new java.awt.Color(204, 204, 204));
        tblByCompany.setRowHeight(18);
        tblByCompany.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblByCompanyMousePressed(evt);
            }
        });
        jScrollPane9.setViewportView(tblByCompany);

        pnlContact_ByCompany.add(jScrollPane9, java.awt.BorderLayout.CENTER);

        pnlContact_ByCompany.setBounds(0, 0, 724, 505);
        jLayeredPane2.add(pnlContact_ByCompany, javax.swing.JLayeredPane.DEFAULT_LAYER);

        pnlContact_OutlookDataField.setBackground(new java.awt.Color(240, 255, 255));
        pnlContact_OutlookDataField.setName("pnlContact_OutlookDataField"); // NOI18N
        pnlContact_OutlookDataField.setLayout(new java.awt.BorderLayout());

        jPanel32.setBackground(java.awt.SystemColor.textHighlight);
        jPanel32.setForeground(new java.awt.Color(255, 255, 255));
        jPanel32.setPreferredSize(new java.awt.Dimension(679, 23));

        lblCurrentTypeView7.setFont(new java.awt.Font("SansSerif", 1, 16));
        lblCurrentTypeView7.setForeground(java.awt.Color.white);
        lblCurrentTypeView7.setText("Outlook Data Files");

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCurrentTypeView7, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(506, Short.MAX_VALUE))
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCurrentTypeView7, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
        );

        pnlContact_OutlookDataField.add(jPanel32, java.awt.BorderLayout.NORTH);

        tblOutlookDataField.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblOutlookDataField.setFillsViewportHeight(true);
        tblOutlookDataField.setGridColor(new java.awt.Color(204, 204, 204));
        tblOutlookDataField.setRowHeight(18);
        tblOutlookDataField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblOutlookDataFieldMousePressed(evt);
            }
        });
        jScrollPane10.setViewportView(tblOutlookDataField);

        pnlContact_OutlookDataField.add(jScrollPane10, java.awt.BorderLayout.CENTER);

        pnlContact_OutlookDataField.setBounds(0, 0, 724, 505);
        jLayeredPane2.add(pnlContact_OutlookDataField, javax.swing.JLayeredPane.DEFAULT_LAYER);

        pnlCalendarScreen.setBackground(java.awt.Color.white);
        pnlCalendarScreen.setName("pnlTypeViewlScreen"); // NOI18N
        pnlCalendarScreen.setLayout(new java.awt.BorderLayout());

        jPanel25.setBackground(java.awt.SystemColor.textHighlight);
        jPanel25.setForeground(new java.awt.Color(255, 255, 255));
        jPanel25.setPreferredSize(new java.awt.Dimension(679, 23));

        lblCurrentTypeView8.setFont(new java.awt.Font("SansSerif", 1, 16));
        lblCurrentTypeView8.setForeground(java.awt.Color.white);
        lblCurrentTypeView8.setText("Calendar");

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCurrentTypeView8, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(585, Short.MAX_VALUE))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCurrentTypeView8, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
        );

        pnlCalendarScreen.add(jPanel25, java.awt.BorderLayout.NORTH);

        jTabbedPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTabbedPane1MouseReleased(evt);
            }
        });

        pnlCalendar_TableDay.setBackground(java.awt.Color.white);
        pnlCalendar_TableDay.setLayout(new java.awt.BorderLayout());

        jSplitPane3.setBorder(null);
        jSplitPane3.setDividerLocation(70);
        jSplitPane3.setDividerSize(3);

        scroll_GhiChu.setWheelScrollingEnabled(false);

        tblCalendar_GhiChu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "Title 1"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblCalendar_GhiChu.setFillsViewportHeight(true);
        tblCalendar_GhiChu.setGridColor(new java.awt.Color(255, 228, 187));
        tblCalendar_GhiChu.setRowHeight(24);
        tblCalendar_GhiChu.setShowVerticalLines(false);
        tblCalendar_GhiChu.addMouseWheelListener(new java.awt.event.MouseWheelListener() {
            public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
                tblCalendar_GhiChuMouseWheelMoved(evt);
            }
        });
        tblCalendar_GhiChu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblCalendar_GhiChuMousePressed(evt);
            }
        });
        scroll_GhiChu.setViewportView(tblCalendar_GhiChu);

        jSplitPane3.setRightComponent(scroll_GhiChu);

        scroll_ThoiGian.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        scroll_ThoiGian.setWheelScrollingEnabled(false);

        tblCalendar_ThoiGian.setBackground(new java.awt.Color(227, 239, 255));
        tblCalendar_ThoiGian.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 11));
        tblCalendar_ThoiGian.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"12:00 AM"},
                {"1:00 "},
                {"2:00 "},
                {"3:00 "},
                {"4:00 "},
                {"5:00 "},
                {"6:00 "},
                {"7:00 "},
                {"8:00 "},
                {"9:00 "},
                {"10:00 "},
                {"11:00 "},
                {"12:00 PM"},
                {"1:00 "},
                {"2:00 "},
                {"3:00 "},
                {"4:00 "},
                {"5:00 "},
                {"6:00 "},
                {"7:00 "},
                {"8:00 "},
                {"9:00 "},
                {"10:00 "},
                {"11:00 "}
            },
            new String [] {
                "Time"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblCalendar_ThoiGian.setGridColor(new java.awt.Color(204, 204, 204));
        tblCalendar_ThoiGian.setRowHeight(24);
        tblCalendar_ThoiGian.setShowVerticalLines(false);
        tblCalendar_ThoiGian.addMouseWheelListener(new java.awt.event.MouseWheelListener() {
            public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
                tblCalendar_ThoiGianMouseWheelMoved(evt);
            }
        });
        scroll_ThoiGian.setViewportView(tblCalendar_ThoiGian);

        jSplitPane3.setLeftComponent(scroll_ThoiGian);

        pnlCalendar_TableDay.add(jSplitPane3, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("Day", pnlCalendar_TableDay);

        pnlCalendar_TableMonth.setBackground(java.awt.Color.white);
        pnlCalendar_TableMonth.setLayout(new java.awt.BorderLayout());

        tblCalendar_Month.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblCalendar_Month.setFillsViewportHeight(true);
        tblCalendar_Month.setGridColor(new java.awt.Color(125, 175, 255));
        tblCalendar_Month.setRowHeight(110);
        tblCalendar_Month.setRowSelectionAllowed(false);
        tblCalendar_Month.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblCalendar_MonthMousePressed(evt);
            }
        });
        scroll_GhiChu1.setViewportView(tblCalendar_Month);

        pnlCalendar_TableMonth.add(scroll_GhiChu1, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("Month", pnlCalendar_TableMonth);

        pnlCalendarScreen.add(jTabbedPane1, java.awt.BorderLayout.CENTER);

        pnlCalendarScreen.setBounds(0, 0, 724, 505);
        jLayeredPane2.add(pnlCalendarScreen, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jSplitPane1.setRightComponent(jLayeredPane2);

        jPanel1.setBackground(java.awt.Color.white);
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(new java.awt.BorderLayout());

        pnlQuanLyBase.setPreferredSize(new java.awt.Dimension(169, 135));
        pnlQuanLyBase.setLayout(new java.awt.GridLayout(3, 0));

        pnlQuanLyMail.setBackground(new java.awt.Color(240, 230, 140));
        pnlQuanLyMail.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        pnlQuanLyMail.setName("pnlQuanLyMail"); // NOI18N

        lblQuanLyMail.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/email.png"))); // NOI18N
        lblQuanLyMail.setText("Quan ly tai khoan");

        javax.swing.GroupLayout pnlQuanLyMailLayout = new javax.swing.GroupLayout(pnlQuanLyMail);
        pnlQuanLyMail.setLayout(pnlQuanLyMailLayout);
        pnlQuanLyMailLayout.setHorizontalGroup(
            pnlQuanLyMailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQuanLyMailLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(lblQuanLyMail, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlQuanLyMailLayout.setVerticalGroup(
            pnlQuanLyMailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQuanLyMailLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblQuanLyMail)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        pnlQuanLyBase.add(pnlQuanLyMail);

        pnlQuanLyContact.setBackground(new java.awt.Color(255, 250, 205));
        pnlQuanLyContact.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        pnlQuanLyContact.setName("pnlQuanLyContact"); // NOI18N

        lblQuanLyContact.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/contact.png"))); // NOI18N
        lblQuanLyContact.setText("Quan ly tai khoan");

        javax.swing.GroupLayout pnlQuanLyContactLayout = new javax.swing.GroupLayout(pnlQuanLyContact);
        pnlQuanLyContact.setLayout(pnlQuanLyContactLayout);
        pnlQuanLyContactLayout.setHorizontalGroup(
            pnlQuanLyContactLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQuanLyContactLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(lblQuanLyContact, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(11, Short.MAX_VALUE))
        );
        pnlQuanLyContactLayout.setVerticalGroup(
            pnlQuanLyContactLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQuanLyContactLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblQuanLyContact)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        pnlQuanLyBase.add(pnlQuanLyContact);

        pnlQuanLyCalendar.setBackground(new java.awt.Color(255, 250, 205));
        pnlQuanLyCalendar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        pnlQuanLyCalendar.setName("pnlQuanLyCalendar"); // NOI18N

        lblQuanLyCalendar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/date.png"))); // NOI18N
        lblQuanLyCalendar.setText("Quan ly tai khoan");

        javax.swing.GroupLayout pnlQuanLyCalendarLayout = new javax.swing.GroupLayout(pnlQuanLyCalendar);
        pnlQuanLyCalendar.setLayout(pnlQuanLyCalendarLayout);
        pnlQuanLyCalendarLayout.setHorizontalGroup(
            pnlQuanLyCalendarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQuanLyCalendarLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(lblQuanLyCalendar, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlQuanLyCalendarLayout.setVerticalGroup(
            pnlQuanLyCalendarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQuanLyCalendarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblQuanLyCalendar)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        pnlQuanLyBase.add(pnlQuanLyCalendar);

        jPanel1.add(pnlQuanLyBase, java.awt.BorderLayout.SOUTH);

        jLayeredPane1.setBackground(java.awt.Color.white);

        pnlChucNangMail.setBackground(java.awt.Color.white);
        pnlChucNangMail.setLayout(new java.awt.BorderLayout());

        jPanel21.setPreferredSize(new java.awt.Dimension(180, 46));
        jPanel21.setLayout(new java.awt.GridLayout(2, 0));

        jPanel7.setBackground(java.awt.SystemColor.textHighlight);
        jPanel7.setForeground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("SansSerif", 1, 16));
        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Mail");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
        );

        jPanel21.add(jPanel7);

        jPanel6.setBackground(java.awt.SystemColor.inactiveCaptionText);
        jPanel6.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11));
        jLabel1.setText("All Mail Folders");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
        );

        jPanel21.add(jPanel6);

        pnlChucNangMail.add(jPanel21, java.awt.BorderLayout.NORTH);

        javax.swing.tree.DefaultMutableTreeNode treeNode1 = new javax.swing.tree.DefaultMutableTreeNode("root");
        treeMail.setModel(new javax.swing.tree.DefaultTreeModel(treeNode1));
        treeMail.setComponentPopupMenu(popMail);
        treeMail.setRowHeight(18);
        treeMail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                treeMailMousePressed(evt);
            }
        });
        treeMail.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                treeMailMouseMoved(evt);
            }
        });
        treeMail.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                treeMailKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(treeMail);

        pnlChucNangMail.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pnlChucNangMail.setBounds(0, 0, 180, 365);
        jLayeredPane1.add(pnlChucNangMail, javax.swing.JLayeredPane.DEFAULT_LAYER);

        pnlChucNangCalendar.setBackground(java.awt.Color.white);
        pnlChucNangCalendar.setLayout(new java.awt.BorderLayout());

        jPanel23.setPreferredSize(new java.awt.Dimension(180, 46));
        jPanel23.setLayout(new java.awt.GridLayout(2, 0));

        jPanel8.setBackground(java.awt.SystemColor.textHighlight);
        jPanel8.setForeground(new java.awt.Color(255, 255, 255));

        jLabel3.setFont(new java.awt.Font("SansSerif", 1, 16));
        jLabel3.setForeground(java.awt.Color.white);
        jLabel3.setText("Calendar");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
        );

        jPanel23.add(jPanel8);

        jPanel9.setBackground(java.awt.SystemColor.inactiveCaptionText);
        jPanel9.setForeground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11));
        jLabel4.setText("My Calendars");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
        );

        jPanel23.add(jPanel9);

        pnlChucNangCalendar.add(jPanel23, java.awt.BorderLayout.NORTH);

        pnlChucNangCalendar.setBounds(0, 0, 180, 365);
        jLayeredPane1.add(pnlChucNangCalendar, javax.swing.JLayeredPane.DEFAULT_LAYER);

        pnlChucNangContact.setBackground(java.awt.Color.white);
        pnlChucNangContact.setLayout(new java.awt.BorderLayout());

        jPanel34.setPreferredSize(new java.awt.Dimension(180, 46));
        jPanel34.setLayout(new java.awt.GridLayout(2, 0));

        jPanel10.setBackground(java.awt.SystemColor.textHighlight);
        jPanel10.setForeground(new java.awt.Color(255, 255, 255));

        jLabel5.setFont(new java.awt.Font("SansSerif", 1, 16));
        jLabel5.setForeground(java.awt.Color.white);
        jLabel5.setText("Contact");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
        );

        jPanel34.add(jPanel10);

        jPanel11.setBackground(java.awt.SystemColor.inactiveCaptionText);
        jPanel11.setForeground(new java.awt.Color(255, 255, 255));

        jLabel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11));
        jLabel6.setText("All my contacts");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
        );

        jPanel34.add(jPanel11);

        pnlChucNangContact.add(jPanel34, java.awt.BorderLayout.NORTH);

        treeNode1 = new javax.swing.tree.DefaultMutableTreeNode("root");
        treeContact.setModel(new javax.swing.tree.DefaultTreeModel(treeNode1));
        treeContact.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                treeContactMousePressed(evt);
            }
        });
        jScrollPane3.setViewportView(treeContact);

        pnlChucNangContact.add(jScrollPane3, java.awt.BorderLayout.CENTER);

        pnlChucNangContact.setBounds(0, 0, 180, 365);
        jLayeredPane1.add(pnlChucNangContact, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jPanel1.add(jLayeredPane1, java.awt.BorderLayout.CENTER);

        jSplitPane1.setLeftComponent(jPanel1);

        jPanel5.add(jSplitPane1, java.awt.BorderLayout.CENTER);

        jLabel10.setText("You have 0 message in box");
        jLabel10.setPreferredSize(new java.awt.Dimension(131, 24));
        jPanel5.add(jLabel10, java.awt.BorderLayout.SOUTH);

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");

        jMenu3.setText("Find");

        memItemSearchMessages.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search message.png"))); // NOI18N
        memItemSearchMessages.setText("Search Messages");
        memItemSearchMessages.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memItemSearchMessagesActionPerformed(evt);
            }
        });
        jMenu3.add(memItemSearchMessages);

        memItemSearchContacts.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/find contact.gif"))); // NOI18N
        memItemSearchContacts.setText("Search Contacts");
        memItemSearchContacts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memItemSearchContactsActionPerformed(evt);
            }
        });
        jMenu3.add(memItemSearchContacts);

        jMenu2.add(jMenu3);

        jMenuBar1.add(jMenu2);

        memLanguage.setText("Language");

        memItemEnglish.setText("English");
        memItemEnglish.setSelected(true);
        memItemEnglish.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memItemEnglishActionPerformed(evt);
            }
        });
        memLanguage.add(memItemEnglish);

        memItemVieNam.setText("Việt Nam");
        memItemVieNam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memItemVieNamActionPerformed(evt);
            }
        });
        memLanguage.add(memItemVieNam);

        jMenuBar1.add(memLanguage);

        memHelp.setText("Help");

        memItemJavaDoc.setText("Java docs");
        memItemJavaDoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memItemJavaDocActionPerformed(evt);
            }
        });
        memHelp.add(memItemJavaDoc);
        memHelp.add(jSeparator2);

        memItemTacGia.setText("Authors");
        memItemTacGia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memItemTacGiaActionPerformed(evt);
            }
        });
        memHelp.add(memItemTacGia);

        jMenuBar1.add(memHelp);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, 910, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, 579, Short.MAX_VALUE)
        );

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-918)/2, (screenSize.height-633)/2, 918, 633);
    }// </editor-fold>//GEN-END:initComponents

    private void formComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentResized
        // TODO add your handling code here:
    }//GEN-LAST:event_formComponentResized
    private Point pointClickToMove;
    private IconNode nodeClick;
    private IconNode nodeAccount;
    private void treeMailMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_treeMailMousePressed
        // TODO add your handling code here:
        int modifiers = evt.getModifiers();
        MyTree.IconNode node = null;
        if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
            if (evt.getClickCount() == 1) {//them nut con
                int selRow = this.treeMail.getRowForLocation(evt.getX(), evt.getY());
                MyTree.IconNode nodeRoot =
                        (MyTree.IconNode) treeMail.getPathForRow(0).getLastPathComponent();
                if (selRow > 0) {
                    pointClickToMove = evt.getPoint();

                    TreePath path = treeMail.getPathForRow(selRow);
                    node = (MyTree.IconNode) path.getLastPathComponent();
                    if (nodeRoot.isNodeChild(node)) {
                        String[] thanhPhanNodeName = node.getIconName().split("\\\\");
                        String nodeName = thanhPhanNodeName[thanhPhanNodeName.length - 1];
                        if (nodeName.equals("Local Folders")) {
                            getPnlLocalfolderScreen().setVisible(true);
                            getPnlMailAccountScreen().setVisible(false);
                            getPnlTypeViewlScreen().setVisible(false);
                        } else {
                            nodeAccount = (IconNode) node.getChildAt(0);
                            getPnlLocalfolderScreen().setVisible(false);
                            getPnlMailAccountScreen().setVisible(true);
                            getPnlTypeViewlScreen().setVisible(false);
                        }
                    } else {
                        try {
                            nodeClick = node;
                            xemMail(node);
                        } catch (ParserConfigurationException ex) {
                            Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (SAXException ex) {
                            Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (IOException ex) {
                            Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (XPathExpressionException ex) {
                            Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        pnlLocalfolderScreen.setVisible(false);
                        pnlMailAccountScreen.setVisible(false);
                        pnlTypeViewlScreen.setVisible(true);
                    }
                }
            }
        } else if ((modifiers & InputEvent.BUTTON3_MASK) == InputEvent.BUTTON3_MASK) {
            pointClick = new Point();
            pointClick = evt.getPoint();
            int selRow = treeMail.getRowForLocation((int) pointClick.getX(), (int) pointClick.getY());
            treeMail.setSelectionInterval(selRow, selRow);
            treeMail.setSelectionRow(selRow);

            MyTree.IconNode nodeRoot =
                    (MyTree.IconNode) treeMail.getPathForRow(0).getLastPathComponent();
            if (selRow == 0) {
                for (int i = 0; i < popMail.getComponentCount(); i++) {
                    popMail.getComponentAtIndex(i).setVisible(false);
                }
            } else if (selRow > 0) {
                TreePath path = treeMail.getPathForRow(selRow);
                node = (MyTree.IconNode) path.getLastPathComponent();
                if (nodeRoot.isNodeChild(node)) {
                    popMail.getComponentAtIndex(0).setVisible(true);
                    popMail.getComponentAtIndex(1).setVisible(false);
                } else {
                    String[] thanhPhanNodeName = node.getIconName().split("\\\\");
                    String nodeName = thanhPhanNodeName[thanhPhanNodeName.length - 1];
                    if (nodeName.equals("Inbox") || nodeName.equals("Trash") || nodeName.equals("Sent")) {
                        popMail.getComponentAtIndex(0).setVisible(true);
                        popMail.getComponentAtIndex(1).setVisible(false);
                    } else {
                        for (int i = 0; i < popMail.getComponentCount(); i++) {
                            popMail.getComponentAtIndex(i).setVisible(true);
                        }
                    }

                }
            }
        }
    }//GEN-LAST:event_treeMailMousePressed
    /**
     * Load danh sach mail dung moi Accountname
     * @param AccountName
     * @throws javax.xml.parsers.ParserConfigurationException
     * @throws org.xml.sax.SAXException
     * @throws java.io.IOException
     * @throws javax.xml.xpath.XPathExpressionException
     */
    public void xemMail(IconNode node) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
        String name, AccountName;
        name = node.getIconName();
        AccountName = node.getIconAccountName();
        XL_Account account = new XL_Account();
        //lay id ung voi accountname
        String[] ThanhPhanName = name.split("\\\\");
        String strNodeName = name.substring(1, name.length());
        File f = new File(strNodeName);

        int accountID =
                account.getUserIDByName(GlobalVariables.g_strTenTapTinAccount, AccountName);
        XL_DanhSachMail dsmail = new XL_DanhSachMail();
        dsmail.DocDanhSachMailByUserID(GlobalVariables.g_strTenTapTinMail, accountID);

        XL_DanhSachMail dsmailThucSu = new XL_DanhSachMail();
        for (int i = 0; i < dsmail.getDanhSachMail().size(); i++) {
            if (dsmail.getDanhSachMail().get(i).getPlaceStore().equals(f.getName())) {
                dsmailThucSu.getDanhSachMail().add(dsmail.getDanhSachMail().get(i));
            }
        }
        MyTable.TableMail.loadFolderIntoTableMail(tblMail, dsmailThucSu);
        if (dsmailThucSu.getDanhSachMail().size() > 0) {
            int num;
            if (ThanhPhanName[ThanhPhanName.length - 1].equals("Inbox")) {
                if (GlobalVariables.numMailOfUser.get(AccountName) == null) {
                    this.tblMail.setRowSelectionInterval(0, 0);
                    return;
                }
                if ((num = GlobalVariables.numMailOfUser.get(AccountName)) > 0) {
                    this.tblMail.setRowSelectionInterval(0, num - 1);
                } else {
                    this.tblMail.setRowSelectionInterval(0, 0);
                }
            } else {
                this.tblMail.setRowSelectionInterval(0, 0);
            }

        } else {
            txtTypeView_Content.setText("");
        }

    }
    private Point pointClick;

    public void addMouseListenerToLabelMail(JLabel label) {
        MouseListener mouseListener = new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent mouseEvent) {
                JLabel label = (JLabel) mouseEvent.getSource();
                imgCurrentNavImage = label.getForeground();
                label.setForeground(Color.blue);
                Font italic = new Font(label.getFont().getName(), Font.ITALIC, label.getFont().getSize());
                label.setFont(italic);
            }

            @Override
            public void mouseExited(MouseEvent mouseEvent) {
                JLabel label = (JLabel) mouseEvent.getSource();

                label.setForeground(imgCurrentNavImage);
                label.setCursor(Cursor.getDefaultCursor());
                Font plain = new Font(label.getFont().getName(), Font.PLAIN, label.getFont().getSize());
                label.setFont(plain);
            }

            public void mousePressed(MouseEvent mouseEvent) {
                int modifiers = mouseEvent.getModifiers();

                if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
                    JLabel label = (JLabel) mouseEvent.getSource();
                    String[] thanhPhanName = label.getName().split("_#_");
                    if (mouseEvent.getClickCount() == 2) {
                        if (thanhPhanName[0].equals("LetuanAttachment")) {
                            OpenMailAttachment dlg = new OpenMailAttachment(null, true, thanhPhanName[1].trim());
                            dlg.show();
                        }
                    } else if (mouseEvent.getClickCount() == 1) {
                        if (thanhPhanName[0].equals("LetuanTo") || thanhPhanName[0].equals("LetuanCC")) {
                            popClickIntoEmaiAddressl.show(mouseEvent.getComponent(), mouseEvent.getX(), mouseEvent.getY());
                            _mailContact = thanhPhanName[1];
                        } else {
                            if (!thanhPhanName[0].equals("LetuanAttachment")) {
                                //from
                                popClickIntoEmaiAddressl.show(mouseEvent.getComponent(), mouseEvent.getX(), mouseEvent.getY());
                                _mailContact = label.getName();
                            }
                        }
                    }
                }
            }
        };
        label.addMouseListener(mouseListener);
    }
    private String _mailContact;
    private XL_Mail _mailProcessNow;
    private void tblMailMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblMailMousePressed
        // TODO add your handling code here:
        int modifiers = evt.getModifiers();
        MyTableModel model;
        int mailID;
        if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
            if (this.tblMail.getSelectedRow() == -1) {
                return;
            }

            if (tblMail.getValueAt(this.tblMail.getSelectedRow(), 1) == null) {
                return;
            }
            if (evt.getClickCount() == 1) {
                String strMailID = ((JLabel) tblMail.getValueAt(this.tblMail.getSelectedRow(), 1)).getName().trim();
                mailID = Integer.parseInt(strMailID);
                XL_Mail mail = new XL_Mail();
                if (mail.docMail(GlobalVariables.g_strTenTapTinMail, mailID)) {
                    _mailProcessNow = mail;
                    lblTypeView_Subject.setText(mail.getSubject());

                    Font plain = new Font(lblTypeView_From.getFont().getName(), Font.PLAIN, lblTypeView_From.getFont().getSize());
                    lblTypeView_From.setFont(plain);
                    lblTypeView_From.setText(mail.getFrom());
                    lblTypeView_From.setName(mail.getFrom());
                    addMouseListenerToLabelMail(lblTypeView_From);

                    String strTo = "";
                    pnlTypeView_To.removeAll();
                    for (int i = 0; i < mail.getTo().size(); i++) {
                        JLabel lb = new JLabel();
                        plain = new Font(lb.getFont().getName(), Font.PLAIN, lb.getFont().getSize());
                        lb.setFont(plain);
                        if (i < mail.getTo().size() - 1) {
                            lb.setText(mail.getTo().get(i) + "; ");
                        } else {
                            lb.setText(mail.getTo().get(i));
                        }
                        lb.setName("LetuanTo_#_" + mail.getTo().get(i));
                        lb.setForeground(Color.blue);
                        addMouseListenerToLabelMail(lb);
                        pnlTypeView_To.add(lb);
                    }

                    pnlTypeView_CC.removeAll();
                    for (int i = 0; i < mail.getCc().size(); i++) {
                        JLabel lb = new JLabel();
                        plain = new Font(lb.getFont().getName(), Font.PLAIN, lb.getFont().getSize());
                        lb.setFont(plain);
                        if (i < mail.getCc().size() - 1) {
                            lb.setText(mail.getCc().get(i) + "; ");
                        } else {
                            lb.setText(mail.getCc().get(i));
                        }
                        lb.setName("LetuanCC_#_" + mail.getCc().get(i));
                        lb.setForeground(Color.blue);
                        addMouseListenerToLabelMail(lb);
                        pnlTypeView_CC.add(lb);
                    }
                    if (mail.getTag().equals("") &&
                            mail.getPathAttach().size() == 0) {
                        pnlAttAndTag.setVisible(false);
                    } else {
                        pnlAttAndTag.setVisible(true);
                        if (mail.getTag().equals("")) {
                            pnlTypeView_Tag.setVisible(false);
                        } else {
                            pnlTypeView_Tag.setVisible(true);
                            if (mail.getTag().equals("Important")) {
                                lblTag.setForeground(Color.red);
                            } else if (mail.getTag().equals("Work")) {
                                lblTag.setForeground(Color.orange);
                            } else if (mail.getTag().equals("Personal")) {
                                lblTag.setForeground(new Color(0, 153, 51));
                            } else if (mail.getTag().equals("To do")) {
                                lblTag.setForeground(Color.blue);
                            } else if (mail.getTag().equals("Later")) {
                                lblTag.setForeground(new Color(153, 0, 153));
                            }
                            lblTag.setText(mail.getTag());
                        }
                    }
                    txtTypeView_Content.setText(mail.getBody());
                    if (mail.getPathAttach().size() == 0) {
                        pnlTypeView_Attachments.setVisible(false);
                    } else {
                        pnlTypeView_Attachments.setVisible(true);
                        pnlTypeView_Attachments.removeAll();
                        JLabel lb = new JLabel();
                        lb.setText("Attachments: ");
                        pnlTypeView_Attachments.add(lb);
                        for (int i = 0; i < mail.getPathAttach().size(); i++) {
                            File file = new File(mail.getPathAttach().get(i));
                            if (file.exists()) {
                                ShellFolder sf;
                                try {
                                    sf = ShellFolder.getShellFolder(file);
                                    ImageIcon imageIcon = new ImageIcon(sf.getIcon(true));
                                    //thu nho kich thuoc cua icon
                                    if (imageIcon.getIconWidth() > 18 || imageIcon.getIconHeight() > 18) {
                                        imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(
                                                18, 18, Image.SCALE_SMOOTH));
                                    }
                                    //add icon vao control
                                    JLabel lb1 = new JLabel();
                                    lb1.setIcon(imageIcon);
                                    plain = new Font(lb1.getFont().getName(), Font.PLAIN, lb1.getFont().getSize());
                                    lb1.setFont(plain);
                                    if (i < mail.getPathAttach().size() - 1) {
                                        lb1.setText(file.getName() + "   ");
                                    } else {
                                        lb1.setText(file.getName());
                                    }
                                    lb1.setName("LetuanAttachment_#_" + file.getPath());
                                    addMouseListenerToLabelMail(lb1);
                                    pnlTypeView_Attachments.add(lb1);
                                } catch (FileNotFoundException ex) {
                                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                                }

                            }
                        }
                    }
                }
            } else if (evt.getClickCount() == 2) {//nhap dup mo cua so coi 1 mail
                String strMailID = ((JLabel) tblMail.getValueAt(this.tblMail.getSelectedRow(), 1)).getName().trim();
                mailID = Integer.parseInt(strMailID);
                XL_Mail mail = new XL_Mail();
                if (mail.docMail(GlobalVariables.g_strTenTapTinMail, mailID)) {
                    Connect.XemMotMail dlg = new Connect.XemMotMail(null, true, mail);
                    dlg.show();
                }

            }
        } else if ((modifiers & InputEvent.BUTTON3_MASK) == InputEvent.BUTTON3_MASK) {
            Point pointRightClick = evt.getPoint();
            int iRow = this.tblMail.rowAtPoint(pointRightClick);
            //format kich chon trong table
            this.tblMail.setRowSelectionAllowed(true);//quan trong
            this.tblMail.setRowSelectionInterval(iRow, iRow);

            popProcessMail.show(evt.getComponent(), evt.getX(), evt.getY());

            String strMailID = ((JLabel) tblMail.getValueAt(iRow, 1)).getName().trim();
            mailID = Integer.parseInt(strMailID);
            XL_Mail mail = new XL_Mail();
            if (mail.docMail(GlobalVariables.g_strTenTapTinMail, mailID)) {
                _mailProcessNow = mail;
            }
        }
    }//GEN-LAST:event_tblMailMousePressed

    private void memItemEnglishActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memItemEnglishActionPerformed
        // TODO add your handling code here:
        this.isVieNamLanguges = false;
        this.setActivePremierLanguage(resStringsEL);
    }//GEN-LAST:event_memItemEnglishActionPerformed

    private void memItemVieNamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memItemVieNamActionPerformed
        // TODO add your handling code here:
        this.isVieNamLanguges = true;
        this.setActivePremierLanguage(resStringsVN);
    }//GEN-LAST:event_memItemVieNamActionPerformed

    private void memItemJavaDocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memItemJavaDocActionPerformed
        try {
            // TODO add your handling code here:
            String user = System.getProperty("user.dir") + File.separator + "javadoc" + File.separator + "index.html";
            Runtime.getRuntime().exec("rundll32 SHELL32.DLL,ShellExec_RunDLL \"" + user);
        } catch (IOException ex) {
            Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
}//GEN-LAST:event_memItemJavaDocActionPerformed

    private void memItemTacGiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memItemTacGiaActionPerformed
        // TODO add your handling code here:
        AboutDlg dlg = new AboutDlg(this, true);
        dlg.show();
}//GEN-LAST:event_memItemTacGiaActionPerformed

    private void memMail_NewFolderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memMail_NewFolderActionPerformed
        // TODO add your handling code here:
        int selRow = this.treeMail.getRowForLocation((int) pointClick.getX(), (int) pointClick.getY());
        if (selRow > 0) {
            TreePath path = treeMail.getPathForRow(selRow);
            MyTree.IconNode node = (MyTree.IconNode) path.getLastPathComponent();
            String pathNode = node.getIconName().
                    substring(1, node.getIconName().length()).trim() + "\\";
            String str = (String) JOptionPane.showInputDialog(null, "New directory", "New",
                    JOptionPane.INFORMATION_MESSAGE, null, null, null);
            if (str == null) {
                return;
            }
            LopDungChung.ThaoTacThuMuc.createFolder(pathNode, str);
            try {
                MyTree.TreeMail.loadElemsIntoTreeMail(treeMail);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_memMail_NewFolderActionPerformed

    private void memMail_DeleteFolderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memMail_DeleteFolderActionPerformed
        // TODO add your handling code here:
        TreePath path = treeMail.getSelectionPath();
        MyTree.IconNode node = (MyTree.IconNode) path.getLastPathComponent();
        String pathNode = node.getIconName().
                substring(1, node.getIconName().length()).trim();
        File file = new File(pathNode);
        if (!file.exists()) {
            return;
        }
        if (JOptionPane.showConfirmDialog(null, "Do you want to delete selected file " +
                file.getName() + "?", "Total Commander",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE) ==
                JOptionPane.OK_OPTION) {
            file.delete();
            try {
                MyTree.TreeMail.loadElemsIntoTreeMail(treeMail);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }//GEN-LAST:event_memMail_DeleteFolderActionPerformed

    private void treeMailMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_treeMailMouseMoved
        // TODO add your handling code here:
        if (transfer.getDrop()) {
            Point p = evt.getPoint();
            int iRow = treeMail.getRowForLocation((int) p.getX(), (int) p.getY());
            if (iRow != -1) {
            }

            this.transfer.setDrop(false);
        }
    }//GEN-LAST:event_treeMailMouseMoved

    private void treeMailKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_treeMailKeyPressed
        // TODO add your handling code here:
        int keyCode = evt.getKeyCode();
        @SuppressWarnings("static-access")
        String keyText = evt.getKeyText(keyCode);
        int selRow = treeMail.getSelectionRows()[0];

        MyTree.IconNode nodeRoot =
                (MyTree.IconNode) treeMail.getPathForRow(0).getLastPathComponent();
        if (keyText.equals("Delete")) {
            if (selRow == 0) {
                return;
            } else if (selRow > 0) {
                TreePath path = treeMail.getPathForRow(selRow);
                MyTree.IconNode node = (MyTree.IconNode) path.getLastPathComponent();
                if (nodeRoot.isNodeChild(node)) {
                    return;
                } else {
                    String[] thanhPhanNodeName = node.getIconName().split("\\\\");
                    String nodeName = thanhPhanNodeName[thanhPhanNodeName.length - 1];
                    if (nodeName.equals("Inbox") || nodeName.equals("Trash")) {
                        return;
                    } else {
                        String pathNode = node.getIconName().
                                substring(1, node.getIconName().length()).trim();
                        File file = new File(pathNode);
                        if (!file.exists()) {
                            return;
                        }
                        if (JOptionPane.showConfirmDialog(null, "Do you want to delete selected file " +
                                file.getName() + "?", "Total Commander",
                                JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE) ==
                                JOptionPane.OK_OPTION) {
                            file.delete();
                            try {
                                MyTree.TreeMail.loadElemsIntoTreeMail(treeMail);
                            } catch (FileNotFoundException ex) {
                                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }

                }
            }
        }
    }//GEN-LAST:event_treeMailKeyPressed

    private void toolbar_btnGetMailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnGetMailActionPerformed
        // TODO add your handling code here:
        if (GlobalVariables.TapHopAccount.getDanhSachAccount().size() == 0) {
            GlobalVariables.loaded = true;
            return;
        }
        for (int i = 0; i < GlobalVariables.TapHopAccount.getDanhSachAccount().size(); i++) {
            XL_Account account =
                    GlobalVariables.TapHopAccount.getDanhSachAccount().get(i);
            String pass;
            try {
                pass = LopDungChung.ThaoTacThuMuc.docPassWord(account.getAccountID());
                account.setPassword(pass);
                //xet accout thu i
                BienDungChung.GlobalVariables.ActiveAccount = account;

                //khoi tao thong so phuc vu cho viec ket noi
                Connect.MailConstant.khoiTaoThanhPhanKetNoi(pass);

                Connect.ProgressConnectDialog processDlg;
                processDlg = new Connect.ProgressConnectDialog(
                        null, "Please wailt", false, pnlLocalfolderScreen,
                        pnlMailAccountScreen, pnlTypeViewlScreen, tblMail, treeMail);
                processDlg.setLocationRelativeTo(this);
                processDlg.startGetMail();
            } catch (IOException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (Exception ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }//GEN-LAST:event_toolbar_btnGetMailActionPerformed

    private void toolbar_btnWriteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnWriteActionPerformed
        // TODO add your handling code here:
        //chu y doi so dau tien phai set la null
        Connect.SendMail dlg = new Connect.SendMail(null, true);
        dlg.show();
    }//GEN-LAST:event_toolbar_btnWriteActionPerformed

    private void toolbar_btnNewContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnNewContactActionPerformed
        // TODO add your handling code here:
        MyContact.NewContact dlg = new MyContact.NewContact(null, true);
        dlg.show();
        if (dlg.isAddSuccess()) {
            if (strActiveContactScreen.equals("pnlContact_AddressCard")) {
                loadAllContact("pnlContact_AddressCard");
            } else if (strActiveContactScreen.equals("pnlContact_DetailAddressCard")) {
                loadAllContact("pnlContact_DetailAddressCard");
            } else if (strActiveContactScreen.equals("pnlContact_BusinessCard")) {
                loadAllContact("pnlContact_BusinessCard");
            } else if (strActiveContactScreen.equals("pnlContact_PhoneList")) {
                loadAllContact("pnlContact_PhoneList");
            } else if (strActiveContactScreen.equals("pnlContact_ByCategory")) {
                loadAllContact("pnlContact_ByCategory");
            } else if (strActiveContactScreen.equals("pnlContact_ByCompany")) {
                loadAllContact("pnlContact_ByCompany");
            } else if (strActiveContactScreen.equals("pnlContact_OutlookDataField")) {
                loadAllContact("pnlContact_OutlookDataField");
            }

        }
    }//GEN-LAST:event_toolbar_btnNewContactActionPerformed

    private void memItemAddToContactsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memItemAddToContactsActionPerformed
        // TODO add your handling code here:
        MyContact.NewContact dlg = new MyContact.NewContact(null, true, _mailContact);
        dlg.show();
    }//GEN-LAST:event_memItemAddToContactsActionPerformed

    private void memItemComposeMailToActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memItemComposeMailToActionPerformed
        // TODO add your handling code here:
        Connect.SendMail dlg = new Connect.SendMail(null, true, _mailContact);
        dlg.show();
    }//GEN-LAST:event_memItemComposeMailToActionPerformed
    private XL_Contact _contactProcess;

    public void addMouseListenerToAddressCard(
            final JPanel pnlTong, final JPanel pnlBase, final JPanel pnlName, JPanel panelChiTiet,
            JTextField txtAddMobile, JTextField txtAddMail, final JLabel label,
            final XL_Contact contact) {
        MouseListener mouseListener = new MouseAdapter() {

            @Override
            public void mousePressed(MouseEvent mouseEvent) {
                int modifiers = mouseEvent.getModifiers();

                if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
                    if (mouseEvent.getClickCount() == 2) {
                        MyContact.NewContact dlg = new MyContact.NewContact(null, true,
                                contact);
                        dlg.show();
                        if (dlg.isUpdateSuccess()) {
                            loadAllContact("pnlContact_AddressCard");
                        }
                    } else if (mouseEvent.getClickCount() == 1) {
                        _contactProcess = contact;
                        for (int i = 0; i < pnlTong.getComponentCount(); i++) {
                            JPanel pnlCon = (JPanel) pnlTong.getComponent(i);
                            if (pnlCon.getName().equals(pnlBase.getName())) {
                                JPanel pnlNameCon = (JPanel) pnlCon.getComponent(0);
                                JLabel labelCon = (JLabel) pnlNameCon.getComponent(0);
                                pnlNameCon.setBackground(new Color(49, 106, 197));
                                labelCon.setForeground(Color.white);
                                indexClickContact = i;
                            } else {
                                JPanel pnlNameCon = (JPanel) pnlCon.getComponent(0);
                                JLabel labelCon = (JLabel) pnlNameCon.getComponent(0);
                                pnlNameCon.setBackground(SystemColor.controlHighlight);
                                labelCon.setForeground(Color.black);
                            }
                        }
                    }
                }
            }
        };
        txtAddMail.addMouseListener(mouseListener);
        txtAddMobile.addMouseListener(mouseListener);
        pnlName.addMouseListener(mouseListener);
        pnlBase.addMouseListener(mouseListener);
    }
    private int indexClickContact;

    public void addMouseListenerToDetailAddressCard(
            final JPanel pnlTong, final JPanel pnlBase, final JPanel pnlName, JPanel panelChiTiet,
            JTextField txtDelFullname, JTextField txtDelJob, JTextField txtDelCompany, JTextField txtAddMobile, JTextField txtAddMail, final JLabel label,
            final XL_Contact contact) {
        MouseListener mouseListener = new MouseAdapter() {

            @Override
            public void mousePressed(MouseEvent mouseEvent) {
                int modifiers = mouseEvent.getModifiers();

                if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
                    if (mouseEvent.getClickCount() == 2) {
                        MyContact.NewContact dlg = new MyContact.NewContact(null, true,
                                contact);
                        dlg.show();
                        if (dlg.isUpdateSuccess()) {
                            loadAllContact("pnlContact_DetailAddressCard");
                        }
                    } else if (mouseEvent.getClickCount() == 1) {
                        _contactProcess = contact;
                        for (int i = 0; i < pnlTong.getComponentCount(); i++) {
                            JPanel pnlCon = (JPanel) pnlTong.getComponent(i);
                            if (pnlCon.getName().equals(pnlBase.getName())) {
                                JPanel pnlNameCon = (JPanel) pnlCon.getComponent(0);
                                JLabel labelCon = (JLabel) pnlNameCon.getComponent(0);
                                pnlNameCon.setBackground(new Color(49, 106, 197));
                                labelCon.setForeground(Color.white);
                                indexClickContact = i;
                            } else {
                                JPanel pnlNameCon = (JPanel) pnlCon.getComponent(0);
                                JLabel labelCon = (JLabel) pnlNameCon.getComponent(0);
                                pnlNameCon.setBackground(SystemColor.controlHighlight);
                                labelCon.setForeground(Color.black);
                            }
                        }
                    }
                }
            }
        };
        txtAddMail.addMouseListener(mouseListener);
        txtAddMobile.addMouseListener(mouseListener);
        txtDelCompany.addMouseListener(mouseListener);
        txtDelFullname.addMouseListener(mouseListener);
        txtDelJob.addMouseListener(mouseListener);

        pnlName.addMouseListener(mouseListener);
        pnlBase.addMouseListener(mouseListener);
    }

    public void addMouseListenerToBusCard(
            final JPanel pnlTong, final JPanel pnlBase, final JPanel pnlName, JPanel panelChiTiet,
            JTextField txtDelFullname, JTextField txtDelJob, JTextField txtDelCompany, JTextField txtAddMobile, JTextField txtAddMail, final JLabel label,
            final XL_Contact contact, JPanel pnlBackground) {
        MouseListener mouseListener = new MouseAdapter() {

            @Override
            public void mousePressed(MouseEvent mouseEvent) {
                int modifiers = mouseEvent.getModifiers();

                if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
                    if (mouseEvent.getClickCount() == 2) {
                        MyContact.NewContact dlg = new MyContact.NewContact(null, true,
                                contact);
                        dlg.show();
                        if (dlg.isUpdateSuccess()) {
                            loadAllContact("pnlContact_BusinessCard");
                        }
                    } else if (mouseEvent.getClickCount() == 1) {
                        _contactProcess = contact;
                        for (int i = 0; i < pnlTong.getComponentCount(); i++) {
                            JPanel pnlCon = (JPanel) pnlTong.getComponent(i);
                            if (pnlCon.getName().equals(pnlBase.getName())) {
                                JPanel pnlNameCon = (JPanel) pnlCon.getComponent(0);
                                JLabel labelCon = (JLabel) pnlNameCon.getComponent(0);
                                pnlNameCon.setBackground(new Color(49, 106, 197));
                                labelCon.setForeground(Color.white);
                                indexClickContact = i;
                            } else {
                                JPanel pnlNameCon = (JPanel) pnlCon.getComponent(0);
                                JLabel labelCon = (JLabel) pnlNameCon.getComponent(0);
                                pnlNameCon.setBackground(SystemColor.controlHighlight);
                                labelCon.setForeground(Color.black);
                            }
                        }
                    }
                }
            }
        };
        txtAddMail.addMouseListener(mouseListener);
        txtAddMobile.addMouseListener(mouseListener);
        txtDelCompany.addMouseListener(mouseListener);
        txtDelFullname.addMouseListener(mouseListener);
        txtDelJob.addMouseListener(mouseListener);

        pnlName.addMouseListener(mouseListener);
        pnlBase.addMouseListener(mouseListener);
        pnlBackground.addMouseListener(mouseListener);
    }

    public void loadContactsToAddressCard(XL_DanhSachContact dsContact, JPanel pnlTong) {

        for (XL_Contact contact : dsContact.getDanhSachContact()) {
            javax.swing.JLabel lblAddressEmail;
            javax.swing.JLabel lblAddressMobile;
            javax.swing.JLabel lblAddressName;
            javax.swing.JPanel pnlBase;
            javax.swing.JPanel pnlChiTiet;
            javax.swing.JPanel pnlEmail;
            javax.swing.JPanel pnlMobile;
            javax.swing.JPanel pnlName;
            javax.swing.JTextField txtAddressEmail;
            javax.swing.JTextField txtAddressMobile;

            pnlBase = new javax.swing.JPanel();
            pnlBase.setName(String.valueOf(contact.getContactID()));
            pnlName = new javax.swing.JPanel();
            pnlName.setName("pnlName");
            pnlChiTiet = new javax.swing.JPanel();
            pnlChiTiet.setName("pnlChiTiet");
            pnlMobile = new javax.swing.JPanel();
            pnlMobile.setName("pnlMobile");
            pnlEmail = new javax.swing.JPanel();
            pnlEmail.setName("pnlEmail");

            lblAddressName = new javax.swing.JLabel();
            lblAddressMobile = new javax.swing.JLabel();
            txtAddressMobile = new javax.swing.JTextField();
            txtAddressMobile.setName("txtAddressMobile");
            lblAddressEmail = new javax.swing.JLabel();
            txtAddressEmail = new javax.swing.JTextField();
            txtAddressEmail.setName("txtAddressEmail");

            pnlBase.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
            pnlBase.setPreferredSize(new java.awt.Dimension(200, 60));
            pnlBase.setLayout(new java.awt.BorderLayout());

            pnlName.setBackground(java.awt.SystemColor.controlHighlight);
            pnlName.setLayout(new java.awt.BorderLayout());

            lblAddressName.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 12)); // NOI18N
            lblAddressName.setText("  " + contact.getDisplayas());
            lblAddressName.setName("lblAddressName");

            pnlName.add(lblAddressName, java.awt.BorderLayout.NORTH);

            pnlBase.add(pnlName, java.awt.BorderLayout.NORTH);

            pnlChiTiet.setBackground(java.awt.Color.white);
            pnlChiTiet.setLayout(new java.awt.GridLayout(2, 0));

            pnlMobile.setBackground(java.awt.Color.white);
            pnlMobile.setLayout(new java.awt.BorderLayout());

            lblAddressMobile.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            lblAddressMobile.setText("  Mobile:");
            lblAddressMobile.setName("lblAddressMobile");
            pnlMobile.add(lblAddressMobile, java.awt.BorderLayout.WEST);

            txtAddressMobile.setBackground(java.awt.Color.white);
            txtAddressMobile.setEditable(false);
            txtAddressMobile.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            txtAddressMobile.setText("  " + contact.getMobilePhone());
            txtAddressMobile.setBorder(null);
            pnlMobile.add(txtAddressMobile, java.awt.BorderLayout.CENTER);

            pnlChiTiet.add(pnlMobile);

            pnlEmail.setBackground(java.awt.Color.white);
            pnlEmail.setLayout(new javax.swing.BoxLayout(pnlEmail, javax.swing.BoxLayout.LINE_AXIS));

            lblAddressEmail.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            lblAddressEmail.setText("  E-mail:");
            lblAddressEmail.setName("lblAddressEmail");
            pnlEmail.add(lblAddressEmail);

            txtAddressEmail.setBackground(java.awt.Color.white);
            txtAddressEmail.setEditable(false);
            txtAddressEmail.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            txtAddressEmail.setText("  " + contact.getEmail());
            txtAddressEmail.setBorder(null);
            pnlEmail.add(txtAddressEmail);

            pnlChiTiet.add(pnlEmail);

            pnlBase.add(pnlChiTiet, java.awt.BorderLayout.CENTER);

            pnlTong.add(pnlBase);

            addMouseListenerToAddressCard(pnlTong, pnlBase, pnlName,
                    pnlChiTiet, txtAddressMobile, txtAddressEmail, lblAddressName, contact);
        }
    }

    public void loadContactsToDetailAddressCard(XL_DanhSachContact dsContact, JPanel pnlTong) {
        for (XL_Contact contact : dsContact.getDanhSachContact()) {
            javax.swing.JLabel lblDetailCompany;
            javax.swing.JLabel lblDetailEmail;
            javax.swing.JLabel lblDetailFullName;
            javax.swing.JLabel lblDetailJob;
            javax.swing.JLabel lblDetailMobile;
            javax.swing.JLabel lblDetailName;
            javax.swing.JPanel pnlBase;
            javax.swing.JPanel pnlChiTiet;
            javax.swing.JPanel pnlDetaildFullname;
            javax.swing.JPanel pnlDetaildJob;
            javax.swing.JPanel pnlEmail1;
            javax.swing.JPanel pnlMobile1;
            javax.swing.JPanel pnlMobile2;
            javax.swing.JPanel pnlName;
            javax.swing.JTextField txtDetailCompany;
            javax.swing.JTextField txtDetailEmail;
            javax.swing.JTextField txtDetailFullname;
            javax.swing.JTextField txtDetailJob;
            javax.swing.JTextField txtDetailMobile;

            pnlBase = new javax.swing.JPanel();
            pnlBase.setName(String.valueOf(contact.getContactID()));
            pnlName = new javax.swing.JPanel();
            lblDetailName = new javax.swing.JLabel();
            pnlChiTiet = new javax.swing.JPanel();
            pnlDetaildFullname = new javax.swing.JPanel();
            lblDetailFullName = new javax.swing.JLabel();
            txtDetailFullname = new javax.swing.JTextField();
            pnlDetaildJob = new javax.swing.JPanel();
            lblDetailJob = new javax.swing.JLabel();
            txtDetailJob = new javax.swing.JTextField();
            pnlMobile1 = new javax.swing.JPanel();
            lblDetailCompany = new javax.swing.JLabel();
            txtDetailCompany = new javax.swing.JTextField();
            pnlMobile2 = new javax.swing.JPanel();
            lblDetailMobile = new javax.swing.JLabel();
            txtDetailMobile = new javax.swing.JTextField();
            pnlEmail1 = new javax.swing.JPanel();
            lblDetailEmail = new javax.swing.JLabel();
            txtDetailEmail = new javax.swing.JTextField();

            pnlBase.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
            pnlBase.setPreferredSize(new java.awt.Dimension(150, 120));
            pnlBase.setLayout(new java.awt.BorderLayout());

            pnlName.setBackground(java.awt.SystemColor.controlHighlight);
            pnlName.setLayout(new java.awt.BorderLayout());

            lblDetailName.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 12));
            lblDetailName.setText("  " + contact.getDisplayas());
            pnlName.add(lblDetailName, java.awt.BorderLayout.NORTH);

            pnlBase.add(pnlName, java.awt.BorderLayout.NORTH);

            pnlChiTiet.setBackground(java.awt.Color.white);
            pnlChiTiet.setLayout(new java.awt.GridLayout(5, 0));

            pnlDetaildFullname.setBackground(java.awt.Color.white);
            pnlDetaildFullname.setLayout(new java.awt.BorderLayout());

            lblDetailFullName.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            lblDetailFullName.setText("  Full Name:");
            pnlDetaildFullname.add(lblDetailFullName, java.awt.BorderLayout.WEST);

            txtDetailFullname.setBackground(java.awt.Color.white);
            txtDetailFullname.setEditable(false);
            txtDetailFullname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            txtDetailFullname.setText("  " + contact.getFullName());
            txtDetailFullname.setBorder(null);
            pnlDetaildFullname.add(txtDetailFullname, java.awt.BorderLayout.CENTER);

            pnlChiTiet.add(pnlDetaildFullname);

            pnlDetaildJob.setBackground(java.awt.Color.white);
            pnlDetaildJob.setLayout(new javax.swing.BoxLayout(pnlDetaildJob, javax.swing.BoxLayout.LINE_AXIS));

            lblDetailJob.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            lblDetailJob.setText("  Job Tiltle:");
            pnlDetaildJob.add(lblDetailJob);

            txtDetailJob.setBackground(java.awt.Color.white);
            txtDetailJob.setEditable(false);
            txtDetailJob.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11));
            txtDetailJob.setText("  " + contact.getJobTitle());
            txtDetailJob.setBorder(null);
            pnlDetaildJob.add(txtDetailJob);

            pnlChiTiet.add(pnlDetaildJob);

            pnlMobile1.setBackground(java.awt.Color.white);
            pnlMobile1.setLayout(new java.awt.BorderLayout());

            lblDetailCompany.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            lblDetailCompany.setText("  Company:");
            pnlMobile1.add(lblDetailCompany, java.awt.BorderLayout.WEST);

            txtDetailCompany.setBackground(java.awt.Color.white);
            txtDetailCompany.setEditable(false);
            txtDetailCompany.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            txtDetailCompany.setText("  " + contact.getCompany());
            txtDetailCompany.setBorder(null);
            pnlMobile1.add(txtDetailCompany, java.awt.BorderLayout.CENTER);

            pnlChiTiet.add(pnlMobile1);

            pnlMobile2.setBackground(java.awt.Color.white);
            pnlMobile2.setLayout(new java.awt.BorderLayout());

            lblDetailMobile.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11));
            lblDetailMobile.setText("  Mobile:");
            pnlMobile2.add(lblDetailMobile, java.awt.BorderLayout.WEST);

            txtDetailMobile.setBackground(java.awt.Color.white);
            txtDetailMobile.setEditable(false);
            txtDetailMobile.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            txtDetailMobile.setText("  " + contact.getMobilePhone());
            txtDetailMobile.setBorder(null);
            pnlMobile2.add(txtDetailMobile, java.awt.BorderLayout.CENTER);

            pnlChiTiet.add(pnlMobile2);

            pnlEmail1.setBackground(java.awt.Color.white);
            pnlEmail1.setLayout(new javax.swing.BoxLayout(pnlEmail1, javax.swing.BoxLayout.LINE_AXIS));

            lblDetailEmail.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            lblDetailEmail.setText("  E-mail:");
            pnlEmail1.add(lblDetailEmail);

            txtDetailEmail.setBackground(java.awt.Color.white);
            txtDetailEmail.setEditable(false);
            txtDetailEmail.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            txtDetailEmail.setText("  " + contact.getEmail());
            txtDetailEmail.setBorder(null);
            pnlEmail1.add(txtDetailEmail);

            pnlChiTiet.add(pnlEmail1);

            pnlBase.add(pnlChiTiet, java.awt.BorderLayout.CENTER);

            pnlTong.add(pnlBase);

            addMouseListenerToDetailAddressCard(
                    pnlTong, pnlBase, pnlName, pnlChiTiet, txtDetailFullname,
                    txtDetailJob, txtDetailCompany,
                    txtDetailMobile, txtDetailEmail, lblDetailName, contact);

        }
    }

    public void loadContactToBusiness(XL_DanhSachContact dsContact, JPanel pnlTong) {
        for (XL_Contact contact : dsContact.getDanhSachContact()) {
            javax.swing.JLabel lblBackGround;
            javax.swing.JLabel lblDetailName;
            javax.swing.JPanel pnlBackgorund;
            javax.swing.JPanel pnlBase;
            javax.swing.JPanel pnlBusCompany;
            javax.swing.JPanel pnlBusFullName;
            javax.swing.JPanel pnlBusJob;
            javax.swing.JPanel pnlBusMail;
            javax.swing.JPanel pnlBusWebPage;
            javax.swing.JPanel pnlChiTiet;
            javax.swing.JPanel pnlName;
            javax.swing.JTextField txtBusCompany;
            javax.swing.JTextField txtBusFullName;
            javax.swing.JTextField txtBusJob;
            javax.swing.JTextField txtBusMail;
            javax.swing.JTextField txtBusWebpage;

            pnlBase = new javax.swing.JPanel();
            pnlName = new javax.swing.JPanel();
            lblDetailName = new javax.swing.JLabel();
            pnlChiTiet = new javax.swing.JPanel();
            pnlBusFullName = new javax.swing.JPanel();
            txtBusFullName = new javax.swing.JTextField();
            pnlBusCompany = new javax.swing.JPanel();
            txtBusCompany = new javax.swing.JTextField();
            pnlBusJob = new javax.swing.JPanel();
            txtBusJob = new javax.swing.JTextField();
            pnlBusMail = new javax.swing.JPanel();
            txtBusMail = new javax.swing.JTextField();
            pnlBusWebPage = new javax.swing.JPanel();
            txtBusWebpage = new javax.swing.JTextField();
            pnlBackgorund = new javax.swing.JPanel();
            lblBackGround = new javax.swing.JLabel();

            pnlBase.setName(String.valueOf(contact.getContactID()));

            pnlBase.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
            pnlBase.setPreferredSize(new java.awt.Dimension(210, 138));
            pnlBase.setLayout(new java.awt.BorderLayout());

            pnlName.setBackground(java.awt.SystemColor.controlHighlight);
            pnlName.setLayout(new java.awt.BorderLayout());

            lblDetailName.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 12));
            lblDetailName.setText("  " + contact.getDisplayas());
            pnlName.add(lblDetailName, java.awt.BorderLayout.NORTH);

            pnlBase.add(pnlName, java.awt.BorderLayout.NORTH);

            pnlChiTiet.setBackground(java.awt.Color.white);
            pnlChiTiet.setLayout(new java.awt.GridLayout(5, 0));

            pnlBusFullName.setBackground(java.awt.Color.white);
            pnlBusFullName.setLayout(new java.awt.BorderLayout());

            txtBusFullName.setBackground(java.awt.Color.white);
            txtBusFullName.setEditable(false);
            txtBusFullName.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 14)); // NOI18N
            txtBusFullName.setText(" " + contact.getFullName());
            txtBusFullName.setBorder(null);
            pnlBusFullName.add(txtBusFullName, java.awt.BorderLayout.CENTER);

            pnlChiTiet.add(pnlBusFullName);

            pnlBusCompany.setBackground(java.awt.Color.white);
            pnlBusCompany.setLayout(new java.awt.BorderLayout());

            txtBusCompany.setBackground(java.awt.Color.white);
            txtBusCompany.setEditable(false);
            txtBusCompany.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            txtBusCompany.setText("  " + contact.getCompany());
            txtBusCompany.setBorder(null);
            pnlBusCompany.add(txtBusCompany, java.awt.BorderLayout.CENTER);

            pnlChiTiet.add(pnlBusCompany);

            pnlBusJob.setBackground(java.awt.Color.white);
            pnlBusJob.setLayout(new java.awt.BorderLayout());

            txtBusJob.setBackground(java.awt.Color.white);
            txtBusJob.setEditable(false);
            txtBusJob.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            txtBusJob.setText("  " + contact.getJobTitle());
            txtBusJob.setBorder(null);
            pnlBusJob.add(txtBusJob, java.awt.BorderLayout.CENTER);

            pnlChiTiet.add(pnlBusJob);

            pnlBusMail.setBackground(java.awt.Color.white);
            pnlBusMail.setLayout(new java.awt.BorderLayout());

            txtBusMail.setBackground(java.awt.Color.white);
            txtBusMail.setEditable(false);
            txtBusMail.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            txtBusMail.setText("  " + contact.getEmail());
            txtBusMail.setBorder(null);
            pnlBusMail.add(txtBusMail, java.awt.BorderLayout.CENTER);

            pnlChiTiet.add(pnlBusMail);

            pnlBusWebPage.setBackground(java.awt.Color.white);
            pnlBusWebPage.setLayout(new javax.swing.BoxLayout(pnlBusWebPage, javax.swing.BoxLayout.LINE_AXIS));

            txtBusWebpage.setBackground(java.awt.Color.white);
            txtBusWebpage.setEditable(false);
            txtBusWebpage.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11)); // NOI18N
            txtBusWebpage.setText("  " + contact.getWebpage());
            txtBusWebpage.setBorder(null);
            pnlBusWebPage.add(txtBusWebpage);

            pnlChiTiet.add(pnlBusWebPage);

            pnlBase.add(pnlChiTiet, java.awt.BorderLayout.CENTER);

            pnlBackgorund.setBackground(java.awt.Color.white);
            pnlBackgorund.setPreferredSize(new java.awt.Dimension(40, 10));
            pnlBackgorund.setLayout(new java.awt.BorderLayout());

            lblBackGround.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/background.gif"))); // NOI18N
            pnlBackgorund.add(lblBackGround, java.awt.BorderLayout.CENTER);

            pnlBase.add(pnlBackgorund, java.awt.BorderLayout.WEST);

            pnlTong.add(pnlBase);

            addMouseListenerToBusCard(
                    pnlTong, pnlBase, pnlName, pnlChiTiet, txtBusFullName,
                    txtBusJob, txtBusCompany,
                    txtBusMail, txtBusWebpage, lblDetailName, contact, pnlBackgorund);
        }
    }

    public void loadAllContact(String shortcut) {
        LopXuLy.XL_DanhSachContact dsContact = new LopXuLy.XL_DanhSachContact();
        if (dsContact.Doc(GlobalVariables.g_strTenTapTinContact)) {
            if (shortcut.equals("pnlContact_AddressCard")) {
                pnlContact_AddressCard_Tong.removeAll();
                loadContactsToAddressCard(dsContact, pnlContact_AddressCard_Tong);
                this.pack();
            } else if (shortcut.equals("pnlContact_DetailAddressCard")) {
                pnlContact_DetailAddress_Tong.removeAll();
                loadContactsToDetailAddressCard(dsContact, pnlContact_DetailAddress_Tong);
                this.pack();
            } else if (shortcut.equals("pnlContact_BusinessCard")) {
                pnlContact_Bus_Tong.removeAll();
                loadContactToBusiness(dsContact, pnlContact_Bus_Tong);
                this.pack();
            } else if (shortcut.equals("pnlContact_PhoneList")) {
                MyTable.TablePhoneList.loadFolderIntoTablePhoneList(tblContact_PhoneList, dsContact);
            } else if (shortcut.equals("pnlContact_ByCategory")) {
                MyTable.TableByCategory.loadFolderIntoTableCategory(tblContactByCateGory, dsContact);
            } else if (shortcut.equals("pnlContact_ByCompany")) {
                MyTable.TableByCompany.loadFolderIntoTableCompany(tblByCompany, dsContact);
            } else if (shortcut.equals("pnlContact_OutlookDataField")) {
                MyTable.TableOutlookDataFiles.loadFolderIntoTableOutlookDataFiles(tblOutlookDataField, dsContact, false);
            }
        }
    }
    private String strActiveContactScreen = "pnlContact_AddressCard";

    private void NavigatePanelContactView(String Shortcut) {
        Component components[] = jLayeredPane2.getComponents();
        for (int i = 0; i <
                components.length; i++) {
            if (components[i].getName() != null) {
                if (components[i].getName().equals("pnlContact_AddressCard")) {
                    if (Shortcut.equals("pnlContact_AddressCard")) {
                        pnlContact_AddressCard.setVisible(true);
                        loadAllContact("pnlContact_AddressCard");
                        strActiveContactScreen = "pnlContact_AddressCard";
                    } else {
                        pnlContact_AddressCard.setVisible(false);
                    }

                } else if (components[i].getName().equals("pnlContact_DetailAddressCard")) {
                    if (Shortcut.equals("pnlContact_DetailAddressCard")) {
                        pnlContact_DetailAddressCard.setVisible(true);
                        loadAllContact("pnlContact_DetailAddressCard");
                        strActiveContactScreen = "pnlContact_DetailAddressCard";
                    } else {
                        pnlContact_DetailAddressCard.setVisible(false);
                    }

                } else if (components[i].getName().equals("pnlContact_BusinessCard")) {
                    if (Shortcut.equals("pnlContact_BusinessCard")) {
                        pnlContact_BusinessCard.setVisible(true);
                        loadAllContact("pnlContact_BusinessCard");
                        strActiveContactScreen = "pnlContact_BusinessCard";
                    } else {
                        pnlContact_BusinessCard.setVisible(false);
                    }

                } else if (components[i].getName().equals("pnlContact_ByCategory")) {
                    if (Shortcut.equals("pnlContact_ByCategory")) {
                        pnlContact_ByCategory.setVisible(true);
                        loadAllContact("pnlContact_ByCategory");
                        strActiveContactScreen = "pnlContact_ByCategory";
                    } else {
                        pnlContact_ByCategory.setVisible(false);
                    }

                } else if (components[i].getName().equals("pnlContact_ByCompany")) {
                    if (Shortcut.equals("pnlContact_ByCompany")) {
                        pnlContact_ByCompany.setVisible(true);
                        loadAllContact("pnlContact_ByCompany");
                        strActiveContactScreen = "pnlContact_ByCompany";
                    } else {
                        pnlContact_ByCompany.setVisible(false);
                    }

                } else if (components[i].getName().equals("pnlContact_OutlookDataField")) {
                    if (Shortcut.equals("pnlContact_OutlookDataField")) {
                        pnlContact_OutlookDataField.setVisible(true);
                        loadAllContact("pnlContact_OutlookDataField");
                        strActiveContactScreen = "pnlContact_OutlookDataField";
                    } else {
                        pnlContact_OutlookDataField.setVisible(false);
                    }

                } else if (components[i].getName().equals("pnlContact_PhoneList")) {
                    if (Shortcut.equals("pnlContact_PhoneList")) {
                        pnlContact_PhoneList.setVisible(true);
                        loadAllContact("pnlContact_PhoneList");
                        strActiveContactScreen = "pnlContact_PhoneList";
                    } else {
                        pnlContact_PhoneList.setVisible(false);
                    }
                } else if (components[i].getName().equals("pnlMailAccountScreen")) {
                    pnlMailAccountScreen.setVisible(false);
                } else if (components[i].getName().equals("pnlTypeViewlScreen")) {
                    pnlTypeViewlScreen.setVisible(false);
                } else if (components[i].getName().equals("pnlLocalfolderScreen")) {
                    pnlLocalfolderScreen.setVisible(false);
                } else if (components[i].getName().equals("pnlCalendarScreen")) {
                    if (Shortcut.equals("pnlCalendarScreen")) {
                        pnlCalendarScreen.setVisible(true);
                    } else {
                        pnlCalendarScreen.setVisible(false);
                    }
                }

            }
        }
    }
    private void treeContactMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_treeContactMousePressed
        // TODO add your handling code here:
        int modifiers = evt.getModifiers();
        MyTree.IconNode node = null;
        if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
            if (evt.getClickCount() == 1) {//them nut con
                int selRow = this.treeContact.getRowForLocation(evt.getX(), evt.getY());
                if (selRow > 0) {
                    TreePath path = treeContact.getPathForRow(selRow);
                    node = (MyTree.IconNode) path.getLastPathComponent();
                    NavigatePanelContactView(node.getIconName());
                }

            }
        }

    }//GEN-LAST:event_treeContactMousePressed

    private void toolbar_btnDeleteContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnDeleteContactActionPerformed
        // TODO add your handling code here:
        if (_contactProcess == null) {
            return;
        }
        if (_contactProcess.delete(GlobalVariables.g_strTenTapTinContact)) {
            if (strActiveContactScreen.equals("pnlContact_AddressCard")) {
                pnlContact_AddressCard_Tong.remove(indexClickContact);
            } else if (strActiveContactScreen.equals("pnlContact_DetailAddressCard")) {
                pnlContact_DetailAddress_Tong.remove(indexClickContact);
            } else if (strActiveContactScreen.equals("pnlContact_BusinessCard")) {
                pnlContact_Bus_Tong.remove(indexClickContact);
            } else if (strActiveContactScreen.equals("pnlContact_PhoneList")) {
                loadAllContact("pnlContact_PhoneList");
                return;
            } else if (strActiveContactScreen.equals("pnlContact_ByCategory")) {
                loadAllContact("pnlContact_ByCategory");
                return;
            } else if (strActiveContactScreen.equals("pnlContact_ByCompany")) {
                loadAllContact("pnlContact_ByCompany");
                return;
            } else if (strActiveContactScreen.equals("pnlContact_OutlookDataField")) {
                loadAllContact("pnlContact_OutlookDataField");
                return;
            }
            this.repaint();
        }
    }//GEN-LAST:event_toolbar_btnDeleteContactActionPerformed

    private void toolbar_btnEditContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnEditContactActionPerformed
        // TODO add your handling code here:
        if (_contactProcess == null) {
            return;
        }
        MyContact.NewContact dlg = new MyContact.NewContact(null, true,
                _contactProcess);
        dlg.show();
        if (dlg.isUpdateSuccess()) {
            if (strActiveContactScreen.equals("pnlContact_AddressCard")) {
                loadAllContact("pnlContact_AddressCard");
            } else if (strActiveContactScreen.equals("pnlContact_DetailAddressCard")) {
                loadAllContact("pnlContact_DetailAddressCard");
            } else if (strActiveContactScreen.equals("pnlContact_BusinessCard")) {
                loadAllContact("pnlContact_BusinessCard");
            } else if (strActiveContactScreen.equals("pnlContact_PhoneList")) {
                loadAllContact("pnlContact_PhoneList");
            } else if (strActiveContactScreen.equals("pnlContact_ByCategory")) {
                loadAllContact("pnlContact_ByCategory");
            } else if (strActiveContactScreen.equals("pnlContact_ByCompany")) {
                loadAllContact("pnlContact_ByCompany");
            } else if (strActiveContactScreen.equals("pnlContact_OutlookDataField")) {
                loadAllContact("pnlContact_OutlookDataField");
            }
        }
    }//GEN-LAST:event_toolbar_btnEditContactActionPerformed

    private void tblContact_PhoneListMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblContact_PhoneListMousePressed
        // TODO add your handling code here:
        int modifiers = evt.getModifiers();
        MyTableModel model;
        int ContactID;
        if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
            if (this.tblContact_PhoneList.getSelectedRow() == -1) {
                return;
            }

            if (tblContact_PhoneList.getValueAt(this.tblContact_PhoneList.getSelectedRow(), 0) == null) {
                return;
            }
            String strContactID = ((JLabel) tblContact_PhoneList.getValueAt(this.tblContact_PhoneList.getSelectedRow(), 0)).getName().trim();
            ContactID = Integer.parseInt(strContactID);
            XL_Contact contact = new XL_Contact();
            contact.selectContactByID(GlobalVariables.g_strTenTapTinContact, ContactID);

            if (evt.getClickCount() == 2) {//nhap dup mo cua so coi 1 mail
                MyContact.NewContact dlg = new MyContact.NewContact(null, true,
                        contact);
                dlg.show();
                if (dlg.isUpdateSuccess()) {
                    XL_DanhSachContact dsContact = new XL_DanhSachContact();
                    dsContact.Doc(GlobalVariables.g_strTenTapTinContact);
                    MyTable.TablePhoneList.loadFolderIntoTablePhoneList(tblContact_PhoneList, dsContact);
                }
            } else if (evt.getClickCount() == 1) {
                _contactProcess = contact;
            }
        }

    }//GEN-LAST:event_tblContact_PhoneListMousePressed

    private void tblContactByCateGoryMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblContactByCateGoryMousePressed
        // TODO add your handling code here:
        int modifiers = evt.getModifiers();
        MyTableModel model;
        int ContactID;
        if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
            if (this.tblContactByCateGory.getSelectedRow() == -1) {
                return;
            }

            if (tblContactByCateGory.getValueAt(this.tblContactByCateGory.getSelectedRow(), 0) == null) {
                return;
            }
            String strContactID = ((JLabel) tblContactByCateGory.getValueAt(this.tblContactByCateGory.getSelectedRow(), 0)).getName().trim();
            ContactID = Integer.parseInt(strContactID);
            XL_Contact contact = new XL_Contact();
            contact.selectContactByID(GlobalVariables.g_strTenTapTinContact, ContactID);

            if (evt.getClickCount() == 2) {//nhap dup mo cua so coi 1 mail
                MyContact.NewContact dlg = new MyContact.NewContact(null, true,
                        contact);
                dlg.show();
                if (dlg.isUpdateSuccess()) {
                    XL_DanhSachContact dsContact = new XL_DanhSachContact();
                    dsContact.Doc(GlobalVariables.g_strTenTapTinContact);
                    MyTable.TableByCategory.loadFolderIntoTableCategory(tblContactByCateGory, dsContact);
                }
            } else if (evt.getClickCount() == 1) {
                _contactProcess = contact;
            }
        }
}//GEN-LAST:event_tblContactByCateGoryMousePressed

    private void tblByCompanyMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblByCompanyMousePressed
        // TODO add your handling code here:
        int modifiers = evt.getModifiers();
        MyTableModel model;
        int ContactID;
        if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
            if (this.tblByCompany.getSelectedRow() == -1) {
                return;
            }

            if (tblByCompany.getValueAt(this.tblByCompany.getSelectedRow(), 0) == null) {
                return;
            }
            String strContactID = ((JLabel) tblByCompany.getValueAt(this.tblByCompany.getSelectedRow(), 0)).getName().trim();
            ContactID = Integer.parseInt(strContactID);
            XL_Contact contact = new XL_Contact();
            contact.selectContactByID(GlobalVariables.g_strTenTapTinContact, ContactID);

            if (evt.getClickCount() == 2) {//nhap dup mo cua so coi 1 mail
                MyContact.NewContact dlg = new MyContact.NewContact(null, true,
                        contact);
                dlg.show();
                if (dlg.isUpdateSuccess()) {
                    XL_DanhSachContact dsContact = new XL_DanhSachContact();
                    dsContact.Doc(GlobalVariables.g_strTenTapTinContact);
                    MyTable.TableByCompany.loadFolderIntoTableCompany(tblByCompany, dsContact);
                }
            } else if (evt.getClickCount() == 1) {
                _contactProcess = contact;
            }
        }
    }//GEN-LAST:event_tblByCompanyMousePressed

    private void tblOutlookDataFieldMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblOutlookDataFieldMousePressed
        // TODO add your handling code here:
        int modifiers = evt.getModifiers();
        MyTableModel model;
        int ContactID;
        if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
            if (this.tblOutlookDataField.getSelectedRow() == -1) {
                return;
            }

            if (tblOutlookDataField.getValueAt(this.tblOutlookDataField.getSelectedRow(), 0) == null) {
                return;
            }
            String strContactID = ((JLabel) tblOutlookDataField.getValueAt(this.tblOutlookDataField.getSelectedRow(), 0)).getName().trim();
            ContactID = Integer.parseInt(strContactID);
            XL_Contact contact = new XL_Contact();
            contact.selectContactByID(GlobalVariables.g_strTenTapTinContact, ContactID);

            if (evt.getClickCount() == 2) {//nhap dup mo cua so coi 1 mail
                MyContact.NewContact dlg = new MyContact.NewContact(null, true,
                        contact);
                dlg.show();
                if (dlg.isUpdateSuccess()) {
                    XL_DanhSachContact dsContact = new XL_DanhSachContact();
                    dsContact.Doc(GlobalVariables.g_strTenTapTinContact);
                    MyTable.TableByCompany.loadFolderIntoTableCompany(tblOutlookDataField, dsContact);
                }
            } else if (evt.getClickCount() == 1) {
                _contactProcess = contact;
            }
        }
}//GEN-LAST:event_tblOutlookDataFieldMousePressed

    private void toolbar_btnNewMessageToContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnNewMessageToContactActionPerformed
        // TODO add your handling code here:
        if (_contactProcess == null) {
            return;
        }
        Connect.SendMail dlg = new Connect.SendMail(null, true,
                _contactProcess.getEmail());
        dlg.show();
    }//GEN-LAST:event_toolbar_btnNewMessageToContactActionPerformed

    private void toolbar_btnFindContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnFindContactActionPerformed
        // TODO add your handling code here:
        MySearch.SearchContact dlg = new MySearch.SearchContact(null, true);
        dlg.show();
    }//GEN-LAST:event_toolbar_btnFindContactActionPerformed

    private void toolbar_btnAddressBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnAddressBookActionPerformed
        // TODO add your handling code here:
        MyContact.AddressBook dlg = new MyContact.AddressBook(null, true);
        dlg.show();
    }//GEN-LAST:event_toolbar_btnAddressBookActionPerformed

    private void toolbar_btnReplyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnReplyActionPerformed
        // TODO add your handling code here:
        if (_mailProcessNow == null) {
            return;
        }
        String subjectReply = "RE: " + _mailProcessNow.getSubject();
        String bodyReply = "\n-----Original Message-----\n" +
                "From: " + _mailProcessNow.getFrom() + "\n" +
                "Sent: " + _mailProcessNow.getDate() + "\n" +
                "To: " + _mailProcessNow.getTo() + "\n" +
                "Subject: " + _mailProcessNow.getSubject() + "\n" +
                _mailProcessNow.getBody() +
                "----------o0o----------\n";
        Connect.SendMail dlg = new Connect.SendMail(null, true,
                _mailProcessNow.getFrom(), subjectReply, bodyReply);
        dlg.show();
    }//GEN-LAST:event_toolbar_btnReplyActionPerformed

    private void toolbar_btnTagMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_toolbar_btnTagMousePressed
        // TODO add your handling code here:
        if (_mailProcessNow == null) {
            return;
        }
        popTag.show(evt.getComponent(), evt.getX(), evt.getY());
    }//GEN-LAST:event_toolbar_btnTagMousePressed

    private void memTag_ImportantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memTag_ImportantActionPerformed
        // TODO add your handling code here:
        if (_mailProcessNow == null) {
            return;
        }
        _mailProcessNow.setTag(memTag_Important.getText());
        if (_mailProcessNow.updateTag(GlobalVariables.g_strTenTapTinMail)) {
            try {
                xemMail(nodeClick);
            } catch (ParserConfigurationException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SAXException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (XPathExpressionException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_memTag_ImportantActionPerformed

    private void memTag_WorkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memTag_WorkActionPerformed
        // TODO add your handling code here:
        if (_mailProcessNow == null) {
            return;
        }
        _mailProcessNow.setTag(memTag_Work.getText());
        if (_mailProcessNow.updateTag(GlobalVariables.g_strTenTapTinMail)) {
            try {
                try {
                    xemMail(nodeClick);
                } catch (ParserConfigurationException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SAXException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (XPathExpressionException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_memTag_WorkActionPerformed

    private void memTag_PersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memTag_PersonalActionPerformed
        // TODO add your handling code here:
        if (_mailProcessNow == null) {
            return;
        }
        _mailProcessNow.setTag(memTag_Personal.getText());
        if (_mailProcessNow.updateTag(GlobalVariables.g_strTenTapTinMail)) {
            try {
                try {
                    xemMail(nodeClick);
                } catch (ParserConfigurationException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SAXException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (XPathExpressionException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_memTag_PersonalActionPerformed

    private void memTag_TodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memTag_TodoActionPerformed
        // TODO add your handling code here:
        if (_mailProcessNow == null) {
            return;
        }
        _mailProcessNow.setTag(memTag_Todo.getText());
        if (_mailProcessNow.updateTag(GlobalVariables.g_strTenTapTinMail)) {
            try {
                try {
                    xemMail(nodeClick);
                } catch (ParserConfigurationException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SAXException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (XPathExpressionException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_memTag_TodoActionPerformed

    private void memTag_LaterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memTag_LaterActionPerformed
        // TODO add your handling code here:
        if (_mailProcessNow == null) {
            return;
        }
        _mailProcessNow.setTag(memTag_Later.getText());
        if (_mailProcessNow.updateTag(GlobalVariables.g_strTenTapTinMail)) {
            try {
                try {
                    xemMail(nodeClick);
                } catch (ParserConfigurationException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SAXException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (XPathExpressionException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_memTag_LaterActionPerformed

    private void memTag_RemoveAlltagActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memTag_RemoveAlltagActionPerformed
        // TODO add your handling code here:
        if (_mailProcessNow == null) {
            return;
        }
        _mailProcessNow.setTag("");
        if (_mailProcessNow.updateTag(GlobalVariables.g_strTenTapTinMail)) {
            try {
                try {
                    xemMail(nodeClick);
                } catch (ParserConfigurationException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SAXException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (XPathExpressionException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_memTag_RemoveAlltagActionPerformed

    private void popMemItemAddStarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_popMemItemAddStarActionPerformed
        // TODO add your handling code here:
        if (_mailProcessNow == null) {
            return;
        }
        if (_mailProcessNow.getStar().equals("false")) {
            _mailProcessNow.setStar("true");
        } else {
            _mailProcessNow.setStar("false");
        }
        if (_mailProcessNow.updateStar(GlobalVariables.g_strTenTapTinMail)) {
            try {
                xemMail(nodeClick);
            } catch (ParserConfigurationException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SAXException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (XPathExpressionException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }//GEN-LAST:event_popMemItemAddStarActionPerformed

    private void popMemItemAddJunkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_popMemItemAddJunkActionPerformed
        // TODO add your handling code here:
        addJunkForMail();
    }//GEN-LAST:event_popMemItemAddJunkActionPerformed

    public void addJunkForMail() {
        if (_mailProcessNow == null) {
            return;
        }
        if (_mailProcessNow.getJunk().equals("false")) {
            _mailProcessNow.setJunk("true");
        } else {
            _mailProcessNow.setJunk("false");
        }
        if (_mailProcessNow.updateJunk(GlobalVariables.g_strTenTapTinMail)) {
            try {
                xemMail(nodeClick);
            } catch (ParserConfigurationException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SAXException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (XPathExpressionException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    private void toolbar_btnJunkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnJunkActionPerformed
        // TODO add your handling code here:
        addJunkForMail();
    }//GEN-LAST:event_toolbar_btnJunkActionPerformed
    private MyPrint.PrintPanel canvas;
    private PrintRequestAttributeSet attributes;
    private void toolbar_btnPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnPrintActionPerformed
        // TODO add your handling code here:
        if (_mailProcessNow == null) {
            return;
        }
        String bodyReply = "From: " + _mailProcessNow.getFrom() + "\n" +
                "Sent: " + _mailProcessNow.getDate() + "\n" +
                "To: " + _mailProcessNow.getTo() + "\n" +
                "Subject: " + _mailProcessNow.getSubject() + "\n" +
                _mailProcessNow.getBody() + "\n";

        canvas = new MyPrint.PrintPanel(this.txtTypeView_Content, bodyReply);
        attributes = new HashPrintRequestAttributeSet();
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable(canvas);
        if (job.printDialog(attributes)) {
            try {
                job.print(attributes);
            } catch (PrinterException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_toolbar_btnPrintActionPerformed

    private void toolbar_btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnDeleteActionPerformed
        // TODO add your handling code here:
        if (_mailProcessNow == null) {
            return;
        }
        if (_mailProcessNow.delete(GlobalVariables.g_strTenTapTinMail)) {
            try {
                if (_mailProcessNow.getPathAttach().size() != 0) {
                    for (String filename : _mailProcessNow.getPathAttach()) {
                        File file = new File(filename);
                        file.delete();
                    }
                }
                xemMail(nodeClick);
                _mailProcessNow = null;
            } catch (ParserConfigurationException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SAXException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (XPathExpressionException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }//GEN-LAST:event_toolbar_btnDeleteActionPerformed

    private void tblCalendar_ThoiGianMouseWheelMoved(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_tblCalendar_ThoiGianMouseWheelMoved
        // TODO add your handling code here:
        int direction = evt.getWheelRotation();
        if (direction < 0) {
            scroll_GhiChu.getVerticalScrollBar().setValue(
                    scroll_GhiChu.getVerticalScrollBar().getValue() - 15);
            scroll_ThoiGian.getVerticalScrollBar().setValue(
                    scroll_ThoiGian.getVerticalScrollBar().getValue() - 15);
        } else {
            scroll_GhiChu.getVerticalScrollBar().setValue(
                    scroll_GhiChu.getVerticalScrollBar().getValue() + 15);
            scroll_ThoiGian.getVerticalScrollBar().setValue(
                    scroll_ThoiGian.getVerticalScrollBar().getValue() + 15);
        }
    }//GEN-LAST:event_tblCalendar_ThoiGianMouseWheelMoved

    public int tinhGio(int row) {
        switch (row) {
            case 0:
                return 24;
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 3;
            case 4:
                return 4;
            case 5:
                return 5;
            case 6:
                return 6;
            case 7:
                return 7;
            case 8:
                return 8;
            case 9:
                return 9;
            case 10:
                return 10;
            case 11:
                return 11;
            case 12:
                return 12;
            case 13:
                return 13;
            case 14:
                return 14;
            case 15:
                return 15;
            case 16:
                return 16;
            case 17:
                return 17;
            case 18:
                return 18;
            case 19:
                return 19;
            case 20:
                return 20;
            case 21:
                return 21;
            case 22:
                return 22;
            case 23:
                return 23;
        }
        return -1;
    }
    private void toolbar_btnNewTaskActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnNewTaskActionPerformed
        // TODO add your handling code here:
        //lich ngay
        if (isDayCalendar) {
            Date dateChooser = calendar.getDate();
            String strdate =
                    DateFormat.getInstance().format(dateChooser);
            String[] ThanhPhanDate = strdate.split(" ");
            String date = ThanhPhanDate[0];
            int row = tblCalendar_GhiChu.getSelectedRow();
            int gio = tinhGio(row);
            MyCalendarAndTask.AddTask dlg = new MyCalendarAndTask.AddTask(null, true, date, gio);
            dlg.show();
            if (dlg.isAddSuccess()) {
                XL_CalendarTask task = new XL_CalendarTask();
                if (task.Doc(GlobalVariables.g_strTenTapTinCalendarTask, date)) {
                    MyTable.TableCalendarTask.loadFolderIntoTable(tblCalendar_GhiChu, task, date);
                }
            }
        } else {//lich thang
            MyCalendarAndTask.AddTask_Month dlg = new MyCalendarAndTask.AddTask_Month(null, true, _taskProcess);
            dlg.show();
            //load lai
            if (dlg.isAddSuccess()) {
                Calendar cal = (Calendar) calendar.getCalendar().clone();
                MonthCalendar.TableMonthTask.disableDayNotBelongMonth(tblCalendar_Month, cal);
            }
        }
}//GEN-LAST:event_toolbar_btnNewTaskActionPerformed

    private void toolbar_btnEditTaskActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnEditTaskActionPerformed
        // TODO add your handling code here:
        if (isDayCalendar) {
            if (_congViecProcess == null) {
                return;
            }
            Date dateChooser = calendar.getDate();
            String strdate =
                    DateFormat.getInstance().format(dateChooser);
            String[] ThanhPhanDate = strdate.split(" ");
            String date = ThanhPhanDate[0];

            MyCalendarAndTask.AddTask dlg = new MyCalendarAndTask.AddTask(null, true, date, _congViecProcess);
            dlg.show();
            if (dlg.isAddSuccess()) {
                XL_CalendarTask task = new XL_CalendarTask();
                if (task.Doc(GlobalVariables.g_strTenTapTinCalendarTask, date)) {
                    MyTable.TableCalendarTask.loadFolderIntoTable(tblCalendar_GhiChu, task, date);
                }
            }
        } else {//lich thang
            if (_taskProcess == null) {
                return;
            }
            MyCalendarAndTask.AddTask_Month dlg = new MyCalendarAndTask.AddTask_Month(null, true, _taskProcess);
            dlg.show();
            //load lai
            if (dlg.isAddSuccess()) {
                Calendar cal = (Calendar) calendar.getCalendar().clone();
                MonthCalendar.TableMonthTask.disableDayNotBelongMonth(tblCalendar_Month, cal);
            }
        }
}//GEN-LAST:event_toolbar_btnEditTaskActionPerformed

    private void toolbar_btnDeleteTaskActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnDeleteTaskActionPerformed
        // TODO add your handling code here:
        if (isDayCalendar) {
            if (_congViecProcess == null) {
                return;
            }
            Date dateChooser = calendar.getDate();
            String strdate =
                    DateFormat.getInstance().format(dateChooser);
            String[] ThanhPhanDate = strdate.split(" ");
            String date = ThanhPhanDate[0];

            if (_congViecProcess.delete(GlobalVariables.g_strTenTapTinCalendarTask, date)) {
                XL_CalendarTask task = new XL_CalendarTask();
                if (task.Doc(GlobalVariables.g_strTenTapTinCalendarTask, date)) {
                    MyTable.TableCalendarTask.loadFolderIntoTable(tblCalendar_GhiChu, task, date);
                }
            }
        } else {
            if (_taskProcess == null) {
                return;
            }
            //load lai
            if (_taskProcess.delete(GlobalVariables.g_strTenTapTinMonthTask)) {
                Calendar cal = (Calendar) calendar.getCalendar().clone();
                MonthCalendar.TableMonthTask.disableDayNotBelongMonth(tblCalendar_Month, cal);
            }
        }
}//GEN-LAST:event_toolbar_btnDeleteTaskActionPerformed
    private XL_CongViec _congViecProcess = null;
    private void tblCalendar_GhiChuMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblCalendar_GhiChuMousePressed
        // TODO add your handling code here:
        int modifiers = evt.getModifiers();
        MyTableModel model;
        int ContactID;
        if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
            if (this.tblCalendar_GhiChu.getSelectedRow() == -1) {
                return;
            }

            if (evt.getClickCount() == 2) {//nhap dup mo cua so coi 1 mail
                Date dateChooser = calendar.getDate();
                String strdate =
                        DateFormat.getInstance().format(dateChooser);
                String[] ThanhPhanDate = strdate.split(" ");
                String date = ThanhPhanDate[0];
                int row = tblCalendar_GhiChu.getSelectedRow();
                int gio = tinhGio(row);
                //System.out.println(date);
                MyCalendarAndTask.AddTask dlg = new MyCalendarAndTask.AddTask(null, true, date, gio);
                dlg.show();
                if (dlg.isAddSuccess()) {
                    XL_CalendarTask task = new XL_CalendarTask();
                    if (task.Doc(GlobalVariables.g_strTenTapTinCalendarTask, date)) {
                        MyTable.TableCalendarTask.loadFolderIntoTable(tblCalendar_GhiChu, task, date);
                    }
                }
            } else if (evt.getClickCount() == 1) {
                //_contactProcess = contact;
                XL_CongViec cv = new XL_CongViec();
                Date dateChooser = calendar.getDate();
                String strdate =
                        DateFormat.getInstance().format(dateChooser);
                String[] ThanhPhanDate = strdate.split(" ");
                String date = ThanhPhanDate[0];
                int row = tblCalendar_GhiChu.getSelectedRow();
                int gio = tinhGio(row);
                cv.setGio(gio);
                if (cv.Doc(GlobalVariables.g_strTenTapTinCalendarTask, date)) {
                    _congViecProcess = cv;
                    toolbar_btnNewTask.setEnabled(false);
                    toolbar_btnEditTask.setEnabled(true);
                    toolbar_btnDeleteTask.setEnabled(true);
                } else {
                    _congViecProcess = null;
                    toolbar_btnNewTask.setEnabled(true);
                    toolbar_btnEditTask.setEnabled(false);
                     toolbar_btnDeleteTask.setEnabled(false);
                }
            }
        }
    }//GEN-LAST:event_tblCalendar_GhiChuMousePressed

    private void tblCalendar_GhiChuMouseWheelMoved(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_tblCalendar_GhiChuMouseWheelMoved
        // TODO add your handling code here:
        int direction = evt.getWheelRotation();
        if (direction < 0) {
            scroll_GhiChu.getVerticalScrollBar().setValue(
                    scroll_GhiChu.getVerticalScrollBar().getValue() - 15);
            scroll_ThoiGian.getVerticalScrollBar().setValue(
                    scroll_ThoiGian.getVerticalScrollBar().getValue() - 15);
        } else {
            scroll_GhiChu.getVerticalScrollBar().setValue(
                    scroll_GhiChu.getVerticalScrollBar().getValue() + 15);
            scroll_ThoiGian.getVerticalScrollBar().setValue(
                    scroll_ThoiGian.getVerticalScrollBar().getValue() + 15);
        }
}//GEN-LAST:event_tblCalendar_GhiChuMouseWheelMoved
    private boolean isDayCalendar = true;
    private void jTabbedPane1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane1MouseReleased
        // TODO add your handling code here:
        Date dateChooser = calendar.getDate();
        String strDate =
                DateFormat.getInstance().format(dateChooser);
        String[] thanhPhanNgay = strDate.split(" ");
        String date = thanhPhanNgay[0];
        if (this.jTabbedPane1.getSelectedIndex() == 0) {
            loadDanhSachCongViec(date);
            isDayCalendar = true;
        } else if (this.jTabbedPane1.getSelectedIndex() == 1) {
            isDayCalendar = false;
            Calendar cal = (Calendar) calendar.getCalendar().clone();
            MonthCalendar.TableMonthTask.disableDayNotBelongMonth(this.tblCalendar_Month, cal);
        }
    }//GEN-LAST:event_jTabbedPane1MouseReleased
    private XL_MonthTask _taskProcess;
    private void tblCalendar_MonthMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblCalendar_MonthMousePressed
        // TODO add your handling code here:
        int modifiers = evt.getModifiers();
        if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
            if (this.tblCalendar_Month.getSelectedRow() == -1) {
                return;
            }
            if (evt.getClickCount() == 2) {
                String date = ((JPanel) tblCalendar_Month.getValueAt(
                        tblCalendar_Month.getSelectedRow(), tblCalendar_Month.getSelectedColumn())).getName();
                XL_MonthTask task = new XL_MonthTask();
                task.setNgay(date);
                if (task.Doc(GlobalVariables.g_strTenTapTinMonthTask)) {
                    _taskProcess = task;
                }
                MyCalendarAndTask.AddTask_Month dlg = new MyCalendarAndTask.AddTask_Month(null, true, task);
                dlg.show();
                //load lai
                if (dlg.isAddSuccess()) {
                    Calendar cal = (Calendar) calendar.getCalendar().clone();
                    MonthCalendar.TableMonthTask.disableDayNotBelongMonth(tblCalendar_Month, cal);
                }
            } else if (evt.getClickCount() == 1) {
                String date = ((JPanel) tblCalendar_Month.getValueAt(
                        tblCalendar_Month.getSelectedRow(), tblCalendar_Month.getSelectedColumn())).getName();
                XL_MonthTask task = new XL_MonthTask();
                task.setNgay(date);
                if (task.Doc(GlobalVariables.g_strTenTapTinMonthTask)) {
                    toolbar_btnNewTask.setEnabled(false);
                    toolbar_btnEditTask.setEnabled(true);
                    toolbar_btnDeleteTask.setEnabled(true);
                } else {
                    toolbar_btnNewTask.setEnabled(true);
                    toolbar_btnEditTask.setEnabled(false);
                    toolbar_btnDeleteTask.setEnabled(false);
                }
                _taskProcess = task;
            }
        }
    }//GEN-LAST:event_tblCalendar_MonthMousePressed

    private void memItemSearchMessagesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memItemSearchMessagesActionPerformed
        // TODO add your handling code here:
        MySearch.SearchMail dlg = new MySearch.SearchMail(null, true);
        dlg.show();
    }//GEN-LAST:event_memItemSearchMessagesActionPerformed

    private void memItemSearchContactsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memItemSearchContactsActionPerformed
        // TODO add your handling code here:
        MySearch.SearchContact dlg = new MySearch.SearchContact(null, true);
        dlg.show();
    }//GEN-LAST:event_memItemSearchContactsActionPerformed
    private ResourceBundle resStringsVN;
    private ResourceBundle resStringsEL;
    private boolean isVieNamLanguges = true;

    /**
     * Hàm set ngôn ngữ hiển thị
     * @param resString: Kiểu ResoubleBundle, chứa thông tin về ngôn ngữ cần hiển thị
     * @param myTable1: user control thứ nhất
     * @param myTable2 user control thứ hai
     */
    private void setActivePremierLanguage(ResourceBundle resString) {
        if (isVieNamLanguges) {
            resString =
                    ResourceBundle.getBundle("ResourceBundle/LanguagesStrings_vi_VN");
        } else {
            resString =
                    ResourceBundle.getBundle("ResourceBundle/LanguagesStrings");
        }

        this.toolbar_btnGetMail.setText(resString.getString("Toolbar_GetMail"));
        this.toolbar_btnWrite.setText(resString.getString("Toolbar_Write"));
        this.toolbar_btnAddressBook.setText(resString.getString("Toolbar_AddressBook"));
        this.toolbar_btnReply.setText(resString.getString("Toolbar_Reply"));
        this.toolbar_btnTag.setText(resString.getString("Toolbar_Tag"));
        this.toolbar_btnDelete.setText(resString.getString("Toolbar_Delete"));
        this.toolbar_btnJunk.setText(resString.getString("Toolbar_Junk"));
        this.toolbar_btnPrint.setText(resString.getString("Toolbar_Print"));

        this.memLanguage.setText(resString.getString("Mem_Language"));
        this.memHelp.setText(resString.getString("Mem_Help"));
        this.memItemTacGia.setText(resString.getString("MemItem_TacGia"));

        validate();

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                try {
                    new MainFrame().setVisible(true);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InstantiationException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IllegalAccessException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (UnsupportedLookAndFeelException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (NoSuchAlgorithmException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (Exception ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JLayeredPane jLayeredPane2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JToolBar.Separator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JToolBar.Separator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JSplitPane jSplitPane2;
    private javax.swing.JSplitPane jSplitPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lblCurrentTypeView;
    private javax.swing.JLabel lblCurrentTypeView1;
    private javax.swing.JLabel lblCurrentTypeView2;
    private javax.swing.JLabel lblCurrentTypeView3;
    private javax.swing.JLabel lblCurrentTypeView4;
    private javax.swing.JLabel lblCurrentTypeView5;
    private javax.swing.JLabel lblCurrentTypeView6;
    private javax.swing.JLabel lblCurrentTypeView7;
    private javax.swing.JLabel lblCurrentTypeView8;
    private javax.swing.JLabel lblLocalFolderSceen_CreateAccount;
    private javax.swing.JLabel lblLocalFolderScreen_SearchContacts;
    private javax.swing.JLabel lblLocalFolderScreen_SearchMessage;
    private javax.swing.JLabel lblLocalFolderScreen_ViewSettingAccount;
    private javax.swing.JLabel lblMaiAccountScreen_ReadMessage;
    private javax.swing.JLabel lblMailAccountScreen_CreateAccount;
    private javax.swing.JLabel lblMailAccountScreen_ReadMessage;
    private javax.swing.JLabel lblMailAccountScreen_SearchContacts;
    private javax.swing.JLabel lblMailAccountScreen_SearchMessage;
    private javax.swing.JLabel lblMailAccountScreen_ViewSettingAccount;
    private javax.swing.JLabel lblMailAccountScreen_WriteMessage;
    private javax.swing.JLabel lblQuanLyCalendar;
    private javax.swing.JLabel lblQuanLyContact;
    private javax.swing.JLabel lblQuanLyMail;
    private javax.swing.JLabel lblTag;
    private javax.swing.JLabel lblTypeView_From;
    private javax.swing.JLabel lblTypeView_Subject;
    private javax.swing.JMenu memHelp;
    private javax.swing.JMenuItem memItemAddToContacts;
    private javax.swing.JMenuItem memItemComposeMailTo;
    private javax.swing.JMenuItem memItemEnglish;
    private javax.swing.JMenuItem memItemJavaDoc;
    private javax.swing.JMenuItem memItemSearchContacts;
    private javax.swing.JMenuItem memItemSearchMessages;
    private javax.swing.JMenuItem memItemTacGia;
    private javax.swing.JMenuItem memItemVieNam;
    private javax.swing.JMenu memLanguage;
    private javax.swing.JMenuItem memMail_DeleteFolder;
    private javax.swing.JMenuItem memMail_NewFolder;
    private javax.swing.JMenuItem memTag_Important;
    private javax.swing.JMenuItem memTag_Later;
    private javax.swing.JMenuItem memTag_Personal;
    private javax.swing.JMenuItem memTag_RemoveAlltag;
    private javax.swing.JMenuItem memTag_Todo;
    private javax.swing.JMenuItem memTag_Work;
    private javax.swing.JPanel pnlAttAndTag;
    private javax.swing.JPanel pnlCalendarScreen;
    private javax.swing.JPanel pnlCalendar_TableDay;
    private javax.swing.JPanel pnlCalendar_TableMonth;
    private javax.swing.JPanel pnlChucNangCalendar;
    private javax.swing.JPanel pnlChucNangContact;
    private javax.swing.JPanel pnlChucNangMail;
    private javax.swing.JPanel pnlContact_AddressCard;
    private javax.swing.JPanel pnlContact_AddressCard_Tong;
    private javax.swing.JPanel pnlContact_Bus_Tong;
    private javax.swing.JPanel pnlContact_BusinessCard;
    private javax.swing.JPanel pnlContact_ByCategory;
    private javax.swing.JPanel pnlContact_ByCompany;
    private javax.swing.JPanel pnlContact_DetailAddressCard;
    private javax.swing.JPanel pnlContact_DetailAddress_Tong;
    private javax.swing.JPanel pnlContact_OutlookDataField;
    private javax.swing.JPanel pnlContact_PhoneList;
    private javax.swing.JPanel pnlContent;
    private javax.swing.JPanel pnlLocalfolderScreen;
    private javax.swing.JPanel pnlMailAccountScreen;
    private javax.swing.JPanel pnlQuanLyBase;
    private javax.swing.JPanel pnlQuanLyCalendar;
    private javax.swing.JPanel pnlQuanLyContact;
    private javax.swing.JPanel pnlQuanLyMail;
    private javax.swing.JPanel pnlTypeView_Attachments;
    private javax.swing.JPanel pnlTypeView_CC;
    private javax.swing.JPanel pnlTypeView_Tag;
    private javax.swing.JPanel pnlTypeView_To;
    private javax.swing.JPanel pnlTypeViewlScreen;
    private javax.swing.JPopupMenu popClickIntoEmaiAddressl;
    private javax.swing.JMenu popCopyTo;
    private javax.swing.JPopupMenu popMail;
    private javax.swing.JMenu popMark;
    private javax.swing.JMenuItem popMemItemAddJunk;
    private javax.swing.JMenuItem popMemItemAddStar;
    private javax.swing.JMenu popMoveTo;
    private javax.swing.JPopupMenu popProcessMail;
    private javax.swing.JPopupMenu popTag;
    private javax.swing.JScrollPane scroll_GhiChu;
    private javax.swing.JScrollPane scroll_GhiChu1;
    private javax.swing.JScrollPane scroll_ThoiGian;
    private javax.swing.JTable tblByCompany;
    private javax.swing.JTable tblCalendar_GhiChu;
    private javax.swing.JTable tblCalendar_Month;
    private javax.swing.JTable tblCalendar_ThoiGian;
    private javax.swing.JTable tblContactByCateGory;
    private javax.swing.JTable tblContact_PhoneList;
    private javax.swing.JTable tblMail;
    private javax.swing.JTable tblOutlookDataField;
    private javax.swing.JToolBar toolbar_Mail;
    private javax.swing.JButton toolbar_btnAddressBook;
    private javax.swing.JButton toolbar_btnDelete;
    private javax.swing.JButton toolbar_btnDeleteContact;
    private javax.swing.JButton toolbar_btnDeleteTask;
    private javax.swing.JButton toolbar_btnEditContact;
    private javax.swing.JButton toolbar_btnEditTask;
    private javax.swing.JButton toolbar_btnFindContact;
    private javax.swing.JButton toolbar_btnGetMail;
    private javax.swing.JButton toolbar_btnJunk;
    private javax.swing.JButton toolbar_btnNewContact;
    private javax.swing.JButton toolbar_btnNewMessageToContact;
    private javax.swing.JButton toolbar_btnNewTask;
    private javax.swing.JButton toolbar_btnPrint;
    private javax.swing.JButton toolbar_btnReply;
    private javax.swing.JButton toolbar_btnTag;
    private javax.swing.JButton toolbar_btnWrite;
    private javax.swing.JTree treeContact;
    private javax.swing.JTree treeMail;
    private javax.swing.JTextArea txtTypeView_Content;
    // End of variables declaration//GEN-END:variables

    /**
     * @return the pnlLocalfolderScreen
     */
    public javax.swing.JPanel getPnlLocalfolderScreen() {
        return pnlLocalfolderScreen;
    }

    /**
     * @return the pnlMailAccountScreen
     */
    public javax.swing.JPanel getPnlMailAccountScreen() {
        return pnlMailAccountScreen;
    }

    /**
     * @return the pnlTypeViewlScreen
     */
    public javax.swing.JPanel getPnlTypeViewlScreen() {
        return pnlTypeViewlScreen;
    }
}