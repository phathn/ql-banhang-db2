/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package MonthCalendar;

/**
 *
 * @author sytuan
 */
public class CellTable {

    public int getColumn() {
        return column;
    }

    public void setColumn(int column) {
        this.column = column;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }
    int row;
    int column;
}
