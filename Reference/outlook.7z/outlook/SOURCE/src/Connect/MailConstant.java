/**
 * @copyright 2008 JackHome Production.
 */
package Connect;

/**
 * MailConstant.java
 * @author Ashok Das
 * @version 1.2 May 19, 2008
 */
public class MailConstant {

    public static String MAIL_SERVER_INCOMING;
    public static String MAIL_SERVER_OUTGOING;

    public static String INCOMING_PORT;
    public static String OUTGOING_PORT;

    public static boolean MAIL_SERVER_AUTH;
    public static String MAIL_SERVER_USER;
    public static String MAIL_SERVER_PASSWORD;

    public static boolean MAIL_DEBUG;
    public static String MAIL_CONTENT_TYPE;

    public static String INBOX = "INBOX";
    public static String POP_MAIL;
    public static String SMTP_MAIL;

     /**
     * Khoi tao cac thong so cho viec ket noi
     * @param passWordRequest
     */
    public static void khoiTaoThanhPhanKetNoi(String passWordRequest) {
        Connect.MailConstant.MAIL_SERVER_INCOMING =
                BienDungChung.GlobalVariables.ActiveAccount.getPopName();
        Connect.MailConstant.MAIL_SERVER_OUTGOING =
                BienDungChung.GlobalVariables.ActiveAccount.getSmtpName();

        Connect.MailConstant.INCOMING_PORT =
                String.valueOf(BienDungChung.GlobalVariables.ActiveAccount.getPopPort());
        Connect.MailConstant.OUTGOING_PORT =
                String.valueOf(BienDungChung.GlobalVariables.ActiveAccount.getSmtpPort());

        Connect.MailConstant.MAIL_SERVER_AUTH = true;
        Connect.MailConstant.MAIL_SERVER_USER =
                BienDungChung.GlobalVariables.ActiveAccount.getEmailAddress();
        Connect.MailConstant.MAIL_SERVER_PASSWORD = passWordRequest;

        Connect.MailConstant.MAIL_DEBUG = false;
        Connect.MailConstant.MAIL_CONTENT_TYPE = "text/html;charset=UTF-8";

        Connect.MailConstant.POP_MAIL =
                BienDungChung.GlobalVariables.ActiveAccount.getPopType();
        Connect.MailConstant.SMTP_MAIL = "smtp";
    }
}
