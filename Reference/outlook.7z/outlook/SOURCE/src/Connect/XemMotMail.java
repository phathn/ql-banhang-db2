/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * SendMail.java
 *
 * Created on Jun 1, 2009, 6:26:24 PM
 */
package Connect;

import AutoComplete.AutoCompleteDecorator;
import BienDungChung.GlobalVariables;
import LopDungChung.OpenMailAttachment;
import LopXuLy.XL_Account;
import LopXuLy.XL_DanhSachMailDaGui;
import LopXuLy.XL_Mail;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.InputEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.ListCellRenderer;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.JTextComponent;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import org.xml.sax.SAXException;
import sun.awt.shell.ShellFolder;

/**
 *
 * @author letuan
 */
public class XemMotMail extends javax.swing.JDialog {

    private JList _DanhSachMailAutoComplete = new JList();
    private DefaultListModel model = new DefaultListModel();
    private XL_Mail _mail;
    private Color imgCurrentNavImage;

    /** Creates new form SendMail */
    public XemMotMail(java.awt.Frame parent, boolean modal, XL_Mail mail) {
        super(parent, modal);
        initComponents();
        this._mail = mail;
        khoiTaoThanhPhan(this._mail);
    //this.pnlSplitAttachment.setVisible(false);
    }

    /**
     * khoi tao,hieu chinh form
     */
    public void khoiTaoThanhPhan(XL_Mail mail) {
        lblSubject.setText(mail.getSubject());
        lblFrom.setText(mail.getFrom());
        lblDate.setText(mail.getDate());

        ListCellRenderer renderer = new MyImageCellRenderer();
        lstAttachment.setCellRenderer(renderer);

        for (int i = 0; i < mail.getTo().size(); i++) {
            String to = mail.getTo().get(i);
            JLabel lb1 = new JLabel();
            Font plain = new Font(lb1.getFont().getName(), Font.PLAIN, lb1.getFont().getSize());
            lb1.setFont(plain);
            lb1.setText(to);
            lb1.setName(to);
            lb1.setForeground(Color.BLUE);

            addMouseListenerToLabelMail(lb1);
            pnlTo.add(lb1);
        }

        for (int i = 0; i < mail.getCc().size(); i++) {
            String cc = mail.getCc().get(i);
            JLabel lb1 = new JLabel();
            Font plain = new Font(lb1.getFont().getName(), Font.PLAIN, lb1.getFont().getSize());
            lb1.setFont(plain);
            lb1.setText(cc);
            lb1.setName(cc);
            lb1.setForeground(Color.blue);

            addMouseListenerToLabelMail(lb1);
            pnlCC.add(lb1);
        }
        txtAreaContent.setText(mail.getBody());

        if (mail.getPathAttach().size() == 0) {
            pnlSplitAttachment.setVisible(false);
        } else {
            for (int i = 0; i < mail.getPathAttach().size(); i++) {
                try {
                    File file = new File(mail.getPathAttach().get(i));
                    ShellFolder sf;
                    sf = ShellFolder.getShellFolder(file);
                    ImageIcon imageIcon = new ImageIcon(sf.getIcon(true));
                    //thu nho kich thuoc cua icon
                    if (imageIcon.getIconWidth() > 14 || imageIcon.getIconHeight() > 14) {
                        imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(14, 14, Image.SCALE_SMOOTH));
                    }
                    //add icon vao control
                    JLabel lb1 = new JLabel();
                    lb1.setIcon(imageIcon);
                    //Font plain = new Font(lb1.getFont().getName(), Font.PLAIN, lb1.getFont().getSize());
                    //lb1.setFont(plain);
                    lb1.setText(file.getName());
                    lb1.setName(file.getPath());
                    model.addElement(lb1);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(XemMotMail.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            lstAttachment.setModel(model);
            pnlSplitAttachment.setVisible(true);
        }

    }

    public void addMouseListenerToLabelMail(JLabel label) {
        MouseListener mouseListener = new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent mouseEvent) {
                JLabel label = (JLabel) mouseEvent.getSource();
                imgCurrentNavImage = label.getForeground();
                label.setForeground(Color.blue);
                Font italic = new Font(label.getFont().getName(), Font.ITALIC, label.getFont().getSize());
                label.setFont(italic);
            }

            @Override
            public void mouseExited(MouseEvent mouseEvent) {
                JLabel label = (JLabel) mouseEvent.getSource();

                label.setForeground(imgCurrentNavImage);
                label.setCursor(Cursor.getDefaultCursor());
                Font plain = new Font(label.getFont().getName(), Font.PLAIN, label.getFont().getSize());
                label.setFont(plain);
            }

            public void mousePressed(MouseEvent mouseEvent) {
                int modifiers = mouseEvent.getModifiers();
                if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
                    if (mouseEvent.getClickCount() == 2) {
                        JLabel label = (JLabel) mouseEvent.getSource();
                        String[] thanhPhanName = label.getName().split("_#_");
                        if (thanhPhanName[0].equals("LetuanAttachment")) {
                            OpenMailAttachment dlg = new OpenMailAttachment(null, true, thanhPhanName[1]);
                            dlg.show();
                        }
                    }
                }
            }
        };
        label.addMouseListener(mouseListener);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel8 = new javax.swing.JPanel();
        jToolBar1 = new javax.swing.JToolBar();
        toolbar_btnWrite = new javax.swing.JButton();
        toolbar_btnAddressBook = new javax.swing.JButton();
        toolbar_btnReply = new javax.swing.JButton();
        toolbar_btnPrint = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtAreaContent = new javax.swing.JTextArea();
        jSplitPane1 = new javax.swing.JSplitPane();
        jPanel7 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblSubject = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        lblFrom = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        lblDate = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        pnlTo = new javax.swing.JPanel();
        pnlCCBase = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        pnlCC = new javax.swing.JPanel();
        pnlSplitAttachment = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        pnlAttachments = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        lstAttachment = new javax.swing.JList();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("My Outlook 2009");
        setBackground(java.awt.SystemColor.inactiveCaptionText);
        setResizable(false);

        jPanel8.setLayout(new java.awt.BorderLayout());

        jToolBar1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jToolBar1.setRollover(true);

        toolbar_btnWrite.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/write.png"))); // NOI18N
        toolbar_btnWrite.setText("Write");
        toolbar_btnWrite.setToolTipText("Create a new message");
        toolbar_btnWrite.setBorderPainted(false);
        toolbar_btnWrite.setFocusable(false);
        toolbar_btnWrite.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnWrite.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnWrite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnWriteActionPerformed(evt);
            }
        });
        jToolBar1.add(toolbar_btnWrite);

        toolbar_btnAddressBook.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/address book.png"))); // NOI18N
        toolbar_btnAddressBook.setText("Address Book");
        toolbar_btnAddressBook.setToolTipText("Go to the adress book");
        toolbar_btnAddressBook.setBorderPainted(false);
        toolbar_btnAddressBook.setFocusable(false);
        toolbar_btnAddressBook.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnAddressBook.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnAddressBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnAddressBookActionPerformed(evt);
            }
        });
        jToolBar1.add(toolbar_btnAddressBook);

        toolbar_btnReply.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/reply.gif"))); // NOI18N
        toolbar_btnReply.setText("Reply");
        toolbar_btnReply.setToolTipText("Reply to the message");
        toolbar_btnReply.setBorderPainted(false);
        toolbar_btnReply.setFocusable(false);
        toolbar_btnReply.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnReply.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnReply.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnReplyActionPerformed(evt);
            }
        });
        jToolBar1.add(toolbar_btnReply);

        toolbar_btnPrint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/printer.png"))); // NOI18N
        toolbar_btnPrint.setText("Print");
        toolbar_btnPrint.setToolTipText("Print the messages");
        toolbar_btnPrint.setBorderPainted(false);
        toolbar_btnPrint.setFocusable(false);
        toolbar_btnPrint.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        toolbar_btnPrint.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        toolbar_btnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolbar_btnPrintActionPerformed(evt);
            }
        });
        jToolBar1.add(toolbar_btnPrint);

        jPanel8.add(jToolBar1, java.awt.BorderLayout.NORTH);

        jPanel6.setBackground(new java.awt.Color(227, 239, 255));

        txtAreaContent.setColumns(20);
        txtAreaContent.setEditable(false);
        txtAreaContent.setLineWrap(true);
        txtAreaContent.setRows(10);
        txtAreaContent.setWrapStyleWord(true);
        jScrollPane1.setViewportView(txtAreaContent);

        jSplitPane1.setDividerLocation(510);
        jSplitPane1.setDividerSize(3);

        jPanel7.setBackground(new java.awt.Color(227, 239, 255));
        jPanel7.setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(227, 239, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(519, 25));
        jPanel1.setLayout(new java.awt.BorderLayout());

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Subject:");
        jLabel1.setPreferredSize(new java.awt.Dimension(120, 14));
        jPanel1.add(jLabel1, java.awt.BorderLayout.WEST);
        jPanel1.add(lblSubject, java.awt.BorderLayout.CENTER);

        jPanel7.add(jPanel1, java.awt.BorderLayout.NORTH);

        jPanel2.setBackground(new java.awt.Color(227, 239, 255));
        jPanel2.setLayout(new java.awt.GridLayout(4, 0));

        jPanel3.setBackground(new java.awt.Color(227, 239, 255));
        jPanel3.setLayout(new java.awt.BorderLayout());

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("From:");
        jLabel2.setPreferredSize(new java.awt.Dimension(120, 14));
        jPanel3.add(jLabel2, java.awt.BorderLayout.WEST);
        jPanel3.add(lblFrom, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel3);

        jPanel4.setBackground(new java.awt.Color(227, 239, 255));
        jPanel4.setLayout(new java.awt.BorderLayout());

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Date:");
        jLabel3.setPreferredSize(new java.awt.Dimension(120, 14));
        jPanel4.add(jLabel3, java.awt.BorderLayout.WEST);
        jPanel4.add(lblDate, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel4);

        jPanel5.setBackground(new java.awt.Color(227, 239, 255));
        jPanel5.setLayout(new java.awt.BorderLayout());

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("To:");
        jLabel4.setPreferredSize(new java.awt.Dimension(120, 14));
        jPanel5.add(jLabel4, java.awt.BorderLayout.WEST);

        pnlTo.setBackground(new java.awt.Color(227, 239, 255));
        pnlTo.setLayout(new java.awt.GridLayout(1, 0));
        jPanel5.add(pnlTo, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel5);

        pnlCCBase.setBackground(new java.awt.Color(227, 239, 255));
        pnlCCBase.setLayout(new java.awt.BorderLayout());

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("CC:");
        jLabel6.setPreferredSize(new java.awt.Dimension(120, 14));
        pnlCCBase.add(jLabel6, java.awt.BorderLayout.WEST);

        pnlCC.setBackground(new java.awt.Color(227, 239, 255));
        pnlCC.setLayout(new java.awt.GridLayout(1, 0));
        pnlCCBase.add(pnlCC, java.awt.BorderLayout.CENTER);

        jPanel2.add(pnlCCBase);

        jPanel7.add(jPanel2, java.awt.BorderLayout.CENTER);

        jSplitPane1.setLeftComponent(jPanel7);

        pnlSplitAttachment.setBackground(java.awt.SystemColor.info);
        pnlSplitAttachment.setLayout(new java.awt.BorderLayout());

        jLabel5.setText("  Attachments");
        pnlSplitAttachment.add(jLabel5, java.awt.BorderLayout.NORTH);

        pnlAttachments.setBackground(java.awt.SystemColor.info);

        lstAttachment.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lstAttachmentMousePressed(evt);
            }
        });
        lstAttachment.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                lstAttachmentKeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(lstAttachment);

        javax.swing.GroupLayout pnlAttachmentsLayout = new javax.swing.GroupLayout(pnlAttachments);
        pnlAttachments.setLayout(pnlAttachmentsLayout);
        pnlAttachmentsLayout.setHorizontalGroup(
            pnlAttachmentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
        );
        pnlAttachmentsLayout.setVerticalGroup(
            pnlAttachmentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE)
        );

        pnlSplitAttachment.add(pnlAttachments, java.awt.BorderLayout.CENTER);

        jSplitPane1.setRightComponent(pnlSplitAttachment);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSplitPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 702, Short.MAX_VALUE)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 702, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jSplitPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 390, Short.MAX_VALUE))
        );

        jPanel8.add(jPanel6, java.awt.BorderLayout.CENTER);

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 3, Short.MAX_VALUE)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 3, Short.MAX_VALUE))
        );

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-710)/2, (screenSize.height-621)/2, 710, 621);
    }// </editor-fold>//GEN-END:initComponents

    private void layThongTinNguoiGui(String AccountName) {
        try {
            XL_Account account = new XL_Account();
            account.getUserInfoByName(
                    GlobalVariables.g_strTenTapTinAccount, AccountName);
            GlobalVariables.ActiveAccount = account;
            //String pass = LopDungChung.ThaoTacThuMuc.docPassWord(account.getAccountID());
            String pass = account.getPassword();
            GlobalVariables.ActiveAccount.setPassword(pass);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(XemMotMail.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
            Logger.getLogger(XemMotMail.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(XemMotMail.class.getName()).log(Level.SEVERE, null, ex);
        } catch (XPathExpressionException ex) {
            Logger.getLogger(XemMotMail.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(XemMotMail.class.getName()).log(Level.SEVERE, null, ex);

        }
    }

    private void lstAttachmentMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lstAttachmentMousePressed
        // TODO add your handling code here:
        int modifiers = evt.getModifiers();
        if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
            if (evt.getClickCount() == 2) {
                JLabel label = (JLabel) lstAttachment.getSelectedValue();
                String thanhPhanName = label.getName();
                OpenMailAttachment dlg = new OpenMailAttachment(null, true, thanhPhanName);
                dlg.show();
            }
        }

    }//GEN-LAST:event_lstAttachmentMousePressed

    private void lstAttachmentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lstAttachmentKeyPressed
        // TODO add your handling code here:
        int keycode = evt.getKeyCode();
        String keyText = evt.getKeyText(keycode);
        if (keyText.equals("Delete")) {
            int index = lstAttachment.getSelectedIndex();
            if (index == -1) {
                return;
            }
            DefaultListModel mod = (DefaultListModel) lstAttachment.getModel();
            mod.remove(index);
        }
    }//GEN-LAST:event_lstAttachmentKeyPressed

    private void toolbar_btnAddressBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnAddressBookActionPerformed
        // TODO add your handling code here:
        MyContact.AddressBook dlg = new MyContact.AddressBook(null, true);
        dlg.show();
}//GEN-LAST:event_toolbar_btnAddressBookActionPerformed

    private void toolbar_btnReplyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnReplyActionPerformed
        // TODO add your handling code here:
        if (_mail == null) {
            return;
        }
        String subjectReply = "RE: " + _mail.getSubject();
        String bodyReply = "\n-----Original Message-----\n" +
                "From: " + _mail.getFrom() + "\n" +
                "Sent: " + _mail.getDate() + "\n" +
                "To: " + _mail.getTo() + "\n" +
                "Subject: " + _mail.getSubject() + "\n" +
                _mail.getBody() +
                "----------o0o----------\n";
        Connect.SendMail dlg = new Connect.SendMail(null, true,
                _mail.getFrom(), subjectReply, bodyReply);
        dlg.show();
}//GEN-LAST:event_toolbar_btnReplyActionPerformed
    private MyPrint.PrintPanel canvas;
    private PrintRequestAttributeSet attributes;
    private void toolbar_btnPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnPrintActionPerformed
        // TODO add your handling code here:
        if (_mail == null) {
            return;
        }
        String bodyReply = "From: " + _mail.getFrom() + "\n" +
                "Sent: " + _mail.getDate() + "\n" +
                "To: " + _mail.getTo() + "\n" +
                "Subject: " + _mail.getSubject() + "\n" +
                _mail.getBody() + "\n";

        canvas = new MyPrint.PrintPanel(this.txtAreaContent, bodyReply);
        attributes = new HashPrintRequestAttributeSet();
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable(canvas);
        if (job.printDialog(attributes)) {
            try {
                job.print(attributes);
            } catch (PrinterException ex) {
                Logger.getLogger(XemMotMail.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_toolbar_btnPrintActionPerformed

    private void toolbar_btnWriteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolbar_btnWriteActionPerformed
        // TODO add your handling code here:
        //chu y doi so dau tien phai set la null
        Connect.SendMail dlg = new Connect.SendMail(null, true, _mail.getFrom());
        dlg.show();
}//GEN-LAST:event_toolbar_btnWriteActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                XemMotMail dialog = new XemMotMail(new javax.swing.JFrame(), true, null);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {

                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JLabel lblDate;
    private javax.swing.JLabel lblFrom;
    private javax.swing.JLabel lblSubject;
    private javax.swing.JList lstAttachment;
    private javax.swing.JPanel pnlAttachments;
    private javax.swing.JPanel pnlCC;
    private javax.swing.JPanel pnlCCBase;
    private javax.swing.JPanel pnlSplitAttachment;
    private javax.swing.JPanel pnlTo;
    private javax.swing.JButton toolbar_btnAddressBook;
    private javax.swing.JButton toolbar_btnPrint;
    private javax.swing.JButton toolbar_btnReply;
    private javax.swing.JButton toolbar_btnWrite;
    private javax.swing.JTextArea txtAreaContent;
    // End of variables declaration//GEN-END:variables
}
