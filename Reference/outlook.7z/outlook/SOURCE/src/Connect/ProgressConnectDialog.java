/**
 * @copyright 2008 JackHome Production. 
 */
package Connect;

import BienDungChung.GlobalVariables;
import LopXuLy.XL_DanhSachAccount;
import LopXuLy.XL_DanhSachMail;
import LopXuLy.XL_Mail;
import LopXuLy.XL_MailDaGui;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.MessagingException;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import org.xml.sax.SAXException;
import outlook2009.MainFrame;

/**
 * ProgressConnectDialog.java
 * @author Ashok Das
 * @version 1.2 May 26, 2008
 */
public class ProgressConnectDialog extends JDialog {

    /**
     * Attributes
     */
    private ImageIcon imageloading = new ImageIcon(
            System.getProperty("user.dir") + File.separator +
            "images_tree/progress_bar.gif");
    private JLabel lblProgress = new JLabel("", imageloading, JLabel.HORIZONTAL);
    private Thread processThread;
    private boolean rememberPassword;
    private JPanel pnlLocalfolderScreen,  pnlMailAccountScreen,  pnlTypeViewlScreen;
    private Message[] messages = null;
    private JTable table;
    private JTree tree;
    private ArrayList<String> _to = new ArrayList<String>();
    private ArrayList<String> _cc = new ArrayList<String>();
    private String _Subject;
    private String _Content;
    private ArrayList<File> fileAttachment;
    private Date _date;

    /**
     * Ham tao phuc vu cho viec kiem tra co mail moi hay khog moi khi chuong trinh khoi dong
     * @param aThis
     * @param title
     * @param AccountID
     */
    public ProgressConnectDialog(MainFrame aThis, String title) {
        setTitle(title);
        setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {

            public void windowClosing(WindowEvent we) {
                //Do nothing....
            }
        });
        setSize(350, 180);
        int width = Toolkit.getDefaultToolkit().getScreenSize().width;
        int height = Toolkit.getDefaultToolkit().getScreenSize().height;
        setLocation(width / 3, height / 3);

        getContentPane().add(lblProgress);
        addMouseListener(new MouseAdapter() {

            public void mouseClicked(MouseEvent me) {
                dispose();
            }
        });
        setVisible(true);
    }

    /**
     * The Constructor.
     * @param mc
     * @param title
     */
    public ProgressConnectDialog(java.awt.Frame parent, String title, boolean rememberPass,
            JPanel pnlLocalfolderScreen, JPanel pnlMailAccountScreen, JPanel pnlTypeViewlScreen,
            JTable table, JTree tree) {
        this.rememberPassword = rememberPass;
        setTitle(title);
        setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {

            public void windowClosing(WindowEvent we) {
                //Do nothing....
            }
        });
        setSize(350, 180);
        int width = Toolkit.getDefaultToolkit().getScreenSize().width;
        int height = Toolkit.getDefaultToolkit().getScreenSize().height;
        setLocation(width / 3, height / 3);

        getContentPane().add(lblProgress);
        addMouseListener(new MouseAdapter() {

            public void mouseClicked(MouseEvent me) {
                dispose();
            }
        });
        setVisible(false);
        this.pnlLocalfolderScreen = pnlLocalfolderScreen;
        this.pnlMailAccountScreen = pnlMailAccountScreen;
        this.pnlTypeViewlScreen = pnlTypeViewlScreen;
        this.table = table;
        this.tree = tree;
    }

    /**
     * Constructor
     * @param parent
     * @param modal
     * @param title
     * @param to
     * @param cc
     * @param subject
     * @param content
     * @param file_name
     * @param date
     */
    public ProgressConnectDialog(java.awt.Frame parent, boolean modal, String title,
            ArrayList<String> to, ArrayList<String> cc, String subject, String content,
            ArrayList<File> file_name, Date date) {
        super(parent, modal);
        setTitle(title);
        setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {

            public void windowClosing(WindowEvent we) {
                //Do nothing....
            }
        });
        setSize(350, 180);
        int width = Toolkit.getDefaultToolkit().getScreenSize().width;
        int height = Toolkit.getDefaultToolkit().getScreenSize().height;
        setLocation(width / 3, height / 3);

        getContentPane().add(lblProgress);
        addMouseListener(new MouseAdapter() {

            public void mouseClicked(MouseEvent me) {
                dispose();
            }
        });
        setVisible(false);

        this._Subject = subject;
        this._Content = content;
        this.fileAttachment = file_name;
        this._date = date;
        this._to = to;
        this._cc = cc;
    }

    /**
     * The Method getLblProgress.
     * @return
     * @return		JLabel
     */
    public JLabel getLblProgress() {
        return lblProgress;
    }

    /**
     * The Method setLblProgress.
     * @param lblProgress
     * @return		void
     */
    public void setLblProgress(JLabel lblProgress) {
        this.lblProgress = lblProgress;
    }

    /**
     *Kiem tra co mail moi hay khong moi khi chuong trinh khoi dong
     */
    public void testMail() {
        try {
            haveNewMessageOnBegin();
        } catch (IOException ex) {
            Logger.getLogger(ProgressConnectDialog.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(ProgressConnectDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Kiem tra ket noi, neu hop le lay mail ve
     * @return true:hop le, false, nguoc lai
     */
    public void haveNewMessageOnBegin() throws IOException, Exception {
        Connect.GuiNhanMail processMail = new Connect.GuiNhanMail();
        if (processMail.moKetnoiToiPopServer()) {
            //lay so luong mail
            BienDungChung.GlobalVariables.numMessage = processMail.layMail();
            //Co mail moi, thuc hien lay mail ve
            this.messages = processMail.messages;
            if (this.messages != null) {
                layMailVeKhiKhoiDong(messages);
            }
            GlobalVariables.numMailOfUser.put(
                    BienDungChung.GlobalVariables.ActiveAccount.getAccountName(),
                    BienDungChung.GlobalVariables.numMessage);
        } else {
            this.dispose();
        }
        this.dispose();
    }

    /**
     * Xet xem mail lay ve co dang de luu hay khong
     * @param dsmail
     * @param mail
     * @return
     */
    public boolean dangDeLuu(XL_DanhSachMail dsmail, XL_Mail mail) {
        for (int i = 0; i < dsmail.getDanhSachMail().size(); i++) {
            XL_Mail m = dsmail.getDanhSachMail().get(i);
            if (m.getSubject().equals(mail.getSubject()) &&
                    m.getDate().equals(mail.getDate()) &&
                    m.getPlaceStore().equals(mail.getPlaceStore())) {
                return false;
            }
        }
        return true;
    }

    /**
     * lay mail ve khi khoi dong chuong trinh, neu co mail moi
     * @param messages
     * @throws javax.mail.MessagingException
     * @throws javax.xml.parsers.ParserConfigurationException
     * @throws org.xml.sax.SAXException
     * @throws java.io.IOException
     * @throws javax.xml.xpath.XPathExpressionException
     */
    public void layMailVeKhiKhoiDong(Message[] messages) throws MessagingException, ParserConfigurationException, SAXException, IOException, XPathExpressionException {

        int mailid = XL_DanhSachMail.layIDMail(GlobalVariables.g_strTenTapTinMail) + 1;
        XL_DanhSachMail dsMail = new XL_DanhSachMail();
        for (int i = 0; i < messages.length; i++) {
            GlobalVariables.pathAtt = new ArrayList<String>();

            if (messages[i] != null && !messages[i].getContentType().equals(
                    "text/html") && !messages[i].isSet(Flags.Flag.SEEN)) {
                XL_Mail mail = new XL_Mail();
                mail.setMailID(mailid);
                mail.setUserID(BienDungChung.GlobalVariables.ActiveAccount.getAccountID());
                mail.setFrom(messages[i].getFrom()[0].toString());
                mail.setSubject(messages[i].getSubject());

                //set to
                Address[] add = messages[i].getRecipients(RecipientType.TO);
                ArrayList<String> to = new ArrayList<String>();
                for (int j = 0; j < add.length; j++) {
                    to.add(add[j].toString());
                }
                mail.setTo(to);

                //set cc (neu co)
                add = messages[i].getRecipients(RecipientType.CC);
                ArrayList<String> cc = new ArrayList<String>();
                if (add != null) {
                    for (int j = 0; j < add.length; j++) {
                        cc.add(add[j].toString());
                    }
                }
                mail.setCc(cc);

                //set content
                String bodyText = getMessageContent(messages[i]).toString();
                int indexBody = bodyText.indexOf("------=");
                if (indexBody != -1) {
                    bodyText = bodyText.substring(0, indexBody);
                }

                mail.setBody(bodyText);

                String date =
                        DateFormat.getInstance().format(messages[i].getSentDate());
                mail.setDate(date);

                mail.setPathAttach(GlobalVariables.pathAtt);

                mail.setPlaceStore("Inbox");

                dsMail.getDanhSachMail().add(mail);
            }
        }
        if (dsMail.getDanhSachMail().size() > 0) {
            //Thuc hien luu mail vao file
            XL_DanhSachMail ds = new XL_DanhSachMail();
            ds.DocDanhSachMailByUserID(
                    GlobalVariables.g_strTenTapTinMail, GlobalVariables.ActiveAccount.getAccountID());
            for (int i = 0; i < dsMail.getDanhSachMail().size(); i++) {
                XL_Mail mail = new XL_Mail();
                mail = dsMail.getDanhSachMail().get(i);
                if (dangDeLuu(ds, mail)) {
                    mail.Ghi(BienDungChung.GlobalVariables.g_strTenTapTinMail);
                }
            }
        }
    }

    /**
     *ham thuc hien tac vu lay mail
     */
    public void startGetMail() {
        processThread = new Thread(new Runnable() {

            public void run() {
                try {
                    if (ketNoiToiPopServer()) {
                        pnlLocalfolderScreen.setVisible(false);
                        pnlMailAccountScreen.setVisible(false);
                        pnlTypeViewlScreen.setVisible(true);
                        GlobalVariables.loaded = true;
                    } else {
                        BienDungChung.GlobalVariables.connectSucess = "Kết nối thất bại";
                        Create_Account.XacNhanAccout xacnhandlg = new Create_Account.XacNhanAccout(null, true, pnlLocalfolderScreen, pnlMailAccountScreen, pnlTypeViewlScreen, table, tree);
                        xacnhandlg.show();
                        GlobalVariables.loaded = true;
                    }
                } catch (Exception ex) {
                    Logger.getLogger(ProgressConnectDialog.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        processThread.start();
        this.setVisible(true);
    }

    /**
     *ham thuc hien tac vu gui mail
     */
    public void startSendMail() {
        processThread = new Thread(new Runnable() {

            public void run() {
                try {
                    if (ketNoiToiSmtpServer()) {
                        JOptionPane.showMessageDialog(null, "Mail has been seen",
                                "Announcement", JOptionPane.INFORMATION_MESSAGE);
                        GlobalVariables.loaded = true;
                    } else {
                        BienDungChung.GlobalVariables.connectSucess = "Kết nối thất bại";
                        GlobalVariables.loaded = true;
                    }
                } catch (Exception ex) {
                    Logger.getLogger(ProgressConnectDialog.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        processThread.start();
        this.setVisible(true);
    }

    /**
     * luu mail da gui
     * @param TenTapTin
     */
    public void luuMailDaGui(String TenTapTin) {
        XL_Mail mail = new XL_Mail();
        int numMail = XL_DanhSachMail.layIDMail(GlobalVariables.g_strTenTapTinMail) + 1;
        mail.setMailID(numMail);
        mail.setUserID(GlobalVariables.ActiveAccount.getAccountID());
        mail.setSubject(_Subject);
        mail.setBody(_Content);
        String date =
                DateFormat.getInstance().format(_date);
        mail.setDate(date);
        mail.setFrom(GlobalVariables.ActiveAccount.getEmailAddress());
        mail.setTo(_to);
        mail.setCc(_cc);
        if (fileAttachment.size() > 0) {
            ArrayList<String> arr = new ArrayList<String>();
            for (int i = 0; i < fileAttachment.size(); i++) {
                arr.add(fileAttachment.get(i).getPath());
            }
            mail.setPathAttach(arr);
        } else {
            mail.setPathAttach(new ArrayList<String>());
        }

        mail.setPlaceStore("Sent");
        mail.Ghi(BienDungChung.GlobalVariables.g_strTenTapTinMail);


    }

    /**
     * luu dia chi da gui de thuc hien autocomplete
     * @param TenTapTin
     * @param address
     */
    public void luuDiaChiDaGui(String TenTapTin, String address) {
        try {
            //doc danh sach tat ca cac mail da gui
            if (XL_MailDaGui.chuaTonTai(TenTapTin, address)) {
                //chua ton tai thi ghi
                XL_MailDaGui mail = new XL_MailDaGui();
                mail.setAddress(address);
                mail.Ghi(TenTapTin);
            }
        } catch (XPathExpressionException ex) {
            Logger.getLogger(ProgressConnectDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Ket noi toi smtp sever de thuc hien gui mail
     * @return
     */
    public boolean ketNoiToiSmtpServer() {
        Connect.GuiNhanMail processMail = new Connect.GuiNhanMail();
        if (processMail.guiMail(_to, _cc, _Subject, _Content, this.fileAttachment)) {
            //gui thanh cong, luu vao danh sach mail da gui
            luuMailDaGui(GlobalVariables.g_strTenTapTinMail);
            //luu giu dia chi da gui di
            for (int i = 0; i < _to.size(); i++) {
                luuDiaChiDaGui(GlobalVariables.g_strTenTapTinMailDaGui, _to.get(i));
            }
            if (_cc.size() > 0) {
                for (int i = 0; i < _cc.size(); i++) {
                    luuDiaChiDaGui(GlobalVariables.g_strTenTapTinMailDaGui, _cc.get(i));
                }
            }
        } else {
            this.dispose();
            return false;
        }
        this.dispose();
        return true;
    }

    /**
     * Kiem tra ket noi, neu hop le lay mail ve
     * @return true:hop le, false, nguoc lai
     */
    public boolean ketNoiToiPopServer() throws IOException, Exception {
        Connect.GuiNhanMail processMail = new Connect.GuiNhanMail();
        if (processMail.moKetnoiToiPopServer()) {
            //ket noi thanh cong, luu password
            if (this.rememberPassword) {
                LopDungChung.ThaoTacThuMuc.ghiPassWord(BienDungChung.GlobalVariables.ActiveAccount.getAccountID(),
                        Connect.MailConstant.MAIL_SERVER_PASSWORD);
            }
            //lay mail ve
            BienDungChung.GlobalVariables.numMessage = processMail.layMail();
            this.messages = processMail.messages;
            GlobalVariables.numMailOfUser.put(
                    BienDungChung.GlobalVariables.ActiveAccount.getAccountName(),
                    BienDungChung.GlobalVariables.numMessage);
            MyTree.TreeMail.loadElemsIntoTreeMail(tree);
            //do du lieu vo table
            if (this.messages != null) {
                createData(messages);
            }
        } else {
            this.dispose();
            return false;
        }
        this.dispose();
        return true;
    }

    /**
     * Kiem tra content la text hay multipart, neu la multipar thuc hien luu file
     * @param m message chua content can kiem tra
     * @return true: text false: multipart
     */
    private boolean isMessageText(Message m) throws IOException, MessagingException {
        String filepath = "";
        Multipart multipart;
        if (m.getContent() instanceof Multipart) {
            multipart = (Multipart) m.getContent();
            for (int z = 0; z < multipart.getCount(); z++) {
                BodyPart part = multipart.getBodyPart(z);
                String disposition = part.getDisposition();
                if ((disposition != null) && (disposition.equals(Part.ATTACHMENT) || (disposition.equals(Part.INLINE)))) {
                    /*
                     * Here allowing user to choose to save or left out
                     */
                    filepath = "D:\\Outlook2009_letuan\\" + GlobalVariables.ActiveAccount.getAccountName() + "\\Inbox";
                    String filename = filepath + "/" + part.getFileName();
                    GlobalVariables.pathAtt.add(filename);
                    LopDungChung.ThaoTacThuMuc.saveFile(filename, part.getInputStream());
                } else {
                    continue;
                }
            }
        } else if (m.getContent() instanceof String) {
            return true;
        }
        return false;
    }

    /**
     * DocDanhSachTatCaMail noi dung mail
     */
    public StringBuffer getMessageContent(Message msg) {
        StringBuffer buffer = new StringBuffer("");
        try {
            boolean flagContent = isMessageText(msg);
            if (!flagContent) {
                BufferedReader is = new BufferedReader(new InputStreamReader(msg.getInputStream()));
                String line = "";
                boolean flag = false;
                int counter = 0;
                while ((line = is.readLine()) != null) {
                    if (line.startsWith("Content-Transfer-")) {
                        flag = true;
                        counter++;
                    }
                    if (flag == true && line.indexOf("_NextPart_") > 0) {
                        flag = false;
                        counter++;
                    }
                    if (counter == 1 && !line.startsWith("Content-Transfer-")) {

                        line = line.replaceAll("=0D=0A", "\n");
                        line = line.replaceAll("=0A", " ");
                        buffer.append(line + "\n");
                    }
                }
            } else {
                buffer.append("\n" + msg.getContent());
            }
        } catch (Exception e) {
            int substr = e.getMessage().length() > 20 ? 20 : e.getMessage().length();
            JOptionPane.showMessageDialog(null, "IO exception:" + e.getMessage().substring(0, substr),
                    "Unable to read message this time",
                    JOptionPane.ERROR_MESSAGE);
        }
        return buffer;
    }

    /**
     * Do du lieu vao table
     * @param messages
     */
    public void createData(Message[] messages) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
        try {
            //lay so luong mail ung voi AccountID
            int mailid;
            XL_DanhSachMail dsMail = new XL_DanhSachMail();
            for (int i = 0; i < messages.length; i++) {
                GlobalVariables.pathAtt = new ArrayList<String>();

                if (messages[i] != null && !messages[i].getContentType().equals(
                        "text/html") && !messages[i].isSet(Flags.Flag.SEEN)) {
                    XL_Mail mail = new XL_Mail();
                    mail.setUserID(BienDungChung.GlobalVariables.ActiveAccount.getAccountID());
                    mail.setFrom(messages[i].getFrom()[0].toString());
                    mail.setSubject(messages[i].getSubject());

                    //set to
                    Address[] add = messages[i].getRecipients(RecipientType.TO);
                    ArrayList<String> to = new ArrayList<String>();
                    for (int j = 0; j < add.length; j++) {
                        to.add(add[j].toString());
                    }
                    mail.setTo(to);

                    //set cc (neu co)
                    add = messages[i].getRecipients(RecipientType.CC);
                    ArrayList<String> cc = new ArrayList<String>();
                    if (add != null) {
                        for (int j = 0; j < add.length; j++) {
                            cc.add(add[j].toString());
                        }
                    }
                    mail.setCc(cc);

                    //set content
                    String bodyText = getMessageContent(messages[i]).toString();
                    int indexBody = bodyText.indexOf("------=");
                    bodyText = bodyText.substring(0, indexBody);
                    mail.setBody(bodyText);

                    String date =
                            DateFormat.getInstance().format(messages[i].getSentDate());
                    mail.setDate(date);

                    mail.setPathAttach(GlobalVariables.pathAtt);

                    mail.setPlaceStore("Inbox");

                    dsMail.getDanhSachMail().add(mail);
                }
            }
            if (dsMail.getDanhSachMail().size() > 0) {
                //lay danh sach cac mail theo user dang xet
                XL_DanhSachMail ds = new XL_DanhSachMail();
                ds.DocDanhSachMailByUserID(
                        GlobalVariables.g_strTenTapTinMail, GlobalVariables.ActiveAccount.getAccountID());
                //kiem tra xem mail lay ve co dang de luu hay khong
                //tuc la da luu roi, khong can luu nua
                for (int i = 0; i < dsMail.getDanhSachMail().size(); i++) {
                    XL_Mail mail = new XL_Mail();
                    mail = dsMail.getDanhSachMail().get(i);
                    if (dangDeLuu(ds, mail)) {
                        mailid = XL_DanhSachMail.layIDMail(GlobalVariables.g_strTenTapTinMail) + 1;
                        ;
                        mail.setMailID(mailid);
                        mail.Ghi(BienDungChung.GlobalVariables.g_strTenTapTinMail);
                    }
                }
                //load tat cac mail theo user vao table
                ds = new XL_DanhSachMail();
                ds.DocDanhSachMailByUserID(
                        GlobalVariables.g_strTenTapTinMail, GlobalVariables.ActiveAccount.getAccountID());
                XL_DanhSachMail dsMailInbox = new XL_DanhSachMail();
                for (XL_Mail mail : ds.getDanhSachMail()) {
                    if (mail.getPlaceStore().equals("Inbox")) {
                        dsMailInbox.getDanhSachMail().add(mail);
                    }
                }
                MyTable.TableMail.loadFolderIntoTableMail(table, dsMailInbox);

            //laySoLuongMailHienCo();
            }
        } catch (MessagingException ex) {
            return;
        }

    }
}
