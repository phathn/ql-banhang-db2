/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Connect;

import LopXuLy.XL_Account;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import java.io.File;
import java.util.ArrayList;
import javax.activation.DataSource;
import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Store;
import javax.swing.JOptionPane;

/**
 *
 * @author letuan
 */
public class GuiNhanMail {

    public Message[] messages = null;
    private Folder folder = null;
    private Store store = null;
    //private MailClient mailClient;
    private Runtime runtime = Runtime.getRuntime();
    private Authenticator authen = new SMTPAuthenticator();

    /**
     * Ham khoi dung
     */
    public GuiNhanMail() {
    }

    /**
     * Mo ket noi toi pop server de thuc hien gui mail
     * @return
     */
    public boolean moKetnoiToiPopServer() {
        Properties prop = new Properties();
        close();
        if (MailConstant.INCOMING_PORT != null && !MailConstant.INCOMING_PORT.equals("")) {
            prop.setProperty("mail.pop3.port", MailConstant.INCOMING_PORT);
            prop.setProperty("mail.pop3.socketFactory.port",
                    MailConstant.INCOMING_PORT);
            prop.setProperty("mail.pop3.socketFactory.class",
                    "javax.net.ssl.SSLSocketFactory");
            prop.setProperty("mail.pop3.socketFactory.fallback", "false");
        }
        prop.put("mail.pop3.host", MailConstant.MAIL_SERVER_INCOMING);
        prop.put("mail.store.protocol", "pop3");

        Session session = null;
        if (MailConstant.MAIL_SERVER_AUTH) {
            session = Session.getInstance(prop, authen);
        } else {
            session = Session.getInstance(prop);
        }

        session.setDebug(MailConstant.MAIL_DEBUG); // Enable the debug mode
        try {
            // Connect to host
            store = session.getStore(MailConstant.POP_MAIL);
            store.connect(MailConstant.MAIL_SERVER_INCOMING, -1, MailConstant.MAIL_SERVER_USER, MailConstant.MAIL_SERVER_PASSWORD);
        } catch (Exception ex) {
            return false;
        }
        return true;
    }

    /**
     * Sau khi ket noi thanh cong, thuc hien thao tao gui mail
     * @param to
     * @param cc
     * @param subject
     * @param content
     * @param file_name
     * @return
     */
    public boolean guiMail(ArrayList<String> to, ArrayList<String> cc,
            String subject, String content, ArrayList<File> file_name) {
        boolean result = true;
        try {
            // Gets the System properties
            Properties props = new Properties();
            props.setProperty("mail.transport.protocol", "smtp");
            props.setProperty("mail.host", MailConstant.MAIL_SERVER_OUTGOING);
            if (MailConstant.MAIL_SERVER_AUTH) {
                props.put("mail.smtp.auth", MailConstant.MAIL_SERVER_AUTH);
            }
            if (MailConstant.OUTGOING_PORT != null && !MailConstant.OUTGOING_PORT.trim().equals("")) {
                props.put("mail.smtp.port", MailConstant.OUTGOING_PORT);
                props.put("mail.smtp.socketFactory.port",
                        MailConstant.OUTGOING_PORT);
                props.put("mail.smtp.socketFactory.class",
                        "javax.net.ssl.SSLSocketFactory");
                props.put("mail.smtp.socketFactory.fallback", "false");
                props.setProperty("mail.smtp.quitwait", "false");
            }

            Session session = null;
            if (MailConstant.MAIL_SERVER_AUTH) {
                session = Session.getInstance(props, authen);
            } else {
                session = Session.getInstance(props);
            }
            // Get the default Session using Properties Object
            // Session session = Session.getDefaultInstance(l_props, null);

            session.setDebug(MailConstant.MAIL_DEBUG); // Enable the debug mode

            // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            // Define message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(MailConstant.MAIL_SERVER_USER));
            /*
             * Multiple receipent to
             */

            if (to.size() > 0) {
                Address toAdd[] = new Address[to.size()];
                for (int i = 0; i < toAdd.length; i++) {
                    toAdd[i] = new InternetAddress(to.get(i));
                }
                message.addRecipients(Message.RecipientType.TO, toAdd);
            }

            /*
             * Multiple receipent cc
             */
            if (cc.size() > 0) {
                Address ccAdd[] = new Address[cc.size()];
                for (int i = 0; i < ccAdd.length; i++) {
                    ccAdd[i] = new InternetAddress(cc.get(i));
                }
                message.addRecipients(Message.RecipientType.CC, ccAdd);
            }

            message.setSubject(subject);
            message.setSentDate(new Date());
            /*
             * Body created
             */
            BodyPart messageBodyPart = new MimeBodyPart();

            /*
             * pushing the bosy text
             */
            messageBodyPart.setText(content);

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);

            /*
             * If any attachement
             */
            if (file_name.size() > 0) {

                for (int i = 0; i < file_name.size(); i++) {
                     messageBodyPart = new MimeBodyPart();
                    DataSource source = new FileDataSource(file_name.get(i));
                    messageBodyPart.setDataHandler(new DataHandler(source));
                    messageBodyPart.setFileName(file_name.get(i).getName());
                    multipart.addBodyPart(messageBodyPart);
                }
            }

            /*
             * allowing support for attachment
             */
            message.setContent(multipart);

            Transport.send(message);

        // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        } catch (MessagingException mex) { // Trap the MessagingException Error
            result = false;
        }
        return result;
    }

    /**
     * Lay mail ve
     * @return
     */
    @SuppressWarnings("static-access")
    public int layMail() {
        // Open the default folder
        int totalMessages;
        try {
            folder = store.getDefaultFolder();
            if (folder == null) {
                return -1;
            }

            folder = folder.getFolder(MailConstant.INBOX);

            if (folder == null) {
                return -1;
            }

            // Get message count
            folder.open(Folder.READ_WRITE);
            totalMessages = folder.getMessageCount();
            if (totalMessages == 0) {
                return 0;
            }

            // Get attributes & flags for all messages
            Message[] message = folder.getMessages();
            this.messages = message;
        } catch (MessagingException ex) {
            return 0;
        }

        return totalMessages;
    }

    /**
     * The Method close.
     * @return		void
     */
    public void close() {
        /*
         * Closing resources no use by now.
         */
        try {
            if (folder != null) {
                folder.close(true);
            }
            if (store != null) {
                store.close();
            }
        } catch (MessagingException e) {
            // e.printStackTrace();
        }
    }

    /**
     * @return the messages
     */
    public Message[] getMessages() {
        return messages;
    }

    /**
     * Inner class
     *
     * @author Ashok Das
     */
    private static class SMTPAuthenticator extends javax.mail.Authenticator {

        public PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(MailConstant.MAIL_SERVER_USER, MailConstant.MAIL_SERVER_PASSWORD);
        }
    }
}

